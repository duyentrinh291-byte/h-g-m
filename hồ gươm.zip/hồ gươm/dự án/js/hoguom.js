// ===============================
// 1. NÚT "KHÁM PHÁ NGAY"
// ===============================

const btnExplore = document.querySelector(".btn");

btnExplore.addEventListener("click", function (event) {
    event.preventDefault();

    document.querySelector("#gioi-thieu").scrollIntoView({
        behavior: "smooth"
    });
});


// ===============================
// 2. MENU ĐỔI MÀU KHI CUỘN TRANG
// ===============================

const header = document.querySelector("header");

window.addEventListener("scroll", function () {

    if (window.scrollY > 80) {
        header.style.background = "rgba(16, 47, 37, 0.95)";
    } else {
        header.style.background = "rgba(0, 0, 0, 0.45)";
    }

});


// ===============================
// 3. HIỆN THÔNG BÁO KHI BẤM VÀO ĐỊA ĐIỂM
// ===============================



// ===============================
// 4. NÚT VỀ ĐẦU TRANG
// ===============================

const backTop = document.createElement("button");

backTop.innerHTML = "↑";

backTop.id = "backTop";

backTop.style.position = "fixed";
backTop.style.bottom = "25px";
backTop.style.right = "25px";
backTop.style.width = "50px";
backTop.style.height = "50px";
backTop.style.border = "none";
backTop.style.borderRadius = "50%";
backTop.style.background = "#d8a82e";
backTop.style.color = "white";
backTop.style.fontSize = "25px";
backTop.style.cursor = "pointer";
backTop.style.display = "none";
backTop.style.zIndex = "999";

document.body.appendChild(backTop);


// Hiện nút khi cuộn xuống

window.addEventListener("scroll", function () {

    if (window.scrollY > 400) {
        backTop.style.display = "block";
    } else {
        backTop.style.display = "none";
    }

});


// Bấm nút để quay lên đầu

backTop.addEventListener("click", function () {

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

});


// ===============================
// 5. HIỆU ỨNG XUẤT HIỆN KHI CUỘN
// ===============================

const sections = document.querySelectorAll("section");

const observer = new IntersectionObserver(
    function (entries) {

        entries.forEach(function (entry) {

            if (entry.isIntersecting) {

                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";

            }

        });

    },
    {
        threshold: 0.15
    }
);


sections.forEach(function (section) {

    section.style.opacity = "0";
    section.style.transform = "translateY(40px)";
    section.style.transition = "all 0.8s ease";

    observer.observe(section);

});

