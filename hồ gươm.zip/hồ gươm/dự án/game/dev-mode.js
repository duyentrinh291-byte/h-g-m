/* HỒ GƯƠM — DEV MODE TÁCH RIÊNG
 * Tắt/xóa công cụ kiểm thử: bỏ thẻ <script src="dev-mode.js"></script> trong game.html.
 * Không cần sửa game.css. Các thao tác trong game được gọi qua window.HoGuomDevAPI.
 */
(() => {
  "use strict";
  const api = window.HoGuomDevAPI;
  if (!api) {
    console.warn("Dev Mode: không tìm thấy HoGuomDevAPI. Hãy kiểm tra thứ tự nạp game.js và dev-mode.js.");
    return;
  }

  const style = document.createElement("style");
  style.textContent = `
    #hoguomDevPanel { position:fixed; z-index:99999; top:14px; right:14px; width:min(300px,calc(100vw - 28px)); max-height:calc(100vh - 28px); overflow:auto; box-sizing:border-box; padding:13px; border:1px solid rgba(119,239,222,.55); border-radius:14px; color:#eafff9; background:rgba(5,25,31,.97); box-shadow:0 12px 34px rgba(0,0,0,.42); font:12px/1.4 system-ui,sans-serif; }
    #hoguomDevPanel.hgd-hidden { display:none; }
    #hoguomDevPanel .hgd-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; color:#91f4d7; letter-spacing:.08em; }
    #hoguomDevPanel button,#hoguomDevPanel select { min-width:0; border:1px solid rgba(134,226,216,.35); border-radius:7px; padding:7px 8px; color:#eafff9; background:#12363b; font:inherit; cursor:pointer; }
    #hoguomDevPanel button:hover { background:#1b5558; }
    #hoguomDevPanel .hgd-head button { padding:2px 8px; font-size:18px; }
    #hoguomDevPanel label { display:block; margin:8px 0 4px; color:#b4d8d4; }
    #hoguomDevPanel .hgd-row { display:flex; gap:6px; }
    #hoguomDevPanel .hgd-row select { flex:1; width:0; }
    #hoguomDevPanel .hgd-actions { display:grid; grid-template-columns:1fr 1fr; gap:6px; margin-top:9px; }
    #hoguomDevPanel .hgd-actions button:last-child { grid-column:1 / -1; }
    #hoguomDevPanel #hoguomDevStatus { margin:10px 0 4px; min-height:16px; color:#9bf1cb; }
    #hoguomDevPanel small { color:#93aaa9; }
    @media (max-width:520px) { #hoguomDevPanel { top:7px; right:7px; width:min(280px,calc(100vw - 14px)); max-height:calc(100vh - 14px); padding:9px; } #hoguomDevPanel button,#hoguomDevPanel select { padding:6px; } }
  `;
  style.textContent += `
    #hoguomDevToggle { position:fixed; z-index:100000; left:12px; bottom:12px; border:1px solid rgba(119,239,222,.65); border-radius:999px; padding:9px 13px; color:#eafff9; background:#07343a; box-shadow:0 5px 18px rgba(0,0,0,.35); font:700 12px system-ui,sans-serif; cursor:pointer; }
    #hoguomDevToggle:hover { background:#1b5558; }
  `;
  document.head.appendChild(style);

  const toggle = document.createElement("button");
  toggle.id = "hoguomDevToggle";
  toggle.type = "button";
  toggle.textContent = "🛠 DEV";
  toggle.setAttribute("aria-label", "Bật hoặc ẩn Dev Mode");
  document.body.appendChild(toggle);

  const panel = document.createElement("aside");
  panel.id = "hoguomDevPanel";
  panel.className = "hgd-hidden";
  panel.setAttribute("aria-label", "Bảng công cụ kiểm thử");
  panel.innerHTML = `
    <div class="hgd-head"><strong>🛠 DEV MODE</strong><button type="button" data-dev-action="close" aria-label="Ẩn bảng">×</button></div>
    <label for="hoguomDevChapter">Nhảy tới chương</label>
    <div class="hgd-row"><select id="hoguomDevChapter">
      <option value="0">Chương 1</option><option value="1">Chương 2</option><option value="2">Chương 3</option><option value="3">Chương 4</option><option value="4">Chương 5</option><option value="5">Chương 6</option>
    </select><button type="button" data-dev-action="jump">Đi</button></div>
    <label for="hoguomDevBoss">Gọi Boss</label>
    <div class="hgd-row"><select id="hoguomDevBoss"><option value="0">Boss chương hiện tại</option><option value="1">Hắc Long thức tỉnh</option><option value="2">Ma Chủ đoạt kiếm</option></select><button type="button" data-dev-action="boss">Gọi</button></div>
    <div class="hgd-actions">
      <button type="button" data-dev-action="phase">Sang phase 2</button>
      <button type="button" data-dev-action="god">Bất tử: TẮT</button>
      <button type="button" data-dev-action="heal">Hồi 3 mạng</button>
      <button type="button" data-dev-action="victory">Test chiến thắng</button>
      <button type="button" data-dev-action="reset">Reset run</button>
    </div>
    <p id="hoguomDevStatus" role="status">Đã tắt · F8 để ẩn/hiện</p>
    <small>Chỉ phục vụ kiểm thử · không ảnh hưởng khi không dùng</small>`;
  document.body.appendChild(panel);

  let enabled = false;
  let godMode = false;
  const status = (message) => { const el = panel.querySelector("#hoguomDevStatus"); if (el) el.textContent = message; };
  const show = (force) => {
    enabled = typeof force === "boolean" ? force : !enabled;
    panel.classList.toggle("hgd-hidden", !enabled);
    status(enabled ? "Đang bật · F8 để ẩn" : "Đã tắt · F8 để hiện");
  };
  const run = (fn) => { try { status(fn()); } catch (err) { console.error("Dev Mode error:", err); status("Lỗi thao tác — xem Console (F12)"); } };

  toggle.addEventListener("click", () => show());

  window.addEventListener("keydown", (event) => {
    if (event.key !== "F8") return;
    event.preventDefault();
    show();
  });

  panel.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-dev-action]");
    if (!button) return;
    switch (button.dataset.devAction) {
      case "close": show(false); break;
      case "jump": run(() => api.jumpChapter(Number(panel.querySelector("#hoguomDevChapter").value))); break;
      case "boss": run(() => api.spawnBoss(Number(panel.querySelector("#hoguomDevBoss").value))); break;
      case "phase": run(() => api.advanceBossPhase()); break;
      case "god": godMode = api.toggleGodMode(); button.textContent = `Bất tử: ${godMode ? "BẬT" : "TẮT"}`; status(godMode ? "Bất tử đã bật" : "Bất tử đã tắt"); break;
      case "heal": run(() => api.heal()); break;
      case "victory": run(() => api.testVictory()); break;
      case "reset": godMode = false; run(() => api.resetRun()); button.textContent = "Bất tử: TẮT"; show(true); break;
    }
  });
})();
