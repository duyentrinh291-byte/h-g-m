(() => {
  "use strict";

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");
  const $ = (id) => document.getElementById(id);
  // Tọa độ game luôn là 960×540; bitmap theo đúng kích thước CSS và DPR
  // để giữ nét khi đổi kích thước cửa sổ hoặc bật/tắt toàn màn hình.
  const W = 960, H = 540;
  let renderScaleX = 1, renderScaleY = 1;
  function configureCanvasResolution() {
    const rect = canvas.getBoundingClientRect();
    const cssW = Math.max(1, rect.width || W);
    const cssH = Math.max(1, rect.height || H);
    // Giới hạn DPR để tránh bitmap quá lớn gây tốn RAM/GPU trên màn hình 4K.
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const targetW = Math.max(1, Math.round(cssW * dpr));
    const targetH = Math.max(1, Math.round(cssH * dpr));
    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
    }
    renderScaleX = targetW / W;
    renderScaleY = targetH / H;
    ctx.setTransform(renderScaleX, 0, 0, renderScaleY, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
  }
  configureCanvasResolution();
  window.addEventListener("resize", configureCanvasResolution, { passive: true });
  // ResizeObserver xử lý cả thay đổi layout không phát sinh window.resize.
  if ("ResizeObserver" in window) {
    const canvasResizeObserver = new ResizeObserver(configureCanvasResolution);
    canvasResizeObserver.observe(canvas);
  }

  const chapters = [
    {
      name: "Khởi hành", count: 5, speed: 1, hazards: 4,
      goal: "Thu thập 5 linh quang để mở đường tới Tháp Rùa."
    },
    {
      name: "Vượt sóng", count: 7, speed: 1.22, hazards: 6,
      goal: "Thu thập 7 linh quang giữa những dòng nước mạnh hơn."
    },
    {
      name: "Ánh sáng cổ", count: 8, speed: 1.42, hazards: 8,
      goal: "Thu thập 8 linh quang và tìm lối an toàn."
    },
    {
      name: "Tháp Rùa", count: 10, speed: 1.62, hazards: 10,
      goal: "Đánh bại Huyền Quy, sau đó đến Tháp Rùa."
    },
    {
      name: "Pháo đài Thiên Lôi", count: 11, speed: 1.78, hazards: 12,
      goal: "Thu thập 11 linh quang giữa những luồng sét, chuẩn bị tiến vào hồi kết."
    },
    {
      name: "Huyền Thoại Hồ Gươm", count: 13, speed: 1.95, hazards: 14,
      goal: "Thu thập 13 linh quang, đánh bại Hắc Long Thức Tỉnh và Ma Chủ Đoạt Kiếm để bảo vệ thanh kiếm thần."
    }
  ];

  let state = "intro";
  let level = 0, score = 0, lives = 3, collected = 0;
  let best = readBest();
  let lastTime = 0, elapsed = 0, invulnerable = 0, shake = 0;
  let player, player2 = null, relics = [], hazards = [], lotus = null;
  let p2Lives = 3, p2Score = 0, p2Invulnerable = 0, p2ShotCooldown = 0, p2SkillCooldown = 0, p2UltCooldown = 0, p2ShieldTimer = 0;
  // Hiệu ứng thị giác riêng cho người chơi 2, không dùng chung timer hoạt ảnh với người chơi 1.
  let p2SkillFx = { type: "", time: 0, duration: 0, angle: 0 };
  // Combat state riêng của người chơi 2; các hàm chiến đấu bên dưới vẫn là hàm dùng chung với chế độ 1 người.
  let p2CombatState = null;
  let particles = [], ripples = [];
  // Giới hạn hạt theo cấu hình để giữ FPS ổn định khi nhiều hiệu ứng xuất hiện.
  const PARTICLE_LIMIT = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) ? 90 : 170;
  let turrets = [], enemyShots = [], playerShots = [];
  let reedPatches = [], powerup = null, boss = null, hunterFish = [];
  let nextFishAt = 6, fishSpawnedThisLevel = 0;
  let keys = Object.create(null), p2Keys = Object.create(null), soundOn = false, audioCtx = null;
  let gateOpen = false, shotCooldown = 0, shieldTimer = 0;
  // Đánh dấu ngữ cảnh chiến đấu để kỹ năng dùng chung không ghi nhầm trạng thái giữa hai người.
  let activeCombatPlayerIndex = 1;
  // Đánh thường tích lũy của Liên: mỗi viên đạn cơ bản trúng mục tiêu cộng 1 Lôi Ấn.
  let lienCharge = 0, lienChargeIdleTimer = 0;
  // Bộ kỹ năng riêng của Lê Lợi.
  let slashCooldown = 0, phongCooldown = 0, longCooldown = 0, slashFlash = 0, phongFlash = 0, longFlash = 0;
  // F tối thượng của Lê Lợi: Hồn Thiêng Đại Việt. Hoạt ảnh chạy theo timeline, sát thương chỉ kích hoạt một lần ở thời điểm giáng thần.
  let daiVietUltimate = null;
  // R của Lê Lợi: Thiên Kiếm Giáng Thế — đại kiếm tím giáng xuống giữa bầy quái.
  let leLoiSwordUltimate = null;
  // Chiêu cuối riêng của Kim Quy: linh quy khổng lồ dẫn đường cho cú lướt và sóng chấn hải.
  let kimQuyUltimate = null;
  // F riêng của Liên: Liên Hoa Nguyệt Triều — hoa sen nước nở tại điểm ngắm, ít hạt để giữ FPS.
  let lienUltimate = null;
  // F của Liên: Lôi Long Diệt Thế — rồng sét lao dọc hướng ngắm xuyên chiến trường.
  let lienLightningDragon = null;
  let lienFlowerPillar = null;
  const cooldownDurations = () => ({ slash: selectedCharacter === "lien" ? 7 : selectedCharacter === "kimQuy" ? 8 : 12, phong: selectedCharacter === "lien" ? 6 : selectedCharacter === "kimQuy" ? 9 : 5, long: selectedCharacter === "lien" ? 12 : selectedCharacter === "kimQuy" ? 30 : 30 });
  function updateCooldownDisplay() {
    const durations = cooldownDurations();
    [["slash", slashCooldown], ["phong", phongCooldown], ["long", longCooldown]].forEach(([name, value]) => {
      const text = $(name + "CooldownText"), bar = $(name + "CooldownBar");
      if (text) text.textContent = name === "slash" && selectedCharacter === "leLoi" && leLoiEmpowerTimer > 0 ? leLoiEmpowerTimer.toFixed(1) + "s" : value > 0.05 ? value.toFixed(1) + " GIÂY" : "SẴN SÀNG";
      if (bar) bar.style.width = Math.max(0, Math.min(1, 1 - value / durations[name])) * 100 + "%";
    });
    // Hồi chiêu P2 lấy hoàn toàn từ p2CombatState và bộ nhân vật P2.
    const p2Durations = { slash: p2SelectedCharacter === "lien" ? 7 : p2SelectedCharacter === "kimQuy" ? 8 : 12, phong: p2SelectedCharacter === "lien" ? 6 : p2SelectedCharacter === "kimQuy" ? 9 : 5, long: p2SelectedCharacter === "lien" ? 12 : p2SelectedCharacter === "kimQuy" ? 30 : 30 };
    [["slash", "slashCooldown"], ["phong", "phongCooldown"], ["long", "longCooldown"]].forEach(([name, key]) => {
      const value = p2CombatState ? (p2CombatState[key] || 0) : 0;
      const text = $("p2" + name[0].toUpperCase() + name.slice(1) + "CooldownText");
      const bar = $("p2" + name[0].toUpperCase() + name.slice(1) + "CooldownBar");
      if (text) text.textContent = name === "slash" && p2SelectedCharacter === "leLoi" && p2CombatState?.leLoiEmpowerTimer > 0 ? p2CombatState.leLoiEmpowerTimer.toFixed(1) + "s" : value > .05 ? value.toFixed(1) + " GIÂY" : "SẴN SÀNG";
      if (bar) bar.style.width = Math.max(0, Math.min(1, 1 - value / p2Durations[name])) * 100 + "%";
    });
  }

  let bossDefeated = false, nextLotusAt = 8, nextPowerAt = 12;
  // Chuỗi chém riêng của Kim Quy: tăng sức mạnh khi đánh liên tiếp, tự nguội sau 1 giây.
  let kimQuyCombo = 0, kimQuyComboTimer = 0;
  // Đánh thường tích lũy riêng Lê Lợi: ba nhịp kiếm tăng dần, nhịp thứ ba phóng kiếm khí Thuận Thiên cường hóa.
  let leLoiCombo = 0, leLoiComboTimer = 0;
  // E Lê Lợi: cường hóa trong 5 giây, bắn ba kiếm khí cùng lúc.
  let leLoiEmpowerTimer = 0;
  // Các đợt cá riêng cho trận Boss: luôn chỉ có tối đa 1 cá trên màn hình.
  let bossFishWave = 0, bossFishRemaining = 0, bossFishSpawnTimer = 0;

  const difficultySettings = {
    easy: {
      enemySpeed: 0.8,
      enemyFire: 1.3,
      bossHp: 120,
      bossFire: 1.15
    },
    normal: {
      enemySpeed: 1,
      enemyFire: 1,
      bossHp: 300,
      bossFire: 0.92
    },
    hard: {
      enemySpeed: 1.3,
      enemyFire: 0.7,
      bossHp: 520,
      bossFire: 0.58
    },
    hell: {
      enemySpeed: 1.75,
      enemyFire: 0.48,
      bossHp: 720,
      bossFire: 0.38
    }
  };

  let difficulty = "normal";
  // Hook bất tử được điều khiển bởi file dev-mode.js; mặc định luôn tắt.
  let devGodMode = false;
  let p2DevGodMode = false; // Chỉ tác động P2 trong Dev Mode 2P.


  // Giữ nguyên hệ thống nâng cấp của game.js, nhưng lưu bộ chỉ số riêng cho từng người.
  // `upgrades` là bộ của P1; khi chạy hàm chiến đấu dùng chung cho P2, context sẽ hoán đổi sang p2Upgrades.
  const createUpgradeSet = () => ({ speed: 0, power: 0, fire: 0, shield: 0 });
  let upgrades = createUpgradeSet();
  let p2Upgrades = createUpgradeSet();

  const upgradeCosts = {
    speed: [335, 530, 795, 1125, 1450],
    power: [405, 665, 990, 1325, 1850],
    fire: [460, 725, 1060, 1450, 1990],
    shield: [300, 500, 750, 1000, 1300]
  };

  function upgradeCost(type, playerIndex = 1) {
    const set = playerIndex === 2 ? p2Upgrades : upgrades;
    return upgradeCosts[type]?.[set[type]] ?? Infinity;
  }

  function playerUpgradePoints(playerIndex = 1) {
    // score là tổng điểm hành trình; p2Score là phần được ghi nhận cho P2.
    return playerIndex === 2 ? p2Score : Math.max(0, score - p2Score);
  }

  function refreshUpgradeUI() {
    const labels = { speed: "⚡ Tốc độ", power: "⚔️ Sát thương", fire: "➶ Tốc độ bắn", shield: "🛡️ Khiên" };
    [1, 2].forEach(playerIndex => {
      const points = document.querySelector(`#chapterUpgradePointsP${playerIndex}`);
      if (points) points.textContent = `Điểm nâng cấp P${playerIndex}: ${playerUpgradePoints(playerIndex)}`;
      document.querySelectorAll(`#chapterUpgradeChoices [data-upgrade-player="${playerIndex}"]`).forEach(button => {
        const cost = upgradeCost(button.dataset.upgrade, playerIndex);
        button.disabled = !Number.isFinite(cost) || playerUpgradePoints(playerIndex) < cost;
        button.textContent = Number.isFinite(cost) ? `${labels[button.dataset.upgrade]} · ${cost} điểm` : `${labels[button.dataset.upgrade]} · ĐÃ TỐI ĐA`;
      });
    });
  }

  function buyUpgrade(type, playerIndex = 1) {
    // Tái sử dụng cùng bảng giá/quy tắc nâng cấp của game.js cho cả hai người.
    if (state !== "chapterDone") return;
    const cost = upgradeCost(type, playerIndex);
    if (!Number.isFinite(cost) || playerUpgradePoints(playerIndex) < cost) {
      playTone(180, 0.08);
      return;
    }

    if (playerIndex === 2) {
      // Trừ đồng thời tổng điểm và điểm P2 để không làm thay đổi ngân sách của P1.
      score -= cost;
      p2Score -= cost;
      p2Upgrades[type]++;
    } else {
      score -= cost;
      upgrades[type]++;
    }

    // Cập nhật tốc độ ngay trong chương kế tiếp; nhân vật hiện tại cũng được đồng bộ.
    if (player && playerIndex === 1) player.speed = 210 * (1 + Math.min(upgrades.speed, 5) * 0.07);
    if (player2 && playerIndex === 2) player2.speed = 205 * (1 + Math.min(p2Upgrades.speed, 5) * 0.07);
    refreshUpgradeUI();
    updateHUD();
    playTone(820, 0.1);
  }

  function readBest() {
    try {
      return Number(localStorage.getItem("hoGuomBest") || 0);
    } catch (_) {
      return 0;
    }
  }

  function saveBest() {
    if (score > best) {
      best = score;
      try {
        localStorage.setItem("hoGuomBest", String(best));
      } catch (_) { }
    }
    $("best").textContent = String(best).padStart(4, "0");
  }

  function rand(min, max) {
    return min + Math.random() * (max - min);
  }

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function distance(a, b) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  function resetUpgrades() {
    upgrades = createUpgradeSet();
    p2Upgrades = createUpgradeSet();
    refreshUpgradeUI();
  }

  let modeConfirmed = false;
  function setMode(mode) {
    if (!difficultySettings[mode]) return;
    difficulty = mode;
    modeConfirmed = false;
    const confirmModeBtn = $("confirmModeBtn");
    if (confirmModeBtn) { confirmModeBtn.classList.remove("is-confirmed"); confirmModeBtn.innerHTML = 'Xác nhận chế độ <span>→</span>'; }
    const modeConfirmStatus = $("modeConfirmStatus");
    if (modeConfirmStatus) modeConfirmStatus.textContent = 'Đã chọn độ khó · hãy xác nhận để khóa lựa chọn';
    $("difficultySelect").value = mode;
    document.querySelectorAll("[data-mode]").forEach(button => {
      const selected = button.dataset.mode === mode;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
    const names = { easy: "THƯ THÁI", normal: "PHIÊU LƯU", hard: "HUYỀN THOẠI", hell: "ĐỊA NGỤC" };
    $("modeStatus").textContent = `ĐANG CHỌN: ${names[mode]}`;
  }

  function resetGame() {
    p2Lives = 3; p2Score = 0; player2 = null; p2CombatState = null;
    resetUpgrades();

    level = 0;
    score = 0;
    lives = 3;
    collected = 0;

    setupLevel(0);
    state = "playing";

    $("overlay").classList.add("hidden");
    $("pauseBtn").disabled = false;
    $("pauseBtn").textContent = "Ⅱ Tạm dừng";
    $("statusLabel").textContent = "ĐANG HÀNH TRÌNH";

    updateHUD();
    playTone(520, 0.07);
  }

  function setupLevel(index) {
    level = index;
    const chapter = chapters[level];

    collected = 0;
    gateOpen = false;
    elapsed = 0;
    invulnerable = 1.2;

    player = {
      x: 92, y: H / 2, r: 13, speed: 210 * (1 + Math.min(upgrades.speed, 5) * 0.07),
      trail: [], aimX: 1, aimY: 0
    };
    player2 = { x: 132, y: H / 2 + 58, r: 13, speed: 205 * (1 + Math.min(p2Upgrades.speed, 5) * 0.07), trail: [], aimX: 1, aimY: 0, color: "#62e9ff" };
    p2Invulnerable = 1.5; p2ShotCooldown = 0; p2SkillCooldown = 0; p2UltCooldown = 0;
    p2CombatState = { shotCooldown: 0, slashCooldown: 0, phongCooldown: 0, longCooldown: 0, slashFlash: 0, phongFlash: 0, longFlash: 0, shieldTimer: 0, lienCharge: 0, lienChargeIdleTimer: 0, kimQuyCombo: 0, kimQuyComboTimer: 0, leLoiCombo: 0, leLoiComboTimer: 0, leLoiEmpowerTimer: 0, invulnerable: 1.5, daiVietUltimate: null, leLoiSwordUltimate: null, kimQuyUltimate: null, lienUltimate: null, lienLightningDragon: null, lienFlowerPillar: null };

    relics = [];
    hazards = [];
    particles = [];
    ripples = [];
    turrets = [];
    enemyShots = [];
    playerShots = [];
    reedPatches = [];
    lotus = null;
    powerup = null;
    boss = null;
    bossDefeated = false;
    shieldTimer = 0;
    p2ShieldTimer = 0;
    shotCooldown = 0;
    lienCharge = 0; lienChargeIdleTimer = 0;
    leLoiCombo = 0; leLoiComboTimer = 0;
    slashCooldown = 0; phongCooldown = 0; longCooldown = 0; slashFlash = 0; phongFlash = 0; longFlash = 0; leLoiEmpowerTimer = 0; daiVietUltimate = null; leLoiSwordUltimate = null; kimQuyUltimate = null; lienUltimate = null; lienLightningDragon = null; lienFlowerPillar = null;
    kimQuyCombo = 0; kimQuyComboTimer = 0; updateCooldownDisplay();
    nextLotusAt = 7 + level * 1.5;
    nextPowerAt = 12 + level * 1.5;
    hunterFish = [];
    fishSpawnedThisLevel = 0;
    nextFishAt = difficulty === "hell" ? 3.5 : 6;

    // Giảm xoáy nước ở các màn boss: tối đa 3 xoáy để chừa không gian né đòn.
    const whirlpoolCount = level >= 3
      ? Math.min(3, Math.max(2, Math.ceil(chapter.hazards * 0.25)))
      : Math.max(3, Math.ceil(chapter.hazards * 0.6));
    for (let i = 0; i < whirlpoolCount; i++) {
      const p = randomOpenPoint(100);
      hazards.push({
        x: p.x, y: p.y, r: rand(17, 24),
        phase: rand(0, 6.28),
        vx: rand(-25, 25) * chapter.speed,
        vy: rand(-22, 22) * chapter.speed,
        wobble: rand(15, 35), baseX: p.x, baseY: p.y
      });
    }

    // Hoa sen địch có thể bắn đạn về phía người chơi.
    const turretCount = level === 0 ? 1 : Math.min(3, level + 1);

    for (let i = 0; i < turretCount; i++) {
      const p = randomOpenPoint(130);
      // Hoa sen trâu hơn để người chơi cần ưu tiên mục tiêu tầm xa.
      const hp = level >= 2 ? 18 : 14;

      turrets.push({
        x: p.x, y: p.y, r: 18,
        hp, maxHp: hp,
        phase: rand(0, 6.28),
        fireTimer: rand(1.2, 2.2),
        flash: 0
      });
    }

    // Bụi lau gai: chướng ngại vật đứng yên.
    for (let i = 0; i < 1 + Math.floor(level / 2); i++) {
      const p = randomOpenPoint(85);
      reedPatches.push({
        x: p.x, y: p.y,
        r: 19 + rand(0, 5),
        phase: rand(0, 6.28)
      });
    }

    // Tạo linh quang sau khi đã đặt bụi lau gai, tránh để vật phẩm
    // xuất hiện chồng lên vùng gai. Giữ khoảng cách an toàn quanh bụi gai.
    for (let i = 0; i < chapter.count; i++) {
      let p = randomOpenPoint(95);
      let attempts = 0;
      const relicRadius = 10;
      const safeGap = 12;

      while (
        attempts < 100 &&
        reedPatches.some(reed =>
          distance(p, reed) < relicRadius + reed.r * 0.72 + safeGap
        )
      ) {
        p = randomOpenPoint(95);
        attempts++;
      }

      relics.push({
        x: p.x, y: p.y, r: relicRadius,
        phase: rand(0, Math.PI * 2), got: false
      });
    }

    updateHUD();
    updateBossHUD();
    updateChapterList();

    $("chapterLabel").textContent =
      `Chương ${level + 1} · ${chapter.name}`;
    $("goalText").textContent = chapter.goal;
    $("statusLabel").textContent = "ĐANG HÀNH TRÌNH";
  }

  function randomOpenPoint(margin) {
    let p, attempts = 0;

    do {
      p = {
        x: rand(margin, W - margin),
        y: rand(82, H - 55)
      };
      attempts++;
    } while (
      attempts < 80 &&
      (
        (player && distance(p, player) < 95) ||
        (p.x > W - 120 &&
          p.y > H * .32 && p.y < H * .68)
      )
    );

    return p;
  }

  function updateHUD() {
    if ($("score")) $("score").textContent = String(score).padStart(4, "0");
    $("relics").textContent = `${collected} / ${chapters[level].count}`;
    if ($("lives")) $("lives").textContent = lives > 0 ? "♥ ".repeat(lives).trim() : "—";
    $("level").textContent = `${level + 1} / ${chapters.length}`;
    $("best").textContent = String(best).padStart(4, "0");
    refreshUpgradeUI();
  }

  let previousBossHudState = "";
  function updateBossHUD() {
    const hud = $("bossHud");
    if (!hud) return;

    const active = !!boss && !boss.defeated;
    if (!active) {
      if (previousBossHudState !== "inactive") hud.classList.add("hidden");
      previousBossHudState = "inactive";
      return;
    }

    const hp = Math.max(0, boss.hp);
    const bossLabel = document.querySelector(".boss-hud-label strong");
    if (bossLabel) bossLabel.textContent = boss.stage
      ? `${boss.name} · Giai đoạn ${boss.stage}/2`
      : "Huyền Quy cầm kiếm · Trùm cuối";
    const hpText = `${hp} / ${boss.maxHp}`;
    const hpWidth = `${Math.max(0, hp / boss.maxHp * 100)}%`;
    const key = `${hpText}|${hpWidth}`;
    if (key !== previousBossHudState) {
      hud.classList.remove("hidden");
      $("bossCount").textContent = hpText;
      $("bossHealthFill").style.width = hpWidth;
      previousBossHudState = key;
    }
  }

  function spawnBoss(stage = (level === chapters.length - 1 ? 1 : 0)) {

    const setting = difficultySettings[difficulty];
    const finalChapter = level === chapters.length - 1;
    const finalStage = finalChapter ? Math.max(1, stage) : 0;
    const bossForm = finalStage === 1 ? "dragon" : finalStage === 2 ? "demon" : "turtle";
    const bossName = finalStage === 1 ? "Hắc Long Thức Tỉnh" : finalStage === 2 ? "Ma Chủ Đoạt Kiếm" : "Huyền Quy cầm kiếm";
    const bossHp = finalStage === 1 ? setting.bossHp * 2 : finalStage === 2 ? setting.bossHp * 2.5 : setting.bossHp * 3;
    bossFishWave = 0;
    bossFishRemaining = 0;
    bossFishSpawnTimer = 1.0;
    hunterFish = []; // Không để cá của màn trước làm sai điều kiện spawn.

    boss = {
      x: W - 205,
      y: H / 2,
      r: finalStage ? (finalStage === 1 ? 52 : 47) : 48,
      hp: bossHp,
      maxHp: bossHp,
      stage: finalStage,
      form: bossForm,
      name: bossName,
      phase: 0,
      shootTimer: (finalStage === 2 ? .82 : finalStage === 1 ? 1.0 : 1.1) * setting.bossFire,
      burstRemaining: 0,
      burstTimer: 0,
      flash: 0,
      defeated: false,
      transformed: false,
      transformTimer: 0,
      laserCooldown: finalStage === 2 ? 1.8 : finalStage === 1 ? 2.6 : 2.2,
      laserTelegraph: 0,
      laserActive: 0,
      laserAngle: 0,
      laserSweep: 0,
      chargeCooldown: 5,
      chargeState: "idle",
      chargeTimer: 0,
      chargeAngle: 0,
      chargeCount: 0,
      chargeOriginX: W - 205,
      chargeOriginY: H / 2,
      // Chiêu riêng của boss: báo trước rồi tung đòn theo hướng người chơi.
      specialCooldown: finalStage === 1 ? 4.8 : 6.2,
      specialTelegraph: 0,
      specialAngle: 0,
      specialType: "breath",
      dragonAttackIndex: 0,
      dragonStrafe: Math.random() < .5 ? -1 : 1,
      // Cơ chế di chuyển riêng của Ma Chủ Đoạt Kiếm.
      demonOrbit: Math.random() < .5 ? -1 : 1,
      demonTeleportCooldown: 3.8,
      demonTeleportTimer: 0,
      demonTeleportX: W * .62,
      demonTeleportY: H * .5,
      demonAfterimageTimer: 0,
      demonMoveAngle: 0,
      // Bộ ba kỹ năng riêng của Ma Chủ Đoạt Kiếm.
      demonSkillCooldown: 2.8,
      demonSkill: "idle",
      demonSkillTimer: 0,
      demonSkillStep: 0,
      demonSkillAngle: 0,
      demonSkillSwords: [],
      demonZones: [],
      demonZoneIndex: 0,
      demonSwordMode: "guard",
      demonSwordModeTimer: 0
    };

    gateOpen = false;
    enemyShots = [];
    updateBossHUD();

    $("goalText").textContent = finalStage === 1
      ? "Hạ Hắc Long Thức Tỉnh! Né luồng hắc viêm và các bóng ma canh giữ thanh kiếm thần."
      : finalStage === 2
        ? "Ma Chủ Đoạt Kiếm đã xuất hiện! Né kiếm trận, đánh bại hắn để khôi phục bình yên cho Hồ Gươm."
        : "Hạ Huyền Quy bằng tia kiếm (Space), sau đó tiến đến Tháp Rùa.";
    $("statusLabel").textContent = finalStage ? `BOSS ${finalStage}/2 XUẤT HIỆN` : "BOSS XUẤT HIỆN";

    showOverlay(
      finalStage === 1 ? "HỒI KẾT · GIAI ĐOẠN 1/2" : finalStage === 2 ? "HỒI KẾT · GIAI ĐOẠN 2/2" : "TRÙM CUỐI XUẤT HIỆN",
      finalStage === 1 ? "Hắc Long Thức Tỉnh" : finalStage === 2 ? "Ma Chủ Đoạt Kiếm" : "Huyền Quy thức tỉnh!",
      finalStage === 1
        ? "Hắc Long trỗi dậy từ đáy hồ. Né hắc viêm và đánh bại nó; các bóng ma của những Boss cũ sẽ xuất hiện theo từng mốc máu."
        : finalStage === 2
          ? "Ma Chủ đã cướp lấy kiếm thần! Hộ vệ kiếm thần sẽ tràn vào đấu trường. Đây là trận chiến cuối cùng — hãy dùng kỹ năng đúng lúc."
          : "Nhấn giữ Space để phóng kiếm quang. Né đạn của Huyền Quy và hoa sen địch, sau đó đánh bại boss.",
      finalStage === 1 ? "Đối đầu Hắc Long" : finalStage === 2 ? "Đối đầu Ma Chủ" : "Đối đầu Huyền Quy",
      finalStage === 1 ? "🐉" : finalStage === 2 ? "👑" : "🐢"
    );

    state = "bossIntro";
    $("pauseBtn").disabled = true;
    burst(boss.x, boss.y, "#85e4dd", 32);
    playTone(110, .35);
  }

  // Chọn người chơi còn sống gần một thực thể nhất; dùng chung cho quái săn đuổi.
  function getNearestLivingPlayer(from) {
    const candidates = [];
    if (player && lives > 0) candidates.push({ ref: player, index: 1 });
    if (player2 && p2Lives > 0) candidates.push({ ref: player2, index: 2 });
    let best = null, bestDistance = Infinity;
    for (const candidate of candidates) {
      const d = Math.hypot(candidate.ref.x - from.x, candidate.ref.y - from.y);
      if (d < bestDistance) { best = candidate; bestDistance = d; }
    }
    return best;
  }

  function aimTarget() {
    // Chọn mục tiêu gần nhất so với nhân vật đang được bind trong combat context.
    let target = null;
    let nearest = Infinity;
    const candidates = [];
    if (boss && !boss.defeated) candidates.push(boss);
    turrets.forEach(t => { if (t && (t.hp == null || t.hp > 0)) candidates.push(t); });
    hunterFish.forEach(f => { if (f && (f.hp == null || f.hp > 0)) candidates.push(f); });
    const aimingPlayer = activeCombatPlayerIndex === 2 && player2 ? player2 : player;
    candidates.forEach(candidate => {
      const d = distance(aimingPlayer, candidate);
      if (d < nearest) { target = candidate; nearest = d; }
    });
    return target;
  }

  // P1 và P2 đều khóa hướng đánh vào kẻ địch gần nhất theo vị trí của chính mình.
  function aimP1AtNearestTarget() {
    if (!player) return false;
    const target = aimTarget();
    if (!target) return false;
    const dx = target.x - player.x, dy = target.y - player.y;
    const len = Math.hypot(dx, dy);
    if (len > 0.001) { player.aimX = dx / len; player.aimY = dy / len; }
    return true;
  }

  // Tự hướng đòn đánh thường của P2 vào kẻ địch gần nhất, nhưng vẫn giữ
  // nguyên hàm firePlayerShot và toàn bộ cơ chế combo/nâng cấp theo nhân vật.
  function aimP2AtNearestTarget() {
    if (!player2) return false;
    const target = aimTarget();
    if (!target) return false;
    const dx = target.x - player2.x, dy = target.y - player2.y;
    const len = Math.hypot(dx, dy);
    if (len > 0.001) { player2.aimX = dx / len; player2.aimY = dy / len; }
    return true;
  }

  function firePlayerShot() {
    if (state !== "playing" || shotCooldown > 0) return;
    if ((activeCombatPlayerIndex === 1 && lives <= 0) || (activeCombatPlayerIndex === 2 && p2Lives <= 0)) return;

    shotCooldown = Math.max(
      0.12,
      Math.max(0.25, 0.34 * (1 - Math.min(upgrades.fire, 5) * 0.07)) * (selectedCharacter === "leLoi" && leLoiEmpowerTimer > 0 ? 0.88 : 1)
    );

    // Liên: đủ 6 Lôi Ấn thì đòn đánh thường kế tiếp phóng sáu cầu điện theo cung 60 độ.
    if (selectedCharacter === "lien" && lienCharge >= 6) {
      const dx0 = player.aimX || 1, dy0 = player.aimY || 0;
      const len0 = Math.hypot(dx0, dy0) || 1;
      const baseAngle = Math.atan2(dy0 / len0, dx0 / len0);
      const spread = Math.PI / 3;
      for (let i = 0; i < 6; i++) {
        const angle = baseAngle - spread / 2 + spread * i / 5;
        const dx = Math.cos(angle), dy = Math.sin(angle);
        playerShots.push({
          x: player.x + dx * 23, y: player.y + dy * 23,
          vx: dx * 430, vy: dy * 430, r: 11, life: 1.8,
          damage: (1 + upgrades.power * 0.6 + 0.25) * 0.65,
          color: "#63f7ff", waterOrb: true, lienChargeBurst: true, trail: true
        });
        burst(player.x + dx * 24, player.y + dy * 24, i % 2 ? "#a5ffff" : "#63f7ff", 5);
      }
      lienCharge = 0;
      lienChargeIdleTimer = 0;
      shake = Math.max(shake, 2.6);
      playTone(940, .16);
      return;
    }

    // Kim Quy: dùng đúng cơ chế đánh thường của game.js chơi đơn.
    // Hàm này được gọi trong withPlayerTwoContext nên player/upgrades/combo/cooldown
    // đang là bộ riêng của P2; chỉ mảng đạn và thế giới được dùng chung.
    if (selectedCharacter === "kimQuy") {
      // Chuỗi đánh thường Kim Quy có thời hạn riêng cho từng người chơi.
      // withPlayerTwoContext sẽ lưu timer này vào p2CombatState, không đụng dữ liệu P1.
      kimQuyCombo = (kimQuyCombo % 3) + 1;
      kimQuyComboTimer = 1.35;
      const tier = kimQuyCombo;
      let dx = player.aimX || 1, dy = player.aimY || 0;
      const len = Math.hypot(dx, dy) || 1; dx /= len; dy /= len;
      const damage = (1.15 + upgrades.power * 0.39) * [1, 1.2, 1.45][tier - 1];
      const speed = 420 + tier * 12;
      playerShots.push({
        x: player.x + dx * 20, y: player.y + dy * 20,
        vx: dx * speed, vy: dy * speed,
        r: [8, 12, 16][tier - 1], life: [1.25, 1.4, 1.55][tier - 1],
        damage, color: tier === 3 ? "#efffff" : "#42f5cf",
        waterOrb: true, kimQuyEmpowered: true, comboLevel: tier, piercing: tier === 3
      });
      burst(player.x + dx * 18, player.y + dy * 18,
        tier === 3 ? "#cafffb" : "#42f5cf", 5 + tier * 3);
      playTone(520 + tier * 90, .05 + tier * .012);
      return;
    }
    // Lê Lợi: đánh thường tích lũy theo chuỗi 3 nhịp; nhịp thứ ba tung kiếm khí Thuận Thiên mạnh hơn.
    if (selectedCharacter === "leLoi") {
      leLoiCombo = (leLoiCombo % 3) + 1;
      leLoiComboTimer = 1.35;
      const tier = leLoiCombo;
      let dx = player.aimX || 1, dy = player.aimY || 0;
      const len = Math.hypot(dx, dy) || 1; dx /= len; dy /= len;
      const speed = tier === 3 ? 560 : 455;
      const isEEmpowered = leLoiEmpowerTimer > 0;
      const comboMultiplier = [1, 1.2, 1.65][tier - 1];
      // Trong E, sát thương mỗi kiếm khí được giới hạn tối đa 130% sát thương cơ bản.
      const damageMultiplier = isEEmpowered ? Math.min(comboMultiplier * 1.12, 1.3) : comboMultiplier;
      const damage = (1 + upgrades.power * 0.6) * damageMultiplier;
      const spreadAngles = isEEmpowered ? [-0.13, 0, 0.13] : [0];
      spreadAngles.forEach(offset => {
        const a = Math.atan2(dy, dx) + offset;
        const sx = Math.cos(a), sy = Math.sin(a);
        playerShots.push({
          x: player.x + sx * (tier === 3 ? 24 : 15), y: player.y + sy * (tier === 3 ? 24 : 15),
          vx: sx * speed, vy: sy * speed,
          r: tier === 3 ? 15 : tier === 2 ? 7 : 5,
          life: tier === 3 ? 1.7 : 1.35, damage,
          color: isEEmpowered ? (tier === 3 ? "#a78bfa" : "#45e8ff") : (tier === 3 ? "#fff4b0" : tier === 2 ? "#ffd86b" : "#fff0b3"),
          leLoiEmpowered: true, leLoiEBoost: isEEmpowered, comboLevel: tier, piercing: tier === 3, trail: tier === 3
        });
      });
      burst(player.x + dx * 19, player.y + dy * 19,
        tier === 3 ? "#fff6c4" : tier === 2 ? "#ffd86b" : "#fff0b3", tier === 3 ? 15 : 5 + tier * 2);
      if (tier === 3) {
        for (let i = 0; i < 8; i++) {
          const side = (i - 3.5) * 0.12;
          burst(player.x + dx * 30 - dy * side * 30, player.y + dy * 30 + dx * side * 30,
            i % 2 ? "#fff0a0" : "#ffffff", 2);
        }
        shake = Math.max(shake, 3.2);
      }
      playTone(tier === 3 ? 960 : 620 + tier * 90, tier === 3 ? .13 : .06);
      return;
    }
    // Bắn theo hướng con trỏ chuột, không tự khóa mục tiêu.
    let dx = player.aimX || 1;
    let dy = player.aimY || 0;
    const aimLength = Math.hypot(dx, dy) || 1;
    dx /= aimLength;
    dy /= aimLength;

    const damage = 1 + upgrades.power * 0.6;
    const shotCount = upgrades.power >= 2 ? 3 : 1;
    const baseAngle = Math.atan2(dy, dx);

    for (let i = 0; i < shotCount; i++) {
      const offset = (i - (shotCount - 1) / 2) * 0.13;
      const angle = baseAngle + offset;

      playerShots.push({
        x: player.x + Math.cos(angle) * 15,
        y: player.y + Math.sin(angle) * 15,
        vx: Math.cos(angle) * 455,
        vy: Math.sin(angle) * 455,
        r: selectedCharacter === "lien" ? 7 : (selectedCharacter === "kimQuy" ? 8 : 5),
        life: selectedCharacter === "lien" ? 1.5 : (selectedCharacter === "kimQuy" ? 1.7 : 1.35),
        damage: selectedCharacter === "lien" ? damage + 0.65 : (selectedCharacter === "kimQuy" ? damage + 0.15 : damage),
        color: selectedCharacter === "lien" ? "#62f5df" : (selectedCharacter === "kimQuy" ? "#55e6c2" : "#fff0b3"),
        waterOrb: selectedCharacter === "lien" || selectedCharacter === "kimQuy",
        lienBasicAttack: selectedCharacter === "lien"
      });
    }

    burst(
      player.x + dx * 13,
      player.y + dy * 13,
      selectedCharacter === "lien" ? "#62f5df" : (selectedCharacter === "kimQuy" ? "#55e6c2" : "#fff0b3"),
      selectedCharacter === "lien" || selectedCharacter === "kimQuy" ? 6 : 3
    );

    playTone(720, .045);
  }

  // E của Liên — Lôi Châu: phóng 6 quả cầu điện theo hình vòng cung.
  // Mỗi quả cầu đều gây sát thương và phóng điện sang các đối thủ ở gần điểm va chạm.
  function lienShockOrbSkill() {
    if (state !== "playing" || slashCooldown > 0) return;
    slashCooldown = 7;
    const ax = player.aimX || 1, ay = player.aimY || 0;
    const len = Math.hypot(ax, ay) || 1, baseAngle = Math.atan2(ay / len, ax / len);
    const count = 6;
    const spread = Math.PI / 3; // tổng góc vòng cung 60 độ
    for (let i = 0; i < count; i++) {
      const angle = baseAngle - spread / 2 + (spread * i) / (count - 1);
      const dx = Math.cos(angle), dy = Math.sin(angle);
      const x = player.x + dx * 25, y = player.y + dy * 25;
      playerShots.push({
        x, y, vx: dx * 430, vy: dy * 430, r: 13, life: 2.1, damage: 2.4,
        color: "#8ffcff", waterOrb: true, lienShockOrb: true, trail: true
      });
      burst(x, y, "#a5ffff", 5);
      for (let j = 0; j < 3; j++) {
        const sparkAngle = angle + (j - 1) * .7;
        burst(x + Math.cos(sparkAngle) * 12, y + Math.sin(sparkAngle) * 12,
          j % 2 ? "#62f5df" : "#ffffff", 1);
      }
    }
    shake = Math.max(shake, 1.8);
    playTone(900, .14);
    updateHUD();
  }

  // Ghi nhận tối đa một Lôi Ấn cho mỗi viên đánh thường của Liên, dù đạn xuyên trúng nhiều mục tiêu.
  function registerLienBasicHit(shot) {
    if (!shot || !shot.lienBasicAttack || shot.lienChargeRegistered) return;
    const isP2Shot = !!shot.coOpShot;
    if (isP2Shot) {
      if (p2SelectedCharacter !== "lien" || !p2CombatState) return;
      shot.lienChargeRegistered = true;
      p2CombatState.lienCharge = Math.min(6, p2CombatState.lienCharge + 1);
      p2CombatState.lienChargeIdleTimer = 0;
      burst(player2?.x ?? shot.x, player2?.y ?? shot.y, "#63f7ff", p2CombatState.lienCharge === 6 ? 12 : 4);
      if (p2CombatState.lienCharge === 6) { playTone(1050, .1); shake = Math.max(shake, 1.2); }
      return;
    }
    if (selectedCharacter !== "lien") return;
    shot.lienChargeRegistered = true;
    lienCharge = Math.min(6, lienCharge + 1);
    lienChargeIdleTimer = 0;
    burst(player.x, player.y, "#63f7ff", lienCharge === 6 ? 12 : 4);
    if (lienCharge === 6) { playTone(1050, .1); shake = Math.max(shake, 1.2); }
  }

  // Điện lan trong bán kính ngắn quanh điểm va chạm. Tia điện có thể chạm nhiều mục tiêu.
  function lienShockBurst(x, y) {
    const radius = 112;
    let hitCount = 0;
    const hitTarget = target => Math.hypot(target.x - x, target.y - y) <= radius + (target.r || 10);
    turrets = turrets.filter(t => {
      if (!hitTarget(t) || hitCount >= 4) return true;
      hitCount++; t.hp -= 1.4; t.flash = .28;
      burst(t.x, t.y, "#9fffff", 7);
      if (t.hp <= 0) { score += 150; burst(t.x, t.y, "#8ffcff", 15); return false; }
      return true;
    });
    hunterFish = hunterFish.filter(f => {
      if (!hitTarget(f) || hitCount >= 4) return true;
      hitCount++; f.hp -= 1.4; f.flash = .28;
      burst(f.x, f.y, "#9fffff", 7);
      if (f.hp <= 0) { score += 100; burst(f.x, f.y, "#8ffcff", 15); return false; }
      return true;
    });
    if (boss && !boss.defeated && hitTarget(boss)) {
      // Boss chịu sát thương điện vừa phải, không bị hạ quá nhanh.
      boss.hp = Math.max(0, boss.hp - 1); boss.flash = .24;
      score += 10; updateBossHUD();
      // Vòng xử lý va chạm chính sẽ kết thúc Boss nếu lượng máu vừa chạm 0.
    }
    // Tia sét ngoằn ngoèo vẽ bằng các hạt sáng nối về những kẻ địch vừa trúng.
    burst(x, y, "#dfffff", 18);
    playTone(1040, .09);
    updateHUD();
  }

  // Liên Hoa — kỹ năng riêng của Liên: đóa sen nước nở thành 5 cánh đạn phép.
  // Không dùng kiếm khí Thuận Thiên của Lê Lợi.
  function lienHoaSkill() {
    if (state !== "playing" || slashCooldown > 0) return;
    slashCooldown = 7;
    const ax = player.aimX || 1, ay = player.aimY || 0;
    const base = Math.atan2(ay, ax);
    const colors = ["#e9ffff", "#70fff0", "#54cfff", "#c5a7ff", "#7df7db"];
    // Tạo đóa sen sáng trước khi bung cánh.
    burst(player.x, player.y, "#75fff0", 24);
    for (let i = 0; i < 5; i++) {
      const angle = base + (i - 2) * 0.19;
      const dx = Math.cos(angle), dy = Math.sin(angle);
      playerShots.push({
        x: player.x + dx * 24, y: player.y + dy * 24,
        vx: dx * 570, vy: dy * 570,
        r: 17, life: 1.55, damage: 2,
        piercing: true, color: colors[i], trail: true,
        waterOrb: true, lotusPetal: true
      });
    }
    // Vòng cánh hoa xoay và ánh sáng ngọc lam — hiệu ứng riêng cho Liên.
    for (let i = 0; i < 16; i++) {
      const a = i * Math.PI * 2 / 16;
      const d = 18 + (i % 3) * 7;
      burst(player.x + Math.cos(a) * d, player.y + Math.sin(a) * d,
        i % 2 ? "#70fff0" : "#e9ffff", 2);
    }
    shake = Math.max(shake, 2.5);
    playTone(820, .16);
    updateHUD();
  }

  function thuanThienSlash() {
    if ((activeCombatPlayerIndex === 1 && lives <= 0) || (activeCombatPlayerIndex === 2 && p2Lives <= 0)) return;
    if (selectedCharacter === "leLoi") {
      if (state !== "playing" || slashCooldown > 0) return;
      // E — Thuận Thiên Cường Hóa: 5 giây bắn ba kiếm khí, tăng nhẹ tốc đánh và sát thương.
      leLoiEmpowerTimer = 5;
      slashCooldown = 12;
      slashFlash = .45;
      burst(player.x, player.y, "#fff0a0", 24);
      for (let i = 0; i < 18; i++) {
        const a = i * Math.PI * 2 / 18;
        burst(player.x + Math.cos(a) * 24, player.y + Math.sin(a) * 24,
          i % 2 ? "#ffd86b" : "#ffffff", 2);
      }
      shake = Math.max(shake, 2.2);
      playTone(760, .18);
      updateHUD();
      return;
    }
    if (selectedCharacter === "kimQuy") {
      if (state !== "playing" || slashCooldown > 0) return;
      // E KIM QUY — Long Quy Triều Trảm: năm mũi thủy kiếm hình vây rùa
      // xoè thành quạt rồi lao xuyên màn hình; hoạt ảnh hoàn toàn mới, không còn mai rùa/vòng lục giác.
      slashCooldown = 8;
      invulnerable = Math.max(invulnerable, .45);
      slashFlash = .28;
      const cx = player.x, cy = player.y;
      const aimLen = Math.hypot(player.aimX || 1, player.aimY || 0) || 1;
      const ax = (player.aimX || 1) / aimLen, ay = (player.aimY || 0) / aimLen;
      const base = Math.atan2(ay, ax);
      const bladeCount = 5;
      burst(cx, cy, "#dfffff", 22);
      // Xoáy nước ngắn tại chân, sau đó năm lưỡi kiếm vút ra theo hình quạt.
      for (let i = 0; i < 24; i++) {
        const a = i * Math.PI * 2 / 24;
        const r = 18 + (i % 3) * 5;
        burst(cx + Math.cos(a) * r, cy + Math.sin(a) * r,
          i % 3 === 0 ? "#fff0a6" : "#55e6c2", 1);
      }
      for (let i = 0; i < bladeCount; i++) {
        const angle = base + (i - (bladeCount - 1) / 2) * .19;
        const dx = Math.cos(angle), dy = Math.sin(angle);
        playerShots.push({
          x: cx + dx * 27, y: cy + dy * 27,
          vx: dx * 650, vy: dy * 650,
          r: i === 2 ? 24 : 19, life: 1.25,
          damage: i === 2 ? 2.2 : 1.6, piercing: true,
          color: i === 2 ? "#f3ffff" : "#55e6c2",
          trail: true, kimQuyTideBlade: true,
          bladeIndex: i, bladeAngle: angle
        });
        burst(cx + dx * 35, cy + dy * 35, i === 2 ? "#ffffff" : "#8bffed", 3);
      }
      // Vệt chém chữ V sáng phía trước tạo cảm giác cú vung kiếm cực mạnh.
      for (let side of [-1, 1]) {
        const a = base + side * .56;
        for (let step = 1; step <= 6; step++) {
          const d = step * 13;
          burst(cx + Math.cos(a) * d, cy + Math.sin(a) * d,
            step % 2 ? "#bafff4" : "#efffff", 2);
        }
      }
      shake = Math.max(shake, 4.8);
      playTone(660, .22);
      updateHUD();
      return;
    }
    if (selectedCharacter === "lien") { lienShockOrbSkill(); return; }
    if (state !== "playing" || slashCooldown > 0) return;
    slashCooldown = selectedCharacter === "lien" ? 7 : 4;
    slashFlash = 0.62;
    const reach = selectedCharacter === "lien" ? 175 : 148;
    // Chém theo hướng đang di chuyển / ngắm; chỉ trúng mục tiêu phía trước.
    const ax = player.aimX || 1, ay = player.aimY || 0;
    let hit = false;
    const inArc = target => {
      const dx = target.x - player.x, dy = target.y - player.y;
      const d = Math.hypot(dx, dy) || 1;
      return d < reach + (target.r || 12) && (dx * ax + dy * ay) / d > -0.05;
    };
    turrets = turrets.filter(t => {
      if (inArc(t)) { t.hp -= 2; t.flash = .18; hit = true; if (t.hp <= 0) { score += 150; burst(t.x, t.y, "#f4d681", 16); return false; } }
      return true;
    });
    hunterFish = hunterFish.filter(f => {
      if (inArc(f)) { f.hp -= 2; f.flash = .18; hit = true; if (f.hp <= 0) { score += 180; burst(f.x, f.y, "#f4d681", 14); return false; } }
      return true;
    });
    if (boss && !boss.defeated && inArc(boss)) { damageBoss(); hit = true; }
    // Liên: Liên Hoa — phóng đóa sen nước phát sáng; Lê Lợi dùng kiếm khí Thuận Thiên.
    const len = Math.hypot(ax, ay) || 1, dx = ax / len, dy = ay / len;
    playerShots.push({
      x: player.x + dx * 28, y: player.y + dy * 28,
      vx: dx * (selectedCharacter === "lien" ? 640 : 860), vy: dy * (selectedCharacter === "lien" ? 640 : 860),
      r: selectedCharacter === "lien" ? 30 : 21, life: selectedCharacter === "lien" ? 1.9 : 1.75, damage: selectedCharacter === "lien" ? 5 : 3,
      piercing: true, color: selectedCharacter === "lien" ? "#62f5df" : "#ffd86b", slashWave: true, trail: true, waterOrb: selectedCharacter === "lien"
    });
    // Vệt chém nhiều tầng và tia sáng bùng ra theo hướng ngắm.
    for (let i = 0; i < 18; i++) {
      const d = 12 + i * 6;
      burst(player.x + dx * d + (Math.random() - .5) * 22,
        player.y + dy * d + (Math.random() - .5) * 22,
        i % 3 === 0 ? "#ffffff" : (i % 2 ? "#ffd86b" : "#83f4ff"), 2);
    }
    shake = Math.max(shake, 5);
    burst(player.x + ax * 42, player.y + ay * 42, hit ? "#fff0b3" : "#d9c17b", 18);
    playTone(hit ? 720 : 480, .12);
    updateHUD();
  }

  // Thủy Ảnh — Nguyệt Bộ: kỹ năng cơ động riêng của Liên, khác Liên Hoa bắn cánh sen.
  // Liên lướt nhanh theo hướng ngắm, để lại bóng nước đánh lạc hướng tại vị trí cũ.
  // Lê Lợi vẫn giữ nguyên Kiếm Phong xuyên mục tiêu.
  function kiemPhong() {
    if (state !== "playing" || phongCooldown > 0) return;
    if ((activeCombatPlayerIndex === 1 && lives <= 0) || (activeCombatPlayerIndex === 2 && p2Lives <= 0)) return;
    if (selectedCharacter === "kimQuy") {
      // R KIM QUY — Bát Phương Kiếm Vũ: kiếm khí cường hóa bắn tỏa đủ 360 độ.
      phongCooldown = 6;
      const tier = Math.max(1, kimQuyCombo || 1);
      const bladeCount = 16; // Giảm số kiếm khí để giảm tải khi chiêu R kích hoạt.
      const speed = 520 + tier * 35;
      const damage = [0, 1.4, 1.7, 2.0][tier]; // Giảm sát thương mỗi kiếm khí khoảng 40%.
      burst(player.x, player.y, "#eafffb", 18);
      for (let i = 0; i < bladeCount; i++) {
        const angle = (Math.PI * 2 * i) / bladeCount;
        const dx = Math.cos(angle), dy = Math.sin(angle);
        const offset = 24;
        playerShots.push({
          x: player.x + dx * offset, y: player.y + dy * offset,
          vx: dx * speed, vy: dy * speed,
          r: tier === 3 ? 22 : tier === 2 ? 19 : 17,
          life: 1.35, damage, piercing: true,
          color: tier === 3 ? "#efffff" : "#55e6c2",
          trail: true, slashWave: true, kimQuySlash: true,
          comboLevel: tier, bladeLength: tier === 3 ? 52 : 42
        });
        // Tia sáng ngắn tại miệng bắn giúp vòng kiếm khí bung ra rõ ràng.
        burst(player.x + dx * 30, player.y + dy * 30,
          tier === 3 ? "#efffff" : (i % 2 ? "#55e6c2" : "#b7fff0"), 2);
      }
      for (let ring = 0; ring < 2; ring++) {
        const radius = 34 + ring * 20;
        for (let i = 0; i < 10; i++) {
          const a = Math.PI * 2 * i / 10 + ring * .08;
          burst(player.x + Math.cos(a) * radius, player.y + Math.sin(a) * radius,
            ring === 1 && tier === 3 ? "#ffffff" : (i % 2 ? "#55e6c2" : "#fff0a6"), 1);
        }
      }
      phongFlash = .55; shake = Math.max(shake, tier === 3 ? 5.5 : 4);
      playTone(tier === 3 ? 980 : 740, .18); updateHUD(); return;
    }
    const ax = player.aimX || 1, ay = player.aimY || 0;
    const len = Math.hypot(ax, ay) || 1, dx = ax / len, dy = ay / len;
    if (selectedCharacter === "lien") {
      phongCooldown = 9;
      const ox = player.x, oy = player.y;
      const dashDistance = 118;
      // Thủy Ảnh: Liên bất tử trong 1,5 giây kể từ lúc kích hoạt (không nhận sát thương).
      // Dùng chung bộ đếm invulnerable của game để mọi nguồn sát thương đều được chặn.
      invulnerable = Math.max(invulnerable, 1.5);
      // Bóng nước nở tại điểm xuất phát để tạo cảm giác tan biến.
      burst(ox, oy, "#9bf9ff", 18);
      for (let i = 0; i < 12; i++) {
        const a = i * Math.PI * 2 / 12;
        burst(ox + Math.cos(a) * (8 + (i % 3) * 5), oy + Math.sin(a) * (8 + (i % 3) * 5),
          i % 2 ? "#65f5e7" : "#d9ffff", 2);
      }
      // Lướt theo hướng ngắm; vị trí được giới hạn trong sân chơi.
      player.x = Math.max(player.r + 4, Math.min(W - player.r - 4, ox + dx * dashDistance));
      player.y = Math.max(player.r + 4, Math.min(H - player.r - 4, oy + dy * dashDistance));
      const ex = player.x, ey = player.y;
      // Trụ hoa sen xuất hiện tại điểm kết thúc lướt, tồn tại đủ 10 giây.
      lienFlowerPillar = { x: ex, y: ey, t: 0, duration: 10, fireTimer: .25 };
      burst(ex, ey, "#73fff0", 22);
      for (let i = 0; i < 10; i++) {
        const a = i * Math.PI * 2 / 10;
        burst(ex + Math.cos(a) * 18, ey + Math.sin(a) * 18, i % 2 ? "#8ccaff" : "#eaffff", 2);
      }
      // Bóng nước đánh lạc hướng: một đợt nổ nhỏ tại vị trí cũ, không bắn thêm cánh sen.
      playerShots.push({
        x: ox, y: oy, vx: 0, vy: 0, r: 34, life: .28, damage: 1,
        color: "#70fff0", waterOrb: true, waterAfterimage: true, areaPulse: true
      });
      phongFlash = .5;
      shake = Math.max(shake, 2.4);
      playTone(680, .13);
      updateHUD();
      return;
    }
    // R Lê Lợi — Thiên Kiếm Giáng Thế: tụ lực, đại kiếm tím rơi xuống và quét diện rộng.
    phongCooldown = 14;
    const range = 270;
    leLoiSwordUltimate = {
      x: clamp(player.x + dx * range, 62, W - 62),
      y: clamp(player.y + dy * range, 62, H - 62),
      t: 0, hit: false, radius: 172
    };
    phongFlash = .72;
    shake = Math.max(shake, 3.5);
    for (let i = 0; i < 24; i++) {
      const a = Math.PI * 2 * i / 24;
      burst(player.x + Math.cos(a) * (20 + (i % 3) * 8), player.y + Math.sin(a) * (20 + (i % 3) * 8),
        i % 3 === 0 ? "#ffffff" : (i % 2 ? "#d7a7ff" : "#8e44ff"), 2);
    }
    playTone(360, .24);
    updateHUD();
  }

  // Hồn Thiêng Đại Việt — Đại Việt Thần Tướng giáng thế, gây sát thương AOE đúng nhịp va chạm.
  function summonDaiVietThan() {
    if (state !== "playing" || longCooldown > 0 || daiVietUltimate) return;
    longCooldown = 30;
    daiVietUltimate = { x: player.x, y: player.y, t: 0, hit: false, hitCount: 0, radius: 228 };
    // Trong toàn bộ chiêu cuối, Lê Lợi bất tử 3 giây.
    invulnerable = Math.max(invulnerable, 3);
    // Vòng trống đồng mở ra dưới chân, tia linh khí hướng về điểm giáng thần.
    for (let i = 0; i < 28; i++) {
      const a = Math.PI * 2 * i / 28;
      const r = 34 + (i % 4) * 10;
      burst(player.x + Math.cos(a) * r, player.y + Math.sin(a) * r,
        i % 3 === 0 ? "#fff4bf" : i % 2 ? "#e6b957" : "#75e9ef", 2);
    }
    shake = Math.max(shake, 2.5);
    playTone(220, .32);
    updateHUD();
  }

  function resolveDaiVietImpact() {
    const u = daiVietUltimate;
    if (!u || u.hitCount >= 3) return;
    const slam = u.hitCount++;
    u.hit = u.hitCount >= 3;
    // Ba nhát đập liên tiếp; mỗi nhát mở rộng phạm vi và tăng sát thương.
    const radius = u.radius + slam * 42;
    const mobDamage = 3 + slam * 2;
    const inZone = target => Math.hypot(target.x - u.x, target.y - u.y) <= radius + (target.r || 10);
    turrets = turrets.filter(t => {
      if (!inZone(t)) return true;
      t.hp -= mobDamage; t.flash = .3;
      if (t.hp <= 0) { score += 150; burst(t.x, t.y, "#ffe7a0", 18); return false; }
      return true;
    });
    hunterFish = hunterFish.filter(f => {
      if (!inZone(f)) return true;
      f.hp -= mobDamage; f.flash = .3;
      if (f.hp <= 0) { score += 180; burst(f.x, f.y, "#ffe7a0", 18); return false; }
      return true;
    });
    if (boss && !boss.defeated && inZone(boss) && !boss.invulnerable) {
      // Mỗi nhát gây sát thương tăng dần, nhưng vẫn tôn trọng bất tử của boss.
      const bossHits = 2 + slam;
      for (let i = 0; i < bossHits && boss && !boss.defeated && !boss.invulnerable; i++) damageBoss();
    }
    [...turrets, ...hunterFish].forEach(target => {
      const dx = target.x - u.x, dy = target.y - u.y, d = Math.hypot(dx, dy) || 1;
      if (d < radius + 24) { target.x += dx / d * (38 + slam * 12); target.y += dy / d * (38 + slam * 12); }
    });
    for (let i = 0; i < 54 + slam * 18; i++) {
      const a = Math.PI * 2 * i / (54 + slam * 18), r = 38 + (i % 5) * (34 + slam * 5);
      burst(u.x + Math.cos(a) * r, u.y + Math.sin(a) * r,
        i % 4 === 0 ? "#ffffff" : i % 2 ? "#f6cf70" : "#7cecf1", 2 + slam * .35);
    }
    shake = Math.max(shake, 7 + slam * 3);
    playTone(125 - slam * 15, .3 + slam * .06);
    updateHUD();
  }

  // F — Thiên Lôi Giáng Thế: ba đợt sét trong vùng ngắm; trạng thái thuộc fighter đang kích hoạt.
  function lienLightningDragonSkill() {
    if (state !== "playing" || longCooldown > 0 || lienLightningDragon) return;
    longCooldown = 30;
    const ax = player.aimX || 1, ay = player.aimY || 0;
    const len = Math.hypot(ax, ay) || 1, dx = ax / len, dy = ay / len;
    lienLightningDragon = { x: clamp(player.x + dx * 300, 48, W - 48), y: clamp(player.y + dy * 300, 48, H - 48), t: 0, strike: 0, radius: 240, bossHit: false };
    invulnerable = Math.max(invulnerable, .35);
    shake = Math.max(shake, 3); playTone(180, .32); updateHUD();
  }

  function resolveLienLightningDragon() {
    const u = lienLightningDragon; if (!u || u.strike >= 14) return;
    // 20 tia sét rải theo vòng xoắn để phủ rộng vùng chiêu.
    const i = u.strike, angle = i * 2.399963229728653, spread = 24 + Math.sqrt(i / 13) * 155;
    const sx = clamp(u.x + Math.cos(angle) * spread, 24, W - 24), sy = clamp(u.y + Math.sin(angle) * spread, 24, H - 24);
    const hitTarget = target => Math.hypot(target.x - sx, target.y - sy) <= 100 + (target.r || 10);
    turrets = turrets.filter(t => { if (!hitTarget(t)) return true; t.hp -= 4.5; t.flash = .28; t.stunTimer = Math.max(t.stunTimer || 0, .32); burst(t.x,t.y,"#9afaff",12); if(t.hp<=0){score+=180;return false;} return true; });
    hunterFish = hunterFish.filter(f => { if (!hitTarget(f)) return true; f.hp -= 4.5; f.flash = .28; f.stunTimer = Math.max(f.stunTimer || 0, .32); burst(f.x,f.y,"#9afaff",12); if(f.hp<=0){score+=220;return false;} return true; });
    if (boss && !boss.defeated && hitTarget(boss) && !boss.invulnerable && !u.bossHit) { damageBoss(); u.bossHit = true; }
    u.strike++; u.lastStrike = {x:sx,y:sy,t:0};
    for(let i=0;i<6;i++){const a=i*Math.PI/3,r=18+(i%3)*12;burst(sx+Math.cos(a)*r,sy+Math.sin(a)*r,i%2?"#79f7ff":"#ffffff",1);}
    shake=Math.max(shake,3.5);playTone(110+u.strike*18,.12);updateHUD();
  }

  // Chiêu F riêng theo nhân vật: Liên Hoa Nguyệt Triều, Linh Khí Hội Tụ, hoặc Hồn Thiêng Đại Việt.
  function longTram() {
    if (state !== "playing" || longCooldown > 0) return;
    if ((activeCombatPlayerIndex === 1 && lives <= 0) || (activeCombatPlayerIndex === 2 && p2Lives <= 0)) return;
    if (selectedCharacter !== "lien" && selectedCharacter !== "kimQuy") { summonDaiVietThan(); return; }
    if (selectedCharacter === "lien") { lienLightningDragonSkill(); return; }
    longCooldown = selectedCharacter === "kimQuy" ? 30 : 11;
    longFlash = .56;
    let hit = false;

    // Liên: Liên Hoa Nguyệt Triều — hoa sen nước nở ở điểm ngắm rồi phát sóng tròn.
    // Dùng một hoạt ảnh vẽ theo frame thay vì sinh hàng chục burst cùng lúc để giảm lag.
    const isLien = selectedCharacter === "lien";
    const isKimQuy = selectedCharacter === "kimQuy";
    const aimX = player.aimX || 1, aimY = player.aimY || 0;
    if (isLien) {
      const aimLen = Math.hypot(aimX, aimY) || 1;
      const dirX = aimX / aimLen, dirY = aimY / aimLen;
      const range = 300;
      lienUltimate = {
        t: 0,
        x: clamp(player.x + dirX * range, 42, W - 42),
        y: clamp(player.y + dirY * range, 42, H - 42),
        hit: false,
        radius: 108
      };
      playTone(720, .16);
      updateHUD();
      return;
    }
    if (isKimQuy) {
      // F — Thần Quy Chấn Hải: khóa tâm tại vị trí kích hoạt, phát hai xung.
      // Trạng thái riêng theo người chơi; hiệu ứng vẽ theo frame để tránh lag.
      kimQuyUltimate = { t: 0, x: player.x, y: player.y, waves: Array(8).fill(false), pulled: false, radius: 420 };
      // Thần cấp: bảo vệ người thi triển trong lúc tụ lực; shieldTimer thuộc context của từng người chơi.
      shieldTimer = Math.max(shieldTimer, .5);
      longFlash = .65;
      playTone(260, .12);
      updateHUD();
      return;
    }
    const aimLen = Math.hypot(aimX, aimY) || 1;
    const dirX = aimX / aimLen, dirY = aimY / aimLen;
    const range = 340;
    const cx = isLien ? clamp(player.x + dirX * range, 36, W - 36) : player.x;
    const cy = isLien ? clamp(player.y + dirY * range, 36, H - 36) : player.y;
    const radius = isLien ? 42 : (isKimQuy ? 185 : 225);
    const inZone = target => {
      if (!isLien) return Math.hypot(target.x - cx, target.y - cy) <= radius + (target.r || 10);
      const vx = cx - player.x, vy = cy - player.y;
      const denom = vx * vx + vy * vy || 1;
      const t = clamp(((target.x - player.x) * vx + (target.y - player.y) * vy) / denom, 0, 1);
      return Math.hypot(target.x - (player.x + t * vx), target.y - (player.y + t * vy)) <= radius + (target.r || 10);
    };

    turrets = turrets.filter(t => {
      if (inZone(t)) { t.hp -= 3; t.flash = .22; hit = true; if (t.hp <= 0) { score += 150; burst(t.x, t.y, isLien ? "#75fff0" : "#ffd875", 18); return false; } }
      return true;
    });
    hunterFish = hunterFish.filter(f => {
      if (inZone(f)) { f.hp -= 3; f.flash = .22; hit = true; if (f.hp <= 0) { score += 180; burst(f.x, f.y, isLien ? "#75fff0" : "#9ceaff", 16); return false; } }
      return true;
    });
    if (boss && !boss.defeated && inZone(boss)) { damageBoss(); hit = true; }

    if (isLien) {
      // Long linh nước: đường sóng dài, đầu rồng sáng và vảy nước hai bên.
      for (let step = 1; step <= 17; step++) {
        const d = step * 18;
        const px = player.x + dirX * d, py = player.y + dirY * d;
        burst(px, py, step % 2 ? "#70fff0" : "#c7ffff", 3);
        const side = step % 2 ? 1 : -1;
        burst(px - dirY * side * 18, py + dirX * side * 18, "#4ccfff", 1);
        if (step % 3 === 0) burst(px + dirX * 7, py + dirY * 7, "#ffffff", 2);
      }
      // Đầu long linh ở cuối đường lao.
      for (let i = 0; i < 16; i++) {
        const a = Math.PI * 2 * i / 16;
        burst(cx + Math.cos(a) * 22, cy + Math.sin(a) * 22, i % 2 ? "#7bfff0" : "#ffffff", 2);
      }
      shake = Math.max(shake, hit ? 6 : 3.8);
    } else {
      // Kim Quy: Thần Quy Chấn Hải — vòng sóng nước xanh ngọc đẩy lùi kẻ địch.
      if (isKimQuy) {
        for (let i = 0; i < 30; i++) { const a = Math.PI * 2 * i / 30; burst(player.x + Math.cos(a) * (45 + (i % 4) * 23), player.y + Math.sin(a) * (45 + (i % 4) * 23), i % 2 ? "#55e6c2" : "#e7fff8", 2); }
        turrets.forEach(t => { const dx = t.x - player.x, dy = t.y - player.y, d = Math.hypot(dx, dy) || 1; if (d < radius + 30) { t.x += dx / d * 35; t.y += dy / d * 35; } });
        hunterFish.forEach(f => { const dx = f.x - player.x, dy = f.y - player.y, d = Math.hypot(dx, dy) || 1; if (d < radius + 30) { f.x += dx / d * 45; f.y += dy / d * 45; } });
      }
      // Long Trảm của Lê Lợi: sóng kiếm vàng bùng quanh nhân vật.
      for (let i = 0; i < 8; i++) {
        const a = Math.PI * 2 * i / 8;
        const d = 38 + (i % 2) * 18;
        burst(player.x + Math.cos(a) * d, player.y + Math.sin(a) * d,
          i % 3 === 0 ? "#8beaff" : (hit ? "#fff0a8" : "#ffd875"), 1);
      }
      shake = Math.max(shake, hit ? 6 : 3.5);
    }

    playTone(hit ? 620 : (isLien ? 760 : 380), .2);
    updateHUD();
  }

  function fireEnemyShot(
    fromX, fromY, targetX, targetY,
    speed, spread = 0, color = "#83e3e1"
  ) {
    const angle =
      Math.atan2(targetY - fromY, targetX - fromX) + spread;

    enemyShots.push({
      x: fromX, y: fromY,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      r: 6, life: 4.2, color
    });
  }

  // Hắc Long: cầu hắc viêm lớn hơn, tự bẻ hướng đuổi theo người chơi.
  function fireHomingFireball(fromX, fromY, targetX, targetY, speed, color = "#ff6338") {
    const angle = Math.atan2(targetY - fromY, targetX - fromX);
    enemyShots.push({
      x: fromX, y: fromY,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      r: 10, life: 6.5, color,
      homing: true, turnRate: 2.15, trail: true
    });
  }

  // Chiêu cuối Kim Quy chỉ ngắt các đòn đang tụ lực của Ma Chủ; không xóa bất tử,
  // không chạm vào pha biến hình/đòn đã tung hoặc các miễn nhiễm của boss khác.
  function breakBossWindupForKimQuy() {
    if (!boss || boss.defeated || boss.invulnerable || boss.form !== "demon") return false;
    const interruptible = new Set(["slash-windup", "swords-windup", "combo-windup", "zones-windup"]);
    if (!interruptible.has(boss.demonSkill)) return false;
    boss.demonSkill = "idle";
    boss.demonSkillTimer = 0;
    boss.demonSkillCooldown = Math.max(boss.demonSkillCooldown || 0, 1.35);
    boss.demonZones = [];
    boss.demonSkillSwords = [];
    boss.flash = Math.max(boss.flash || 0, .22);
    burst(boss.x, boss.y, "#8ffff0", 18);
    playTone(210, .12);
    return true;
  }

  function damageBoss() {
    if (!boss || boss.defeated || boss.invulnerable || (boss.damageGate || 0) > 0) return;

    // Chống sốc sát thương: giới hạn nhịp nhận đòn, không xóa miễn nhiễm theo cơ chế riêng.
    boss.damageGate = 0.06;
    boss.hp--;
    boss.flash = .12;
    score += 25;
    if (activeCombatPlayerIndex === 2) p2Score += 25;

    burst(
      boss.x - 20,
      boss.y + rand(-18, 18),
      "#f4d681",
      6
    );

    playTone(350 + (boss.maxHp - boss.hp) * 12, .04);
    updateBossHUD();
    updateHUD();

    if (boss.hp <= 0 && level === chapters.length - 1 && boss.stage === 1) {
      const defeatedX = boss.x, defeatedY = boss.y;
      burst(defeatedX, defeatedY, "#ff7b4d", 70);
      burst(defeatedX, defeatedY, "#f7d783", 42);
      playTone(130, .35);
      spawnBoss(2);
      state = "bossIntro";
      $("pauseBtn").disabled = true;
      $("statusLabel").textContent = "MA CHỦ ĐOẠT KIẾM XUẤT HIỆN";
      updateBossHUD();
      return;
    }

    if (boss.hp <= 0) {
      boss.defeated = true;
      bossDefeated = true;
      gateOpen = true;
      enemyShots = [];
      turrets = [];
      score += 600;
      if (activeCombatPlayerIndex === 2) p2Score += 600;
      shieldTimer = Math.max(shieldTimer, 3);

      burst(boss.x, boss.y, "#f5d783", 55);
      const defeatedBossStage = boss.stage;
      boss = null;

      updateBossHUD();
      saveBest();
      updateHUD();

      const finalVictory = level === chapters.length - 1 && defeatedBossStage === 2;
      $("goalText").textContent = finalVictory
        ? "Ma Chủ đã bị đánh bại! Đến Tháp Rùa để trả kiếm thần về Hồ Gươm."
        : "Huyền Quy đã bị đánh bại! Đi đến Tháp Rùa ở phía bên phải.";
      $("statusLabel").textContent = finalVictory ? "KIẾM THẦN ĐƯỢC GIẢI CỨU" : "CỔNG THÁP RÙA ĐÃ MỞ";

      showOverlay(
        finalVictory ? "HỒI KẾT · CHIẾN THẮNG" : "CHIẾN THẮNG TRÙM CUỐI",
        finalVictory ? "Hồ Gươm lại bình yên!" : "Huyền Quy đã bình yên!",
        finalVictory
          ? "Ma Chủ đã bị đánh bại, thanh kiếm thần được trả về Hồ Gươm. Hãy tiến đến Tháp Rùa để khép lại huyền thoại."
          : "Bạn đã phá giải lớp phong ấn cuối cùng. Tiếp tục di chuyển đến Tháp Rùa ở phía bên phải.",
        finalVictory ? "Khép lại huyền thoại" : "Tiếp tục đến Tháp Rùa",
        finalVictory ? "⚔" : "✦"
      );

      state = "bossDefeatedIntro";
      $("pauseBtn").disabled = true;

      playTone(560, .16);
      setTimeout(() => playTone(820, .2), 140);
    }
  }

  function updateChapterList() {
    const items = $("chapterList").querySelectorAll("li");

    items.forEach((item, i) => {
      item.classList.toggle("active", i === level);
      item.classList.toggle("done", i < level);

      item.querySelector("i").textContent =
        i < level ? "Hoàn thành" :
          i === level ? "Đang chơi" : "Chưa mở";
    });
  }

  function showOverlay(kicker, title, text, button, icon = "✧") {
    document.querySelector("#chapterUpgradeChoices")?.remove();
    $("overlayKicker").textContent = kicker;
    $("overlayTitle").textContent = title;
    $("overlayText").textContent = text;
    $("mainBtn").innerHTML = `${button} <span>→</span>`;
    $("overlayIcon").textContent = icon;
    $("overlay").classList.remove("hidden");
  }

  function pauseGame() {
    if (state === "playing") {
      state = "paused";
      $("pauseBtn").textContent = "▶ Tiếp tục";
      $("statusLabel").textContent = "ĐÃ TẠM DỪNG";

      showOverlay(
        "TẠM NGHỈ MỘT CHÚT",
        "Hành trình đang dừng",
        "Khi sẵn sàng, hãy tiếp tục chuyến đi.",
        "Tiếp tục",
        "Ⅱ"
      );
    } else if (state === "paused") {
      state = "playing";
      $("overlay").classList.add("hidden");
      $("pauseBtn").textContent = "Ⅱ Tạm dừng";
      $("statusLabel").textContent = "ĐANG HÀNH TRÌNH";
      lastTime = performance.now();
    }
  }

  function showChapterUpgradeChoices() {
    const panel = document.querySelector("#overlay .overlay-panel");
    if (!panel) return;
    const choices = document.createElement("div");
    choices.id = "chapterUpgradeChoices";
    choices.className = "chapter-upgrade-choices";
    choices.innerHTML = `
      <p class="chapter-upgrade-title">NÂNG CẤP RIÊNG TRƯỚC MÀN TIẾP THEO</p>
      <section class="chapter-upgrade-player">
        <p class="chapter-upgrade-points" id="chapterUpgradePointsP1">Điểm nâng cấp P1: ${playerUpgradePoints(1)}</p>
        <div class="chapter-upgrade-grid">
          <button type="button" data-upgrade-player="1" data-upgrade="speed">⚡ Tốc độ</button>
          <button type="button" data-upgrade-player="1" data-upgrade="power">⚔️ Sát thương</button>
          <button type="button" data-upgrade-player="1" data-upgrade="fire">➶ Tốc độ bắn</button>
          <button type="button" data-upgrade-player="1" data-upgrade="shield">🛡️ Khiên</button>
        </div>
      </section>
      <section class="chapter-upgrade-player">
        <p class="chapter-upgrade-points" id="chapterUpgradePointsP2">Điểm nâng cấp P2: ${playerUpgradePoints(2)}</p>
        <div class="chapter-upgrade-grid">
          <button type="button" data-upgrade-player="2" data-upgrade="speed">⚡ Tốc độ</button>
          <button type="button" data-upgrade-player="2" data-upgrade="power">⚔️ Sát thương</button>
          <button type="button" data-upgrade-player="2" data-upgrade="fire">➶ Tốc độ bắn</button>
          <button type="button" data-upgrade-player="2" data-upgrade="shield">🛡️ Khiên</button>
        </div>
      </section>
      <p class="chapter-upgrade-note">Mỗi người dùng điểm và bộ nâng cấp riêng. Nâng cấp đã mua được giữ sang chương kế tiếp.</p>`;
    // Đặt nút qua chương trước bảng nâng cấp để không bị đẩy khỏi màn hình laptop.
    const mainButton = panel.querySelector("#mainBtn");
    if (mainButton) mainButton.insertAdjacentElement("afterend", choices);
    else panel.appendChild(choices);
    choices.querySelectorAll("[data-upgrade]").forEach(button => {
      button.addEventListener("click", () => buyUpgrade(button.dataset.upgrade, Number(button.dataset.upgradePlayer) || 1));
    });
    refreshUpgradeUI();
  }

  function finishChapter() {
    // Thưởng qua chương cho từng người; giữ cách tính thưởng gốc của game.js cho P1.
    const p1ChapterReward = 300 + lives * 50;
    const p2ChapterReward = 300 + p2Lives * 50;
    score += p1ChapterReward + p2ChapterReward;
    p2Score += p2ChapterReward;
    saveBest();

    if (level === chapters.length - 1) {
      state = "won";
      $("pauseBtn").disabled = true;
      $("statusLabel").textContent = "HỒ GƯƠM ĐƯỢC GIẢI CỨU";

      // Reset all temporary upgrades when the full run ends in victory.
      // Keep the final score and saved best score unchanged.
      resetUpgrades();

      showOverlay(
        "HÀNH TRÌNH HOÀN TẤT",
        "Huyền thoại được tiếp nối!",
        `Bạn đã hoàn thành cả ${chapters.length} chương với ${score} điểm. Ma Chủ đã bị đánh bại, thanh kiếm thần trở về và ánh sáng lại soi sáng Hồ Gươm.`,
        "Chơi lại từ đầu",
        "✦"
      );

      burst(W - 75, H / 2, "#f5d783", 50);
      playTone(760, .14);
      setTimeout(() => playTone(920, .2), 130);
    } else {
      state = "chapterDone";
      $("pauseBtn").disabled = true;
      $("statusLabel").textContent = "ĐÃ HOÀN THÀNH CHƯƠNG";

      showOverlay(
        `CHƯƠNG ${level + 1} HOÀN THÀNH`,
        chapters[level].name,
        "Bạn đã thu thập đủ linh quang và nhận thưởng! Hãy chọn nâng cấp bên dưới trước khi sang màn tiếp theo.",
        "Tiến tới chương tiếp",
        "✦"
      );
      showChapterUpgradeChoices();

      playTone(690, .12);
      setTimeout(() => playTone(830, .12), 110);
    }

    updateHUD();
  }

  function loseLife() {
    if (devGodMode || lives <= 0 || invulnerable > 0 || state !== "playing") return;

    if (shieldTimer > 0) {
      shieldTimer = 0;
      invulnerable = 1;
      burst(player.x, player.y, "#8fe8ed", 20);
      playTone(500, .1);
      return;
    }

    lives--;
    invulnerable = 1.5;
    shake = Math.min(shake, 2.5);

    burst(player.x, player.y, "#8bd9d2", 18);
    playTone(160, .16);

    // Khi hết mạng, P1 gục tại chỗ và có thể được P2 cứu dậy.
    if (lives <= 0) lives = 0;

    updateHUD();
  }

  function burst(x, y, color, count) {
    const available = Math.max(0, PARTICLE_LIMIT - particles.length);
    count = Math.min(count, available);
    for (let i = 0; i < count; i++) {
      const a = rand(0, Math.PI * 2);
      const s = rand(35, 170);

      particles.push({
        x, y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: rand(.35, .85),
        max: .85,
        color,
        r: rand(1.5, 4)
      });
    }
  }

  function playTone(freq, duration) {
    if (!soundOn) return;

    try {
      audioCtx = audioCtx ||
        new (window.AudioContext || window.webkitAudioContext)();

      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = "sine";
      osc.frequency.value = freq;

      gain.gain.setValueAtTime(.045, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(
        .001,
        audioCtx.currentTime + duration
      );

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (_) { }
  }
  // Tiến trình cứu đồng đội: phải giữ C/U liên tục trong 2 giây.
  let reviveProgress = 0;
  const REVIVE_DURATION = 2;

  function update(dt) {
    if (state !== "playing") return;

    // Giới hạn bước thời gian để chuyển động ổn định khi tab bị khựng.
    dt = Math.min(Math.max(Number.isFinite(dt) ? dt : 0, 0), 1 / 30);
    if (dt <= 0) return;

    // C cứu P2, U cứu P1; rời xa hoặc nhả phím sẽ hủy tiến trình.
    const nearP2 = player2 && Math.hypot(player.x-player2.x, player.y-player2.y) <= 58;
    const nearP1 = player2 && Math.hypot(player.x-player2.x, player.y-player2.y) <= 58;
    const rescuingP2 = !!(keys.c || keys.C) && lives > 0 && p2Lives <= 0 && nearP2;
    const rescuingP1 = !!(keys.u || keys.U) && p2Lives > 0 && lives <= 0 && nearP1;
    if (rescuingP2 || rescuingP1) {
      reviveProgress = Math.min(REVIVE_DURATION, reviveProgress + dt);
      if (reviveProgress >= REVIVE_DURATION) {
        if (rescuingP2) {
          p2Lives = 1; p2Invulnerable = 2; p2CombatState.invulnerable = 2;
          p2SkillFx = { type: "revive", time: .7, duration: .7, angle: 0 };
          burst(player2.x, player2.y, "#62e9ff", 24);
        } else {
          lives = 1; invulnerable = 2; burst(player.x, player.y, "#f4d681", 24); updateHUD();
        }
        reviveProgress = 0;
        updateTwoPlayerHUD();
      }
    } else reviveProgress = 0;

    elapsed += dt;
    if (lienFlowerPillar) {
      const p = lienFlowerPillar;
      p.t += dt;
      p.fireTimer -= dt;
      // Trụ hoa sen tự động bắn đạn phép xanh vào mục tiêu gần nhất.
      if (p.fireTimer <= 0 && p.t < p.duration) {
        let target = (boss && !boss.defeated) ? boss : null;
        let bestDistance = target ? distance(p, target) : Infinity;
        for (const candidate of hunterFish) {
          const d = distance(p, candidate);
          if (d < bestDistance) { target = candidate; bestDistance = d; }
        }
        for (const candidate of turrets) {
          const d = distance(p, candidate);
          if (d < bestDistance) { target = candidate; bestDistance = d; }
        }
        if (target && bestDistance < 620) {
          const sx = p.x, sy = p.y - 48;
          const dx = target.x - sx, dy = target.y - sy;
          const len = Math.hypot(dx, dy) || 1;
          playerShots.push({
            x: sx, y: sy, vx: dx / len * 330, vy: dy / len * 330,
            r: 9, life: 2.1, damage: 1.8, color: '#8ffff0', lotusPillarShot: true, trail: true
          });
          burst(sx, sy, '#bafff5', 4);
        }
        p.fireTimer = .62;
      }
      if (p.t >= p.duration) lienFlowerPillar = null;
    }
    const chapter = chapters[level];

    if (invulnerable > 0) invulnerable -= dt;
    if (shake > 0) shake = Math.max(0, shake - 32 * dt);
    // Cấp đạn Kim Quy luân phiên qua từng phát bắn, không phụ thuộc thời gian chờ.
    slashCooldown = Math.max(0, slashCooldown - dt);
    if (leLoiEmpowerTimer > 0) leLoiEmpowerTimer = Math.max(0, leLoiEmpowerTimer - dt);
    phongCooldown = Math.max(0, phongCooldown - dt);
    longCooldown = Math.max(0, longCooldown - dt);
    if (daiVietUltimate) {
      daiVietUltimate.t += dt;
      const u = daiVietUltimate;
      if (u.t >= .95 && (u.hitCount || 0) < 1) resolveDaiVietImpact();
      if (u.t >= 1.48 && (u.hitCount || 0) < 2) resolveDaiVietImpact();
      if (u.t >= 2.02 && (u.hitCount || 0) < 3) resolveDaiVietImpact();
      if (u.t >= 2.75) daiVietUltimate = null;
    }
    if (leLoiSwordUltimate) {
      const u = leLoiSwordUltimate;
      u.t += dt;
      // Va chạm ở nhịp kiếm chạm đất; gây sát thương nhiều mục tiêu trong vùng.
      if (u.t >= 1.08 && !u.hit) {
        u.hit = true;
        const inZone = target => Math.hypot(target.x - u.x, target.y - u.y) <= u.radius + (target.r || 10);
        turrets = turrets.filter(t => {
          if (!inZone(t)) return true;
          t.hp -= 3.5; t.flash = .3;
          if (t.hp <= 0) { score += 150; burst(t.x, t.y, "#d7a7ff", 20); return false; }
          return true;
        });
        hunterFish = hunterFish.filter(f => {
          if (!inZone(f)) return true;
          f.hp -= 3.5; f.flash = .3;
          if (f.hp <= 0) { score += 180; burst(f.x, f.y, "#d7a7ff", 18); return false; }
          return true;
        });
        if (boss && !boss.defeated && inZone(boss) && !boss.invulnerable) {
          for (let i = 0; i < 4 && boss && !boss.defeated && !boss.invulnerable; i++) damageBoss();
        }
        // Sóng kiếm đẩy quái ra ngoài tâm chém để tạo cảm giác va chạm mạnh.
        [...turrets, ...hunterFish].forEach(target => {
          const vx = target.x - u.x, vy = target.y - u.y, d = Math.hypot(vx, vy) || 1;
          if (d < u.radius + 24) { target.x = clamp(target.x + vx / d * 42, 20, W - 20); target.y = clamp(target.y + vy / d * 42, 20, H - 20); }
        });
        for (let i = 0; i < 48; i++) {
          const a = Math.PI * 2 * i / 48, r = 24 + (i % 6) * 25;
          burst(u.x + Math.cos(a) * r, u.y + Math.sin(a) * r,
            i % 4 === 0 ? "#ffffff" : (i % 2 ? "#d7a7ff" : "#8e44ff"), 2);
        }
        shake = Math.max(shake, 9);
        playTone(120, .38);
        updateHUD();
      }
      if (u.t >= 2.35) leLoiSwordUltimate = null;
    }
    if (lienLightningDragon) {
      const u = lienLightningDragon; u.t += dt; if (u.lastStrike) u.lastStrike.t += dt;
      if (u.strike < 14 && u.t >= .25 + u.strike * .15) resolveLienLightningDragon();
      if (u.t >= 2.85) lienLightningDragon = null;
    }
    if (lienUltimate) {
      const u = lienUltimate;
      u.t += dt;
      // Sóng nở sau khi cánh sen mở; chỉ xử lý va chạm một lần.
      if (u.t >= .48 && !u.hit) {
        u.hit = true;
        const hitTarget = target => Math.hypot(target.x - u.x, target.y - u.y) <= u.radius + (target.r || 10);
        turrets = turrets.filter(t => { if (!hitTarget(t)) return true; t.hp -= 3; t.flash = .24; if (t.hp <= 0) { score += 150; return false; } return true; });
        hunterFish = hunterFish.filter(f => { if (!hitTarget(f)) return true; f.hp -= 3; f.flash = .24; if (f.hp <= 0) { score += 180; return false; } return true; });
        if (boss && !boss.defeated && hitTarget(boss)) damageBoss();
        [...turrets, ...hunterFish].forEach(target => {
          const dx = target.x - u.x, dy = target.y - u.y, d = Math.hypot(dx, dy) || 1;
          if (d < u.radius + 24) { target.x = clamp(target.x + dx / d * 26, 20, W - 20); target.y = clamp(target.y + dy / d * 26, 20, H - 20); }
        });
        shake = Math.max(shake, 3.2);
        playTone(510, .18);
        updateHUD();
      }
      if (u.t >= 1.18) lienUltimate = null;
    }
    if (kimQuyUltimate) {
      const u = kimQuyUltimate;
      u.t += dt;
      // Tám xung Thần Quy Diệt Thế; trạng thái và hồi chiêu của P1/P2 vẫn tách biệt.
      const hitWave = (damage, push, tone) => {
        const radius = u.radius || 420;
        const hitTarget = target => Math.hypot(target.x - u.x, target.y - u.y) <= radius + (target.r || 10);
        turrets = turrets.filter(t => { if (!hitTarget(t)) return true; t.hp -= damage; t.flash = .24; t.stunTimer = Math.max(t.stunTimer || 0, .4); if (t.hp <= 0) { score += 150; return false; } return true; });
        hunterFish = hunterFish.filter(f => { if (!hitTarget(f)) return true; f.hp -= damage; f.flash = .24; f.stunTimer = Math.max(f.stunTimer || 0, .4); if (f.hp <= 0) { score += 180; return false; } return true; });
        if (boss && !boss.defeated && hitTarget(boss)) {
          breakBossWindupForKimQuy();
          if (!boss.invulnerable) { damageBoss(); damageBoss(); }
        }
        turrets.forEach(t => { const dx = t.x - u.x, dy = t.y - u.y, d = Math.hypot(dx, dy) || 1; if (d < radius + 20) { t.x = clamp(t.x + dx / d * push, 20, W - 20); t.y = clamp(t.y + dy / d * push, 20, H - 20); } });
        hunterFish.forEach(f => { const dx = f.x - u.x, dy = f.y - u.y, d = Math.hypot(dx, dy) || 1; if (d < radius + 20) { f.x = clamp(f.x + dx / d * push, 20, W - 20); f.y = clamp(f.y + dy / d * push, 20, H - 20); } });
        shake = Math.max(shake, tone > 450 ? 4.2 : 3.2);
        playTone(tone, .14);
        updateHUD();
      };
      const waveTimes = [.38, .70, 1.02, 1.34, 1.66, 1.98, 2.30, 2.62];
      const wavePush = [28, 35, 42, 49, 56, 63, 70, 78];
      const waveTones = [420, 460, 500, 540, 580, 620, 700, 820];
      if (!u.waves) u.waves = [u.hit, u.hit2, u.hit3, u.hit4, false, false, false, false].map(Boolean);
      waveTimes.forEach((at, i) => {
        if (u.t >= at && !u.waves[i]) {
          u.waves[i] = true;
          hitWave(12, wavePush[i], waveTones[i]);
          if (i === 7) shieldTimer = Math.max(shieldTimer, 2);
        }
      });
      if (u.t >= 3.18) kimQuyUltimate = null;
    }
    updateCooldownDisplay();
    phongFlash = Math.max(0, phongFlash - dt);
    longFlash = Math.max(0, longFlash - dt);
    slashFlash = Math.max(0, slashFlash - dt);
    if (lives > 0 && (keys.e || keys.E)) { thuanThienSlash(); keys.e = keys.E = false; }

    let dx = 0, dy = 0;
    const arrowAssignedToP2 = key => Object.values(p2KeyMap).some(mapped => normalizedKey(mapped) === normalizedKey(key));
    if (lives > 0 && ((keys.ArrowLeft && !arrowAssignedToP2("ArrowLeft")) || keys.a || keys.A)) dx--;
    if (lives > 0 && ((keys.ArrowRight && !arrowAssignedToP2("ArrowRight")) || keys.d || keys.D)) dx++;
    if (lives > 0 && ((keys.ArrowUp && !arrowAssignedToP2("ArrowUp")) || keys.w || keys.W)) dy--;
    if (lives > 0 && ((keys.ArrowDown && !arrowAssignedToP2("ArrowDown")) || keys.s || keys.S)) dy++;

    // Chuẩn hóa vector để tốc độ chéo bằng tốc độ di chuyển thẳng.
    const inputLength = Math.hypot(dx, dy);
    if (inputLength > 0) {
      dx /= inputLength;
      dy /= inputLength;
      player.aimX = dx;
      player.aimY = dy;
    }

    const oldX = player.x;
    const oldY = player.y;
    player.x = clamp(oldX + dx * player.speed * dt, 25, W - 25);
    player.y = clamp(oldY + dy * player.speed * dt, 68, H - 28);

    // Người chơi 2: bộ điều khiển và tài nguyên riêng, cùng chiến đấu trong thế giới/màn hiện tại.
    if (player2) {
      p2Invulnerable = Math.max(0, p2Invulnerable - dt);
      p2ShieldTimer = Math.max(0, p2ShieldTimer - dt);
      p2ShotCooldown = Math.max(0, p2ShotCooldown - dt);
      p2SkillCooldown = Math.max(0, p2SkillCooldown - dt);
      p2UltCooldown = Math.max(0, p2UltCooldown - dt);
      p2SkillFx.time = Math.max(0, p2SkillFx.time - dt);
      if (p2CombatState) {
        p2CombatState.shotCooldown = Math.max(0, p2CombatState.shotCooldown - dt);
        p2CombatState.slashCooldown = Math.max(0, p2CombatState.slashCooldown - dt);
        p2CombatState.phongCooldown = Math.max(0, p2CombatState.phongCooldown - dt);
        p2CombatState.longCooldown = Math.max(0, p2CombatState.longCooldown - dt);
        p2CombatState.lienChargeIdleTimer = Math.max(0, p2CombatState.lienChargeIdleTimer - dt);
        p2CombatState.kimQuyComboTimer = Math.max(0, p2CombatState.kimQuyComboTimer - dt);
        p2CombatState.leLoiComboTimer = Math.max(0, p2CombatState.leLoiComboTimer - dt);
        p2CombatState.leLoiEmpowerTimer = Math.max(0, p2CombatState.leLoiEmpowerTimer - dt);
        if (p2CombatState.kimQuyComboTimer <= 0) p2CombatState.kimQuyCombo = 0;
        if (p2CombatState.leLoiComboTimer <= 0) p2CombatState.leLoiCombo = 0;
      }
      let x2 = 0, y2 = 0;
      if (p2Lives > 0) { if (p2Keys.j) x2--; if (p2Keys.l) x2++; if (p2Keys.i) y2--; if (p2Keys.k) y2++; }
      const l2 = Math.hypot(x2, y2); if (l2) { x2 /= l2; y2 /= l2; player2.aimX = x2; player2.aimY = y2; }
      player2.x = clamp(player2.x + x2 * player2.speed * dt, 25, W - 25);
      player2.y = clamp(player2.y + y2 * player2.speed * dt, 68, H - 28);
      player2.trail.push({ x: player2.x, y: player2.y, life: .24 }); if (player2.trail.length > 8) player2.trail.shift();
      player2.trail.forEach(t => t.life -= dt);
      // Đánh thường P2: giữ U để tự động đánh liên tục theo hồi chiêu riêng.
      // Dùng lại firePlayerShot() của game một người qua context P2 để giữ nguyên
      // bộ đạn, sát thương, combo và nâng cấp của nhân vật đã chọn.
      if (p2Lives > 0 && p2Keys.Enter && state === "playing" && p2CombatState.shotCooldown <= 0) {
        withPlayerTwoContext(() => { aimP2AtNearestTarget(); firePlayerShot(); });
        p2SkillFx = { type: "shot", time: .18, duration: .18, angle: Math.atan2(player2.aimY || 0, player2.aimX || 1) };
      }
      // Va chạm độc lập: người 2 mất mạng riêng, không trừ mạng người 1.
      const hurtP2 = (x,y,r=14) => {
        if (p2Lives <= 0 || Math.hypot(player2.x-x,player2.y-y) > player2.r+r) return;
        if (p2ShieldTimer > 0) { p2ShieldTimer = 0; burst(x,y,"#62e9ff",10); return; }
        if (p2Invulnerable > 0) return;
        p2Lives = Math.max(0, p2Lives - 1); p2Invulnerable=1.35; burst(player2.x,player2.y,"#62e9ff",14);
      };
      hazards.forEach(h=>hurtP2(h.x,h.y,h.r*.7));
      // Bụi lau gai gây sát thương cho P2 theo mạng/bất tử/khiên riêng, giống cơ chế P1.
      reedPatches.forEach(r=>hurtP2(r.x,r.y,r.r*.72));
      hunterFish.forEach(f=>hurtP2(f.x,f.y,f.r*.72));
      enemyShots.forEach(s=>hurtP2(s.x,s.y,s.r||6));
      if (p2Lives<=0 && lives<=0) { state="gameover"; showOverlay("CẢ HAI CHIẾN BINH ĐÃ GỤC","Cả hai đang chờ đồng đội cứu","Không còn ai đứng vững để cứu đồng đội. Hãy chơi lại màn này.","Chơi lại","✦"); }
    }

    if (player2 && p2CombatState && p2Lives > 0) updateP2DelayedSkills(dt);

    player.trail.push({ x: player.x, y: player.y, life: .28 });
    if (player.trail.length > 10) player.trail.shift();
    player.trail.forEach(t => t.life -= dt);

    // Cá săn mồi xuất hiện theo thời gian và bám đuổi người chơi.
    // Giới hạn TỔNG số cá mỗi màn để không thể farm điểm vô hạn:
    // màn 1 có 3 con, mỗi màn tiếp theo tăng thêm 1 con.
    const fishLimitThisLevel = 3 + level;
    const maxFishAtOnce = difficulty === "hell" ? 4 : difficulty === "hard" ? 3 : 2;
    if (elapsed >= nextFishAt && fishSpawnedThisLevel < fishLimitThisLevel && hunterFish.length < maxFishAtOnce) {
      const fromLeft = Math.random() < .5;
      hunterFish.push({
        x: fromLeft ? -24 : W + 24,
        y: rand(90, H - 55), r: 16,
        speed: (difficulty === "hell" ? 150 : difficulty === "hard" ? 130 : difficulty === "easy" ? 100 : 115) + level * 10,
        phase: rand(0, Math.PI * 2), life: difficulty === "hell" ? 17 : 14,
        // Cá săn mồi có máu cao hơn hoa sen để buộc người chơi né và tập trung bắn.
        hp: level >= 2 ? 32 : 24,
        maxHp: level >= 2 ? 32 : 24,
        flash: 0
      });
      fishSpawnedThisLevel++;
      nextFishAt = elapsed + (difficulty === "hell" ? 3.5 : difficulty === "hard" ? 4.5 : difficulty === "easy" ? 7 : 5.5);
    }
    hunterFish.forEach(f => {
      f.phase += dt * 5;
      f.life -= dt;
      f.flash = Math.max(0, (f.flash || 0) - dt);
      const prey = getNearestLivingPlayer(f);
      if (!prey) return;
      const target = prey.ref;
      const angle = Math.atan2(target.y - f.y, target.x - f.x);
      f.x += Math.cos(angle) * f.speed * dt;
      f.y += Math.sin(angle) * f.speed * dt + Math.sin(f.phase) * 12 * dt;
      if (distance(target, f) < target.r + f.r * .72) {
        const shield = prey.index === 2 ? p2ShieldTimer > 0 : shieldTimer > 0;
        const invuln = prey.index === 2 ? p2Invulnerable : invulnerable;
        if (shield) {
          if (prey.index === 2) p2ShieldTimer = 0; else shieldTimer = 0;
          f.life = 0;
          burst(f.x, f.y, "#9ceaff", 14);
        } else if (invuln <= 0) {
          if (prey.index === 2) {
            p2Lives = Math.max(0, p2Lives - 1); p2Invulnerable = 1.35;
            burst(player2.x, player2.y, "#62e9ff", 14); updateTwoPlayerHUD();
          } else { loseLife(); }
          f.x -= Math.cos(angle) * 35;
          f.y -= Math.sin(angle) * 35;
        }
      }
    });
    hunterFish = hunterFish.filter(f => f.life > 0 && f.x > -70 && f.x < W + 70 && f.y > 45 && f.y < H + 45);

    // Thu thập linh quang
    relics.forEach(r => {
      r.phase += dt * 2.5;

      const p1Collects = !r.got && distance(player, r) < player.r + r.r + 2;
      const p2Collects = !r.got && player2 && p2Lives > 0 && distance(player2, r) < player2.r + r.r + 2;
      if (p1Collects || p2Collects) {
        r.got = true;
        collected++;
        if (p2Collects && !p1Collects) p2Score += 100; else score += 100;

        burst(r.x, r.y, p2Collects && !p1Collects ? "#62e9ff" : "#f5d783", 12);
        playTone(620 + collected * 25, .08);
        updateHUD();

        if (collected >= chapter.count && !bossDefeated) {
          if (level === 3 || level === chapters.length - 1) {
            if (!boss) spawnBoss();
          } else {
            gateOpen = true;
          }
        }
      }
    });

    // Hoa sen thưởng: cộng điểm và hồi mạng
    if (!lotus && elapsed >= nextLotusAt) {
      const p = randomOpenPoint(70);

      lotus = {
        x: p.x, y: p.y, r: 12,
        life: 10, phase: 0
      };

      nextLotusAt = elapsed + rand(13, 18);
    }

    if (lotus) {
      lotus.life -= dt;
      lotus.phase += dt * 3;

      const p1GetsLotus = distance(player, lotus) < player.r + lotus.r;
      const p2GetsLotus = player2 && p2Lives > 0 && distance(player2, lotus) < player2.r + lotus.r;
      if (p1GetsLotus || p2GetsLotus) {
        if (p2GetsLotus && !p1GetsLotus) { p2Score += 250; p2Lives = Math.min(5, p2Lives + 1); }
        else { score += 250; lives = Math.min(5, lives + 1); }
        burst(lotus.x, lotus.y, p2GetsLotus && !p1GetsLotus ? "#62e9ff" : "#f4b8c3", 20);
        lotus = null;
        playTone(880, .13);
        updateHUD();
      } else if (lotus.life <= 0) {
        lotus = null;
      }
    }

    // Hoa sen hộ mệnh: khiên 6 giây
    if (!powerup && elapsed >= nextPowerAt) {
      const p = randomOpenPoint(75);

      powerup = {
        x: p.x, y: p.y, r: 13,
        life: 9, phase: 0, type: "shield"
      };

      nextPowerAt = elapsed + rand(18, 24);
    }

    if (powerup) {
      powerup.life -= dt;
      powerup.phase += dt * 3.5;

      const p1GetsPower = distance(player, powerup) < player.r + powerup.r;
      const p2GetsPower = player2 && p2Lives > 0 && distance(player2, powerup) < player2.r + powerup.r;
      if (p1GetsPower || p2GetsPower) {
        if (p2GetsPower && !p1GetsPower) { p2ShieldTimer = 6; p2Score += 120; }
        else { shieldTimer = 6; score += 120; }
        burst(powerup.x, powerup.y, p2GetsPower && !p1GetsPower ? "#62e9ff" : "#8fe8ed", 24);
        powerup = null;
        playTone(970, .15);
        updateHUD();
      } else if (powerup.life <= 0) {
        powerup = null;
      }
    }

    if (shieldTimer > 0) {
      shieldTimer = Math.max(0, shieldTimer - dt);
    }

    shotCooldown = Math.max(0, shotCooldown - dt);
    if (selectedCharacter === "lien" && lienCharge > 0) {
      lienChargeIdleTimer += dt;
      if (lienChargeIdleTimer >= 4) {
        lienCharge = Math.max(0, lienCharge - 1);
        lienChargeIdleTimer -= 1;
        if (lienCharge === 0) lienChargeIdleTimer = 0;
      }
    } else if (selectedCharacter !== "lien") {
      lienCharge = 0; lienChargeIdleTimer = 0;
    }
    if (leLoiComboTimer > 0) { leLoiComboTimer = Math.max(0, leLoiComboTimer - dt); if (leLoiComboTimer === 0) leLoiCombo = 0; }

    // Giữ Space để bắn kiếm quang
    if (keys[" "] || keys.Space) {
      aimP1AtNearestTarget();
      firePlayerShot();
    }

    // Cập nhật đạn của người chơi
    playerShots.forEach(s => {
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.life -= dt;
      // Vệt kiếm khí liên tục giúp chiêu nhìn rõ ở khoảng cách xa.
      if (s.trail && particles.length < PARTICLE_LIMIT && Math.random() < .32) {
        particles.push({
          x: s.x - s.vx * .018, y: s.y - s.vy * .018,
          vx: rand(-22, 22), vy: rand(-22, 22), life: .28, max: .28,
          color: Math.random() < .45 ? "#ffffff" : s.color, r: rand(2, 5)
        });
      }
    });

    playerShots = playerShots.filter(s =>
      s.life > 0 &&
      s.x > -20 && s.x < W + 20 &&
      s.y > 50 && s.y < H + 20
    );

    // Đạn người chơi phá đạn địch, hoa sen địch và boss
    for (let i = playerShots.length - 1; i >= 0; i--) {
      const s = playerShots[i];
      let consumed = false;

      for (let j = enemyShots.length - 1; j >= 0; j--) {
        if (distance(s, enemyShots[j]) < s.r + enemyShots[j].r + 2) {
          burst(enemyShots[j].x, enemyShots[j].y, "#f7e9b5", 5);

          enemyShots.splice(j, 1);
          if (!s.piercing) playerShots.splice(i, 1);
          consumed = !s.piercing;

          score += 10; if (s.coOpShot) p2Score += 10;
          updateHUD();
          break;
        }
      }

      if (consumed) continue;

      for (let j = hunterFish.length - 1; j >= 0; j--) {
        const fish = hunterFish[j];
        if (distance(s, fish) < s.r + fish.r) {
          fish.hp -= (s.damage || 1);
          registerLienBasicHit(s);
          fish.flash = .14;
          burst(s.x, s.y, "#9ceaff", 6);
          if (!s.piercing) playerShots.splice(i, 1);
          consumed = !s.piercing;
          if (fish.hp <= 0) {
            burst(fish.x, fish.y, "#80d9ef", 18);
            hunterFish.splice(j, 1);
            score += 100; if (s.coOpShot) p2Score += 100;
            playTone(420, .07);
            updateHUD();
          }
          if (s.lienShockOrb) lienShockBurst(s.x, s.y);
          break;
        }
      }

      if (consumed) continue;

      for (let j = turrets.length - 1; j >= 0; j--) {
        if (distance(s, turrets[j]) < s.r + turrets[j].r) {
          turrets[j].hp -= (s.damage || 1);
          registerLienBasicHit(s);
          turrets[j].flash = .12;

          burst(s.x, s.y, s.color || "#f6c7d4", 7);
          if (!s.piercing) playerShots.splice(i, 1);
          consumed = !s.piercing;

          if (turrets[j].hp <= 0) {
            burst(turrets[j].x, turrets[j].y, "#f29fb1", 24);

            turrets.splice(j, 1);
            score += 150; if (s.coOpShot) p2Score += 150;

            playTone(460, .09);
            updateHUD();
          }
          if (s.lienShockOrb) lienShockBurst(s.x, s.y);

          break;
        }
      }

      if (consumed) continue;
      if (boss && distance(s, boss) < s.r + boss.r * .83) {
        const damage = s.damage || 1;

        if (!s.piercing) playerShots.splice(i, 1);
        if (boss.invulnerable || (boss.damageGate || 0) > 0) {
          burst(s.x, s.y, "#8ff6ff", 3);
          continue;
        }

        boss.damageGate = 0.06;
        boss.hp -= damage;
        registerLienBasicHit(s);
        boss.flash = .12;
        if (s.lienShockOrb) lienShockBurst(s.x, s.y);

        if (boss.hp <= 0) {
          boss.hp = 0;
          // Cho phép nhánh kết liễu chạy dù đòn vừa trúng đã bật bộ giới hạn nhịp.
          boss.damageGate = 0;
          if (s.coOpShot && player2 && p2CombatState) withPlayerTwoContext(() => damageBoss());
          else damageBoss();
        }
      }
    } // THÊM DẤU NÀY ĐỂ ĐÓNG VÒNG LẶP FOR

    // Hoa sen địch ngắm người chơi và bắn đạn hồng
    turrets.forEach(t => {
      t.phase += dt * 1.5;
      t.fireTimer -= dt;
      t.flash = Math.max(0, t.flash - dt);

      // Mỗi hoa sen tự chọn người chơi còn sống ở gần nó nhất.
      const prey = getNearestLivingPlayer(t);
      if (t.fireTimer <= 0 && state === "playing") {
        if (prey && distance(t, prey.ref) < 560) {
          fireEnemyShot(
            t.x, t.y,
            prey.ref.x, prey.ref.y,
            165 + level * 25,
            0, "#f2a6c0"
          );
        }

        t.fireTimer =
          Math.max(.85, 1.9 - level * .22) + rand(0, .25);
      }
    });

    // Boss Huyền Quy
    if (boss) {
      boss.phase += dt;
      boss.flash = Math.max(0, boss.flash - dt);

      // Màn cuối: thả từng đợt cá săn mồi theo phần trăm máu Boss.
      // Mỗi ngưỡng chỉ kích hoạt một lần; nếu Boss mất nhiều máu trong một đòn,
      // các đợt tương ứng vẫn được thả riêng, không bị bỏ qua.
      if (state === "playing" && !boss.defeated) {
        const hpRatio = boss.maxHp > 0 ? boss.hp / boss.maxHp : 1;
        const bossFishWaves = [
          { threshold: 0.80, number: 1, count: 2 },
          { threshold: 0.60, number: 2, count: 2 },
          { threshold: 0.40, number: 3, count: 3 },
          { threshold: 0.20, number: 4, count: 3 }
        ];
        for (const wave of bossFishWaves) {
          if (bossFishWave < wave.number && hpRatio <= wave.threshold) {
            bossFishWave = wave.number;
            const finalBossStage = level === chapters.length - 1 ? boss.stage : 0;
            const minionKind = finalBossStage === 1 ? "ghost" : finalBossStage === 2 ? "guardian" : "fish";
            const fishHp = minionKind === "guardian" ? 42 : minionKind === "ghost" ? 34 : (level >= 2 ? 32 : 24);
            const fishSpeed = minionKind === "guardian" ? 92 + level * 4 : minionKind === "ghost" ? 108 + level * 4 : (difficulty === "hell" ? 150 : difficulty === "hard" ? 130 : difficulty === "easy" ? 100 : 115) + level * 10;
            for (let i = 0; i < wave.count; i++) {
              const fromLeft = Math.random() < 0.5;
              hunterFish.push({
                x: fromLeft ? -24 - i * 12 : W + 24 + i * 12,
                y: rand(90, H - 55), r: minionKind === "guardian" ? 18 : minionKind === "ghost" ? 15 : 16,
                kind: minionKind,
                speed: fishSpeed + rand(-8, 8),
                phase: rand(0, Math.PI * 2), life: 16,
                hp: fishHp, maxHp: fishHp, flash: 0
              });
            }
            const status = $("statusLabel");
            if (status) status.textContent = finalBossStage
              ? `${minionKind === "ghost" ? "BÓNG MA BOSS CŨ" : "HỘ VỆ KIẾM THẦN"} · ĐỢT ${wave.number}/4 · BOSS CÒN ${Math.round(hpRatio * 100)}%`
              : `ĐỢT CÁ ${wave.number}/4 · BOSS CÒN ${Math.round(hpRatio * 100)}% MÁU`;
          }
        }
      }

      // Ma Chủ Đoạt Kiếm: bộ pháp cong, tàn ảnh và đoạt vị có báo trước.
      if (boss.form === "demon" && !boss.defeated) {
        const dx = player.x - boss.x, dy = player.y - boss.y;
        const dist = Math.max(1, Math.hypot(dx, dy));
        boss.demonTeleportCooldown -= dt;
        boss.demonAfterimageTimer = Math.max(0, boss.demonAfterimageTimer - dt);
        if (boss.demonTeleportTimer > 0) {
          boss.demonTeleportTimer -= dt;
          if (boss.demonTeleportTimer <= 0) {
            const oldX = boss.x, oldY = boss.y;
            boss.x = boss.demonTeleportX;
            boss.y = boss.demonTeleportY;
            burst(oldX, oldY, "#c18aff", 15);
            burst(boss.x, boss.y, "#e3c8ff", 24);
            boss.demonTeleportCooldown = boss.transformed ? 4.2 : 5.4;
            boss.demonAfterimageTimer = .42;
            playTone(520, .09);
          }
        } else {
          // Truy kiếm ở gần; khi xa thì vòng cung để đổi góc tiếp cận.
          const desiredRange = dist < 155 ? 118 : 205;
          const radial = dist > desiredRange + 18 ? 1 : dist < desiredRange - 18 ? -0.68 : 0;
          const orbitSpeed = boss.transformed ? 112 : 86;
          const orbit = boss.demonOrbit * (dist < 170 ? .42 : .86);
          const vx = dx / dist * radial * orbitSpeed - dy / dist * orbitSpeed * orbit;
          const vy = dy / dist * radial * orbitSpeed + dx / dist * orbitSpeed * orbit;
          boss.x += vx * dt;
          boss.y += vy * dt;
          boss.x = Math.max(boss.r + 12, Math.min(W - boss.r - 12, boss.x));
          boss.y = Math.max(78 + boss.r, Math.min(H - boss.r - 12, boss.y));
          if (Math.sin(boss.phase * .75) > .997) boss.demonOrbit *= -1;
          boss.demonMoveAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);

          // Chỉ đoạt vị khi người chơi đã tạo khoảng cách; điểm đến nằm lệch bên cạnh/phía trước.
          if (dist > 325 && boss.demonTeleportCooldown <= 0 && state === "playing") {
            const side = Math.random() < .5 ? -1 : 1;
            const offset = 125 + Math.random() * 35;
            const tx = player.x + Math.cos(boss.demonMoveAngle) * 90 + Math.cos(boss.demonMoveAngle + Math.PI / 2) * offset * side;
            const ty = player.y + Math.sin(boss.demonMoveAngle) * 90 + Math.sin(boss.demonMoveAngle + Math.PI / 2) * offset * side;
            boss.demonTeleportX = Math.max(boss.r + 20, Math.min(W - boss.r - 20, tx));
            boss.demonTeleportY = Math.max(82 + boss.r, Math.min(H - boss.r - 18, ty));
            boss.demonTeleportTimer = .68;
            boss.demonAfterimageTimer = .68;
            const status = $("statusLabel");
            if (status) status.textContent = "MA CHỦ · ĐOẠT VỊ";
            playTone(340, .12);
          }
        }
      }

      // Ba kỹ năng riêng của Ma Chủ Đoạt Kiếm.
      if (boss.form === "demon" && !boss.defeated && state === "playing") {
        boss.demonSkillCooldown -= dt;
        if (boss.demonSkill === "idle" && boss.demonSkillCooldown <= 0) {
          // Luân phiên ba chiêu để người chơi có thể học nhịp và phản ứng.
          boss.demonSkillStep = (boss.demonSkillStep % 4) + 1;
          boss.demonSkill = boss.demonSkillStep === 1 ? "slash-windup" : boss.demonSkillStep === 2 ? "swords-windup" : boss.demonSkillStep === 3 ? "combo-windup" : "zones-windup";
          boss.demonSkillTimer = boss.demonSkillStep === 1 ? .68 : boss.demonSkillStep === 4 ? .82 : .72;
          boss.demonSkillAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
          boss.demonSkillSwords = [];
          boss.demonZones = []; boss.demonZoneIndex = 0;
          boss.demonSwordMode = boss.demonSkillStep === 2 ? "tracking" : boss.demonSkillStep === 3 ? "return" : "guard";
          if (boss.demonSkillStep === 2) {
            for (let i = 0; i < 5; i++) boss.demonSkillSwords.push({ angle: Math.PI * 2 * i / 5, radius: boss.r + 24 });
          }
          const label = $("statusLabel");
          if (label) label.textContent = boss.demonSkillStep === 1 ? "MA CHỦ · TRẢM NGUYỆT" : boss.demonSkillStep === 2 ? "MA CHỦ · VẠN KIẾM TRUY HỒN" : boss.demonSkillStep === 3 ? "MA CHỦ · ĐOẠT MỆNH LIÊN TRẢM" : "MA CHỦ · KIẾM VỰC TÁNG HỒN";
          playTone(boss.demonSkillStep === 1 ? 330 : 460, .13);
        }
        if (boss.demonSkill !== "idle") {
          boss.demonSkillTimer -= dt;
          if (boss.demonSkill === "slash-windup" && boss.demonSkillTimer <= 0) {
            boss.demonSkill = "slash-active";
            boss.demonSkillTimer = .36;
            boss.demonSkillAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
            burst(boss.x + Math.cos(boss.demonSkillAngle) * 78, boss.y + Math.sin(boss.demonSkillAngle) * 78, "#ff3d73", 34);
            burst(boss.x + Math.cos(boss.demonSkillAngle) * 118, boss.y + Math.sin(boss.demonSkillAngle) * 118, "#f7c9ff", 16);
            shake = Math.max(shake, 6);
          } else if (boss.demonSkill === "slash-active") {
            const ax = player.x - boss.x, ay = player.y - boss.y;
            const d = Math.hypot(ax, ay);
            const da = Math.atan2(Math.sin(Math.atan2(ay, ax) - boss.demonSkillAngle), Math.cos(Math.atan2(ay, ax) - boss.demonSkillAngle));
            if (d < 190 + player.r && Math.abs(da) < 1.12) {
              if (shieldTimer > 0) shieldTimer = 0;
              else if (invulnerable <= 0) { loseLife(); boss.demonSkill = "slash-recovery"; boss.demonSkillTimer = .45; }
            }
            if (boss.demonSkillTimer <= 0) { boss.demonSkill = "idle"; boss.demonSkillCooldown = boss.transformed ? 3.2 : 4.0; }
          } else if (boss.demonSkill === "swords-windup" && boss.demonSkillTimer <= 0) {
            boss.demonSkill = "swords-fire";
            boss.demonSkillTimer = .18;
            boss.demonSwordIndex = 0;
          } else if (boss.demonSkill === "swords-fire" && boss.demonSkillTimer <= 0) {
            const angle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
            const spread = (boss.demonSwordIndex - 2) * .105;
            fireEnemyShot(boss.x, boss.y, boss.x + Math.cos(angle + spread) * 100, boss.y + Math.sin(angle + spread) * 100,
              boss.transformed ? 285 : 235, 0, boss.demonSwordIndex % 2 ? "#e6b7ff" : "#a65cff");
            burst(boss.x + Math.cos(angle + spread) * 30, boss.y + Math.sin(angle + spread) * 30, "#d9a0ff", 5);
            boss.demonSwordIndex++;
            boss.demonSkillTimer = .22;
            if (boss.demonSwordIndex >= 5) { boss.demonSkill = "idle"; boss.demonSkillCooldown = boss.transformed ? 7.2 : 8.8; }
          } else if (boss.demonSkill === "zones-windup" && boss.demonSkillTimer <= 0) {
            boss.demonSkill = "zones-fire"; boss.demonSkillTimer = 1.34; boss.demonZoneIndex = 0; boss.demonZones = [];
            const toward = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
            for (let i = 0; i < 3; i++) {
              const a = toward + (i - 1) * .62;
              const dist = 105 + i * 24;
              boss.demonZones.push({ x: player.x + Math.cos(a) * dist, y: player.y + Math.sin(a) * dist, warn: .58 + i * .25, active: .24, done: false });
            }
            burst(boss.x, boss.y, "#c58aff", 28); shake = Math.max(shake, 5);
          } else if (boss.demonSkill === "zones-fire") {
            for (const zone of boss.demonZones) {
              zone.warn -= dt;
              if (!zone.done && zone.warn <= 0) {
                zone.done = true;
                burst(zone.x, zone.y, "#e7c6ff", 22); shake = Math.max(shake, 3);
                if (Math.hypot(player.x - zone.x, player.y - zone.y) < 72 + player.r) {
                  if (shieldTimer > 0) shieldTimer = 0;
                  else if (invulnerable <= 0) loseLife();
                }
              }
            }
            if (boss.demonSkillTimer <= 0) { boss.demonSkill = "zones-recovery"; boss.demonSkillTimer = .72; boss.demonSwordMode = "return"; }
          } else if (boss.demonSkill === "zones-recovery" && boss.demonSkillTimer <= 0) {
            boss.demonSkill = "idle"; boss.demonSkillCooldown = boss.transformed ? 12 : 14;
          } else if (boss.demonSkill === "combo-windup" && boss.demonSkillTimer <= 0) {
            boss.demonSkill = "combo-dash1";
            boss.demonSkillTimer = .22;
            boss.demonSkillAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
          } else if (boss.demonSkill === "combo-dash1" || boss.demonSkill === "combo-dash2") {
            const speed = boss.transformed ? 520 : 440;
            boss.x += Math.cos(boss.demonSkillAngle) * speed * dt;
            boss.y += Math.sin(boss.demonSkillAngle) * speed * dt;
            boss.x = Math.max(boss.r + 10, Math.min(W - boss.r - 10, boss.x));
            boss.y = Math.max(78 + boss.r, Math.min(H - boss.r - 10, boss.y));
            boss.demonAfterimageTimer = .16;
            if (Math.hypot(player.x - boss.x, player.y - boss.y) < boss.r + player.r + 7) {
              if (shieldTimer > 0) shieldTimer = 0;
              else if (invulnerable <= 0) loseLife();
            }
            if (boss.demonSkillTimer <= 0) {
              if (boss.demonSkill === "combo-dash1") {
                boss.demonSkill = "combo-dash2"; boss.demonSkillTimer = .22;
                boss.demonSkillAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
              } else {
                boss.demonSkill = "combo-slam"; boss.demonSkillTimer = .34;
                burst(boss.x, boss.y, "#a65cff", 28); shake = Math.max(shake, 7);
                for (let i = 0; i < 12; i++) {
                  const a = Math.PI * 2 * i / 12;
                  fireEnemyShot(boss.x, boss.y, boss.x + Math.cos(a) * 100, boss.y + Math.sin(a) * 100,
                    boss.transformed ? 220 : 185, 0, "#c18aff");
                }
              }
            }
          } else if (boss.demonSkill === "combo-slam" && boss.demonSkillTimer <= 0) {
            if (Math.hypot(player.x - boss.x, player.y - boss.y) < 92 + player.r) {
              if (shieldTimer > 0) shieldTimer = 0;
              else if (invulnerable <= 0) loseLife();
            }
            boss.demonSkill = "idle"; boss.demonSkillCooldown = boss.transformed ? 9.5 : 11;
          } else if (boss.demonSkill === "slash-recovery" && boss.demonSkillTimer <= 0) {
            boss.demonSkill = "idle"; boss.demonSkillCooldown = 3.8;
          }
        }
      }

      // Hắc Long và Huyền Quy húc hai lần liên tiếp, sau đó lùi về trong trạng thái bất tử.
      // Khi ở trạng thái bình thường, cả hai vẫn di chuyển lên xuống theo nhịp sin.
      if (boss.chargeState === "idle") {
        if (boss.form === "dragon") {
          // Hắc Long chủ động săn đuổi và đảo cánh quanh người chơi, không còn
          // đứng giữ một vị trí như Huyền Quy. Dạng cuồng nộ ép sát hơn.
          const bossTarget = getNearestLivingPlayer(boss)?.ref || player;
          const dxToPlayer = bossTarget.x - boss.x;
          const dyToPlayer = bossTarget.y - boss.y;
          const distToPlayer = Math.max(1, Math.hypot(dxToPlayer, dyToPlayer));
          const preferredRange = boss.transformed ? 170 : 225;
          const approach = distToPlayer > preferredRange + 24 ? 1 : distToPlayer < preferredRange - 24 ? -0.72 : 0;
          const strafe = boss.dragonStrafe || 1;
          const speed = boss.transformed ? 118 : 82;
          boss.x += (dxToPlayer / distToPlayer * approach * speed - dyToPlayer / distToPlayer * strafe * speed * .78) * dt;
          boss.y += (dyToPlayer / distToPlayer * approach * speed + dxToPlayer / distToPlayer * strafe * speed * .78) * dt;
          boss.x = Math.max(boss.r + 12, Math.min(W - boss.r - 12, boss.x));
          boss.y = Math.max(78 + boss.r, Math.min(H - boss.r - 12, boss.y));
          if (Math.sin(boss.phase * .9) > .997) boss.dragonStrafe *= -1;
        } else if (boss.form === "turtle") {
          boss.x = W - 205 + Math.sin(boss.phase * .7) * 13;
          boss.y = H / 2 + Math.sin(boss.phase * 1.15) * 135;
        }
        if (boss.form !== "demon") boss.chargeCooldown -= dt;
        if (boss.form !== "demon" && boss.chargeCooldown <= 0 && state === "playing") {
          boss.chargeCount = 0;
          boss.chargeOriginX = W - 205;
          boss.chargeOriginY = H / 2;
          boss.chargeAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
          boss.chargeState = "telegraph";
          boss.chargeTimer = 1.25;
          playTone(260, .16);
        }
      } else if (boss.chargeState === "telegraph") {
        boss.chargeTimer -= dt;
        if (boss.chargeTimer <= 0) {
          boss.chargeState = "charging";
          boss.chargeTimer = .95;
          playTone(115, .2);
        }
      } else if (boss.chargeState === "charging") {
        const dashSpeed = boss.transformed ? 570 : 500;
        boss.x += Math.cos(boss.chargeAngle) * dashSpeed * dt;
        boss.y += Math.sin(boss.chargeAngle) * dashSpeed * dt;
        boss.chargeTimer -= dt;
        if (boss.chargeTimer <= 0 || boss.x < boss.r || boss.x > W - boss.r || boss.y < 75 + boss.r || boss.y > H - boss.r) {
          boss.x = Math.max(boss.r, Math.min(W - boss.r, boss.x));
          boss.y = Math.max(75 + boss.r, Math.min(H - boss.r, boss.y));
          burst(boss.x, boss.y, "#b7faff", 24);
          burst(boss.x, boss.y, "#f5d5ff", 16);
          shake = Math.max(shake, 5);
          playTone(440, .18);
          if (boss.form === "dragon" || boss.form === "turtle") {
            boss.chargeCount++;
            if (boss.chargeCount < 2) {
              // Lần húc thứ hai được báo trước ngắn, không chen pha hồi chiêu.
              boss.chargeAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
              boss.chargeState = "telegraph";
              boss.chargeTimer = .38;
            } else if (boss.form === "dragon") {
              // Hắc Long không lùi về điểm xuất phát: kết thúc cú húc thứ hai
              // rồi tiếp tục săn đuổi người chơi ngay trong trạng thái bình thường.
              boss.chargeState = "idle";
              boss.chargeCooldown = boss.transformed ? 3.0 : 4.2;
              boss.chargeCount = 0;
              boss.invulnerable = !!(boss.transformTimer > 0);
              burst(boss.x, boss.y, "#ff6338", 24);
              burst(boss.x, boss.y, "#ffbd68", 18);
            } else {
              boss.chargeState = "retreating";
              boss.invulnerable = true;
              burst(boss.x, boss.y, "#a020f0", 24);
              burst(boss.x, boss.y, "#ff365d", 18);
            }
          } else {
            boss.chargeState = "stunned";
            boss.chargeTimer = 1.05;
          }
        }
      } else if (boss.chargeState === "retreating") {
        // Huyền Quy chỉ bất tử trong đúng lúc đang lùi về; các boss khác giữ cơ chế cũ.
        boss.invulnerable = boss.form === "turtle" ? true : true;
        const dx = boss.chargeOriginX - boss.x;
        // Huyền Quy vẫn bơi lên xuống trong lúc lùi về; chỉ Hắc Long quay thẳng
        // về điểm xuất phát theo cả hai trục.
        if (boss.form === "turtle") {
          boss.y = Math.max(75 + boss.r, Math.min(H - boss.r,
            H / 2 + Math.sin(boss.phase * 1.15) * 135));
        }
        const dy = boss.form === "turtle" ? 0 : boss.chargeOriginY - boss.y;
        const dist = Math.hypot(dx, dy);
        // Dùng một bước di chuyển theo độ dài vector để không vượt quá điểm đích
        // khi lùi chéo; luôn chốt tọa độ chính xác trước khi vào hồi chiêu.
        if (dist <= 7 || dist === 0) {
          boss.x = boss.chargeOriginX;
          if (boss.form !== "turtle") boss.y = boss.chargeOriginY;
          boss.chargeState = "cooldown";
          boss.chargeTimer = 10;
          // Hết lùi về thì Huyền Quy nhận sát thương bình thường trong thời gian hồi chiêu.
          boss.invulnerable = boss.form !== "turtle";
          burst(boss.x, boss.y, "#a020f0", 20);
          burst(boss.x, boss.y, "#ff365d", 16);
        } else {
          const retreatSpeed = 300;
          const step = Math.min(retreatSpeed * dt, dist);
          boss.x += dx / dist * step;
          if (boss.form !== "turtle") boss.y += dy / dist * step;
          // Chốt chính xác nếu bước này đã chạm điểm đích.
          if (step >= dist - 0.001) {
            boss.x = boss.chargeOriginX;
            if (boss.form !== "turtle") boss.y = boss.chargeOriginY;
          }
        }
      } else if (boss.chargeState === "cooldown") {
        // Huyền Quy không được đứng im trong 10 giây hồi chiêu:
        // tiếp tục bơi lên xuống tại vị trí ngang đã lùi về.
        if (boss.form === "turtle") {
          boss.y = Math.max(75 + boss.r, Math.min(H - boss.r,
            H / 2 + Math.sin(boss.phase * 1.15) * 135));
        } else if (boss.form === "dragon") {
          // Sau khi lùi về, Hắc Long đứng đúng điểm xuất phát trong toàn bộ 10 giây hồi chiêu.
          boss.x = boss.chargeOriginX;
          boss.y = boss.chargeOriginY;
        }
        boss.chargeTimer -= dt;
        if (boss.chargeTimer <= 0) {
          boss.chargeState = "idle";
          boss.chargeCooldown = 0;
          boss.invulnerable = boss.form === "turtle" ? false : !!(boss.transformTimer > 0);
          burst(boss.x, boss.y, "#ff7048", 12);
        }
      } else if (boss.chargeState === "stunned") {
        boss.chargeTimer -= dt;
        if (boss.chargeTimer <= 0) boss.chargeState = "idle";
      }

      // Giai đoạn cuối: biến hình trong trạng thái bất tử ngắn, sau đó có thể bị đánh lại.
      if (!boss.transformed && boss.hp <= boss.maxHp * .25) {
        boss.transformed = true;
        // Chỉ Hắc Long và Ma Chủ bất tử sau khi đổi dạng. Huyền Quy không còn bất tử do biến hình.
        boss.transformTimer = (boss.stage === 1 || boss.stage === 2) ? 5 : 0;
        boss.invulnerable = boss.form !== "turtle";
        boss.laserCooldown = .65;
        shake = Math.max(shake, 8);
        burst(boss.x, boss.y, "#9c7cff", 42);
        burst(boss.x, boss.y, "#72f4ff", 30);
        playTone(180, .24);
        $("statusLabel").textContent = boss.stage === 1 ? "HẮC LONG CUỒNG NỘ" : boss.stage === 2 ? "MA CHỦ BÙNG NỔ SỨC MẠNH" : "HUYỀN QUY THỨC TỈNH";
        $("goalText").textContent = boss.stage === 1
          ? "Hắc Long cuồng nộ! Né hắc viêm và phản công khi luồng năng lượng suy yếu."
          : boss.stage === 2
            ? "Ma Chủ giải phóng sức mạnh cuối cùng! Né kiếm trận và tìm thời cơ phản công."
            : "Huyền Quy đã thức tỉnh! Né tia laser và phản công khi lớp giáp tím suy yếu.";
      }
      boss.damageGate = Math.max(0, (boss.damageGate || 0) - dt);
      if (boss.transformTimer > 0) {
        boss.transformTimer = Math.max(0, boss.transformTimer - dt);
        // Với Huyền Quy, chỉ pha lùi về mới bật bất tử; không để bộ đếm biến hình ghi đè.
        boss.invulnerable = boss.form === "turtle"
          ? boss.chargeState === "retreating"
          : boss.transformTimer > 0;
        if (boss.transformTimer === 0) {
          burst(boss.x, boss.y, "#b7faff", 22);
          $("statusLabel").textContent = boss.stage === 1 ? "HẮC LONG CUỒNG NỘ" : boss.stage === 2 ? "MA CHỦ BÙNG NỔ SỨC MẠNH" : "HUYỀN QUY THỨC TỈNH";
        }
      }

      // Chiêu đặc biệt theo từng dạng boss, luôn có thời gian báo trước.
      if (boss.form !== "demon") boss.specialCooldown -= dt;
      if (boss.form !== "demon" && boss.specialTelegraph > 0) {
        boss.specialTelegraph -= dt;
        if (boss.specialTelegraph <= 0 && state === "playing") {
          const aim = boss.specialAngle;
          if (boss.form === "dragon") {
            // Ba kiểu tấn công luân phiên để Hắc Long không chỉ bắn một quạt lửa:
            // Hắc Viêm quét quạt, Long Ảnh liên kích, và Long Chấn tỏa vòng.
            const pattern = boss.dragonAttackIndex % 3;
            const shotSpeed = boss.transformed ? 255 : 210;
            if (pattern === 0) {
              // Hắc Viêm Truy Ảnh: cầu lửa to hơn một chút, bẻ hướng liên tục
              // để bám theo người chơi thay vì chỉ bay thẳng.
              const orbColor = boss.transformed ? "#d36bff" : "#ff7048";
              for (const offset of [-0.24, 0, 0.24]) {
                const a = aim + offset;
                fireHomingFireball(boss.x - 18, boss.y,
                  boss.x + Math.cos(a) * 100, boss.y + Math.sin(a) * 100,
                  boss.transformed ? 175 : 150, orbColor);
              }
              burst(boss.x + Math.cos(aim) * 35, boss.y + Math.sin(aim) * 35, "#ff8a54", 18);
            } else if (pattern === 1) {
              // Ba nhịp Long Ảnh khóa các hướng lệch nhau; người chơi phải đổi hướng né.
              for (const offset of [-0.34, 0, 0.34]) {
                const a = aim + offset;
                fireEnemyShot(boss.x - 18, boss.y, boss.x + Math.cos(a) * 120,
                  boss.y + Math.sin(a) * 120, shotSpeed * 1.08, 0, "#ffbd68");
              }
              burst(boss.x, boss.y, "#d65cff", 22);
            } else {
              // Long Chấn: vòng đạn lan tỏa, chừa khe hở giữa các hướng.
              const count = boss.transformed ? 12 : 10;
              for (let i = 0; i < count; i++) {
                const a = (Math.PI * 2 * i / count) + boss.phase * .22;
                fireEnemyShot(boss.x, boss.y, boss.x + Math.cos(a) * 100,
                  boss.y + Math.sin(a) * 100, boss.transformed ? 205 : 170, 0, "#b94cff");
              }
              shake = Math.max(shake, boss.transformed ? 7 : 4);
              burst(boss.x, boss.y, "#ff633f", 26);
            }
            boss.dragonAttackIndex++;
            boss.specialCooldown = boss.transformed ? 3.5 : 4.6;
          } else if (boss.form === "demon") {
            // Ma Chủ: kiếm khí bóng tối ba nhánh.
            for (let i = -1; i <= 1; i++) {
              const a = aim + i * 0.22;
              fireEnemyShot(boss.x - 18, boss.y, boss.x + Math.cos(a) * 100,
                boss.y + Math.sin(a) * 100, boss.transformed ? 255 : 215, 0, "#c18aff");
            }
            boss.specialCooldown = boss.transformed ? 4.4 : 5.8;
          } else {
            // Huyền Quy: đợt sóng năng lượng thẳng, chậm nhưng dễ đọc hướng.
            for (let i = -1; i <= 1; i++) {
              const a = aim + i * 0.13;
              fireEnemyShot(boss.x - 18, boss.y, boss.x + Math.cos(a) * 100,
                boss.y + Math.sin(a) * 100, 185, 0, "#8deaff");
            }
            boss.specialCooldown = 6.2;
          }
        }
      } else if (boss.form !== "demon" && boss.specialCooldown <= 0 && state === "playing" && boss.chargeState !== "charging" && boss.chargeState !== "telegraph") {
        boss.specialAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
        boss.specialTelegraph = boss.form === "dragon" ? 0.85 : 0.72;
        if (boss.form === "dragon") {
          const names = ["HẮC VIÊM QUÉT NGANG", "LONG ẢNH LIÊN KÍCH", "LONG CHẤN · SÓNG XUNG KÍCH"];
          const status = $("statusLabel");
          if (status) status.textContent = names[boss.dragonAttackIndex % 3];
        }
        playTone(boss.form === "dragon" ? 310 : 420, 0.12);
      }

      // Laser có thời gian báo trước để người chơi kịp né.
      boss.laserCooldown -= dt;
      if (boss.laserTelegraph > 0) {
        boss.laserTelegraph -= dt;
        if (boss.laserTelegraph <= 0) {
          boss.laserActive = boss.transformed ? .72 : .48;
          boss.laserSweep = 0;
          playTone(780, .12);
        }
      } else if (boss.laserActive > 0) {
        boss.laserActive -= dt;
        boss.laserSweep += dt * (boss.transformed ? .34 : .16);
      } else if (boss.laserCooldown <= 0 && state === "playing" && boss.hp <= boss.maxHp / 2) {
        boss.laserAngle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
        boss.laserTelegraph = boss.form === "demon" ? .68 : boss.form === "dragon" ? .9 : (boss.transformed ? .58 : .82);
        boss.laserCooldown = boss.form === "demon"
          ? (boss.transformed ? 1.55 : 2.1)
          : boss.form === "dragon"
            ? (boss.transformed ? 1.9 : 2.8)
            : (boss.transformed ? 2.25 : 3.1);
      }

      // Tia laser gây sát thương theo khoảng cách từ người chơi đến trục tia.
      if (boss.laserActive > 0) {
        const a = boss.laserAngle + Math.sin(boss.laserSweep) * (boss.transformed ? .13 : .035);
        const dx = player.x - boss.x, dy = player.y - boss.y;
        const along = dx * Math.cos(a) + dy * Math.sin(a);
        const across = Math.abs(-dx * Math.sin(a) + dy * Math.cos(a));
        if (along > 0 && along < Math.max(W, H) && across < player.r + (boss.transformed ? 13 : 9)) {
          if (shieldTimer > 0) {
            shieldTimer = 0;
            boss.laserActive = 0;
            burst(player.x, player.y, "#a4f8ff", 20);
          } else if (invulnerable <= 0) loseLife();
        }
      }

      boss.shootTimer -= dt;

      // Dạng 1: bắn thành loạt 3 viên liên tiếp, cách nhau rất ngắn.
      if (boss.burstRemaining > 0) {
        boss.burstTimer -= dt;
        if (boss.burstTimer <= 0 && state === "playing") {
          const angle = Math.atan2((getNearestLivingPlayer(boss)?.ref || player).y - boss.y, (getNearestLivingPlayer(boss)?.ref || player).x - boss.x);
          fireEnemyShot(
            boss.x - 25, boss.y,
            boss.x + Math.cos(angle) * 100,
            boss.y + Math.sin(angle) * 100,
            165, 0, boss.form === "dragon" ? "#ff985c" : boss.form === "demon" ? "#c69cff" : "#9ceaff"
          );
          boss.burstRemaining--;
          boss.burstTimer = .18;
        }
      }

      if (boss.shootTimer <= 0 && state === "playing") {
        const baseAngle = Math.atan2(
          player.y - boss.y,
          player.x - boss.x
        );

        const speed = boss.hp <= boss.maxHp / 2 ? 205 : 165;

        if (boss.hp <= boss.maxHp / 2) {
          // Nửa máu: đạn tỏa kết hợp các viên laser năng lượng.
          const spread = boss.form === "demon"
            ? [-.72, -.5, -.28, 0, .28, .5, .72]
            : boss.form === "dragon"
              ? [-.52, -.3, -.1, .1, .3, .52]
              : (boss.transformed ? [-.62, -.4, -.2, 0, .2, .4, .62] : [-.34, -.17, 0, .17, .34]);
          const shotColor = boss.form === "dragon" ? "#ff985c" : boss.form === "demon" ? "#c69cff" : (boss.transformed ? "#c69cff" : "#9ceaff");
          spread.forEach(off => {
            fireEnemyShot(
              boss.x - 25, boss.y,
              boss.x + Math.cos(baseAngle + off) * 100,
              boss.y + Math.sin(baseAngle + off) * 100,
              speed, 0, shotColor
            );
          });
          if (boss.transformed || boss.form === "demon") {
            [-.16, .16].forEach(off => fireEnemyShot(
              boss.x - 31, boss.y,
              boss.x + Math.cos(baseAngle + off) * 120,
              boss.y + Math.sin(baseAngle + off) * 120,
              speed * 1.18, 0, boss.form === "dragon" ? "#ffd078" : "#ff8bf2"
            ));
          }

          boss.shootTimer = boss.form === "demon" ? (boss.transformed ? .58 : .78) : boss.form === "dragon" ? (boss.transformed ? .68 : .88) : (boss.transformed ? .72 : .95);
        } else {
          // Khi còn nhiều máu, bắn viên đầu tiên rồi nối tiếp thêm 2 viên.
          fireEnemyShot(
            boss.x - 25, boss.y,
            boss.x + Math.cos(baseAngle) * 100,
            boss.y + Math.sin(baseAngle) * 100,
            speed, 0, boss.form === "dragon" ? "#ff985c" : boss.form === "demon" ? "#c69cff" : "#9ceaff"
          );
          boss.burstRemaining = boss.form === "demon" ? 3 : 2;
          boss.burstTimer = .18;
          boss.shootTimer = boss.form === "demon" ? .95 : boss.form === "dragon" ? 1.15 : 1.35;
        }
      }

      if (distance(player, boss) < player.r + boss.r * .72) {
        loseLife();
      }
    }

    // Đạn địch va chạm với người chơi
    enemyShots.forEach(s => {
      // Cầu lửa truy đuổi cập nhật hướng mỗi khung hình, có giới hạn tốc độ xoay
      // để người chơi vẫn có thể né bằng cách đổi hướng hoặc lách qua vật cản.
      if (s.homing && player && state === "playing") {
        const targetAngle = Math.atan2(player.y - s.y, player.x - s.x);
        const currentAngle = Math.atan2(s.vy, s.vx);
        let deltaAngle = Math.atan2(Math.sin(targetAngle - currentAngle), Math.cos(targetAngle - currentAngle));
        const maxTurn = (s.turnRate || 2.0) * dt;
        deltaAngle = Math.max(-maxTurn, Math.min(maxTurn, deltaAngle));
        const nextAngle = currentAngle + deltaAngle;
        const speed = Math.hypot(s.vx, s.vy) || 150;
        s.vx = Math.cos(nextAngle) * speed;
        s.vy = Math.sin(nextAngle) * speed;
      }
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.life -= dt;
      // Vệt kiếm khí liên tục giúp chiêu nhìn rõ ở khoảng cách xa.
      if (s.trail && particles.length < PARTICLE_LIMIT && Math.random() < .32) {
        particles.push({
          x: s.x - s.vx * .018, y: s.y - s.vy * .018,
          vx: rand(-22, 22), vy: rand(-22, 22), life: .28, max: .28,
          color: Math.random() < .45 ? "#ffffff" : s.color, r: rand(2, 5)
        });
      }
    });

    enemyShots = enemyShots.filter(s =>
      s.life > 0 &&
      s.x > -30 && s.x < W + 30 &&
      s.y > 48 && s.y < H + 30
    );

    enemyShots.forEach(s => {
      if (distance(player, s) < player.r + s.r) {
        if (shieldTimer > 0) {
          shieldTimer = 0;
          burst(player.x, player.y, "#8fe8ed", 18);
          playTone(520, .08);
          s.life = 0;
        } else {
          s.life = 0;
          loseLife();
        }
      }
    });

    enemyShots = enemyShots.filter(s => s.life > 0);

    // Bụi lau gai
    reedPatches.forEach(r => {
      r.phase += dt;

      if (distance(player, r) < player.r + r.r * .72) {
        if (shieldTimer > 0) {
          shieldTimer = 0;
          burst(r.x, r.y, "#8fe8ed", 10);
        } else {
          loseLife();
        }
      }
    });

    // Xoáy nước di chuyển
    hazards.forEach(h => {
      h.phase += dt * (1.1 + chapter.speed * .4);

      h.x += h.vx * dt;
      h.y += h.vy * dt;

      if (h.x < 45 || h.x > W - 45) h.vx *= -1;
      if (h.y < 82 || h.y > H - 42) h.vy *= -1;

      if (distance(player, h) < player.r + h.r * .72) {
        if (shieldTimer > 0) {
          shieldTimer = 0;
          burst(player.x, player.y, "#8fe8ed", 12);
        } else {
          loseLife();
        }
      }
    });

    // Hiệu ứng hạt sáng
    particles.forEach(p => {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= .985;
      p.vy *= .985;
      p.life -= dt;
    });

    particles = particles.filter(p => p.life > 0);

    ripples.forEach(r => {
      r.r += 38 * dt;
      r.life -= dt;
    });

    ripples = ripples.filter(r => r.life > 0);

    // Chỉ qua màn cuối khi boss đã bị đánh bại
    if (
      state === "playing" &&
      gateOpen &&
      !boss &&
      (
        (player.x > W - 85 && player.y > H * .32 && player.y < H * .68) ||
        (player2 && p2Lives > 0 && player2.x > W - 85 && player2.y > H * .32 && player2.y < H * .68)
      )
    ) {
      // Cả P1 lẫn P2 đều có thể chạm cổng Tháp Rùa để kích hoạt vượt màn.
      finishChapter();
    }
  }

  function roundedRect(x, y, w, h, r, fill) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
    ctx.fillStyle = fill;
    ctx.fill();
  }

  function drawBackground() {
    const g = ctx.createLinearGradient(0, 0, W, H);

    if (level === chapters.length - 1) {
      g.addColorStop(0, "#482b57");
      g.addColorStop(.48, "#241f48");
      g.addColorStop(1, "#10152f");
    } else if (level === chapters.length - 2) {
      g.addColorStop(0, "#604b35");
      g.addColorStop(.48, "#263e4c");
      g.addColorStop(1, "#142b3a");
    } else {
      g.addColorStop(0, "#2a7168");
      g.addColorStop(.48, "#195a54");
      g.addColorStop(1, "#0c3d3c");
    }

    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    // Bờ hồ
    ctx.fillStyle = "#17443a";
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(W, 0);
    ctx.lineTo(W, 55);
    ctx.quadraticCurveTo(W * .7, 78, W * .45, 48);
    ctx.quadraticCurveTo(W * .2, 25, 0, 70);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#245c48";
    ctx.beginPath();
    ctx.moveTo(0, H);
    ctx.lineTo(W, H);
    ctx.lineTo(W, H - 27);
    ctx.quadraticCurveTo(W * .6, H - 52, W * .3, H - 25);
    ctx.quadraticCurveTo(W * .12, H - 10, 0, H - 35);
    ctx.closePath();
    ctx.fill();

    // Gợn nước
    for (let i = 0; i < 42; i++) {
      const x = (i * 137 + 29) % W;
      const y = 85 + ((i * 83) % (H - 135));
      const shift = Math.sin(elapsed * .6 + i) * 9;

      ctx.beginPath();
      ctx.ellipse(
        x + shift, y,
        13 + (i % 4) * 4, 2.2,
        -.08, 0, Math.PI * 2
      );

      ctx.strokeStyle =
        `rgba(166, 226, 205, ${.07 + (i % 3) * .025})`;
      ctx.lineWidth = 1.3;
      ctx.stroke();
    }

    // Tán cây hai bên
    for (let side of [0, 1]) {
      for (let i = 0; i < 8; i++) {
        const x = side === 0 ? 12 + i * 13 : W - 12 - i * 13;
        const y = 78 + (i % 3) * 22;

        ctx.fillStyle = i % 2 ? "#214f3c" : "#2a6347";
        ctx.beginPath();
        ctx.arc(x, y, 14 + (i % 3) * 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Đường dẫn tới Tháp Rùa
    ctx.save();
    ctx.setLineDash([5, 12]);
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = gateOpen ? "#f2d58b99" : "#d9e8cf28";

    ctx.beginPath();
    ctx.moveTo(W - 68, H * .32);
    ctx.lineTo(W - 68, H * .68);
    ctx.stroke();
    ctx.restore();

    drawTurtleTower();
  }

  function drawTurtleTower() {
    const x = W - 68, y = H / 2;

    ctx.save();
    ctx.globalAlpha = gateOpen ? 1 : .72;

    const glow = ctx.createRadialGradient(
      x, y, 4, x, y, gateOpen ? 82 : 53
    );

    glow.addColorStop(
      0, gateOpen ? "#f6d98b50" : "#e7d49a16"
    );
    glow.addColorStop(1, "#f6d98b00");

    ctx.fillStyle = glow;
    ctx.fillRect(x - 90, y - 90, 180, 180);

    // Đảo nhỏ
    ctx.fillStyle = "#c5a96a";
    ctx.beginPath();
    ctx.ellipse(x, y + 33, 40, 13, 0, 0, Math.PI * 2);
    ctx.fill();

    // Chân tháp
    ctx.fillStyle = "#e4d4a4";
    ctx.beginPath();
    ctx.moveTo(x - 27, y + 28);
    ctx.lineTo(x - 23, y - 3);
    ctx.lineTo(x + 23, y - 3);
    ctx.lineTo(x + 27, y + 28);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#a84f3e";
    ctx.fillRect(x - 20, y - 3, 40, 6);

    // Tầng giữa
    ctx.fillStyle = "#eadbb3";
    ctx.fillRect(x - 19, y - 24, 38, 22);

    ctx.fillStyle = "#b64c3d";
    ctx.beginPath();
    ctx.moveTo(x - 25, y - 24);
    ctx.lineTo(x, y - 37);
    ctx.lineTo(x + 25, y - 24);
    ctx.closePath();
    ctx.fill();

    // Tầng trên
    ctx.fillStyle = "#e8d9b1";
    ctx.fillRect(x - 12, y - 42, 24, 18);

    ctx.fillStyle = "#a94437";
    ctx.beginPath();
    ctx.moveTo(x - 17, y - 42);
    ctx.lineTo(x, y - 52);
    ctx.lineTo(x + 17, y - 42);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#f8e7b5";
    ctx.fillRect(x - 2, y - 47, 4, 5);

    if (gateOpen) {
      ctx.strokeStyle = "#f6d98b";
      ctx.lineWidth = 2;

      ctx.beginPath();
      ctx.arc(
        x, y, 45 + Math.sin(elapsed * 4) * 4,
        0, Math.PI * 2
      );
      ctx.stroke();

      ctx.fillStyle = "#fff0b8";
      ctx.font = "bold 12px Segoe UI";
      ctx.textAlign = "center";
      ctx.fillText("ĐẾN ĐÍCH", x, y + 63);
    } else {
      ctx.fillStyle = "#e7d6a9";
      ctx.font = "10px Segoe UI";
      ctx.textAlign = "center";
      ctx.fillText("THÁP RÙA", x, y + 62);
    }

    ctx.restore();
  }

  function drawRelic(r) {
    if (r.got) return;

    const pulse = Math.sin(r.phase) * 2;

    ctx.save();
    ctx.translate(r.x, r.y);
    ctx.rotate(r.phase * .2);
    ctx.shadowColor = "#ffdf83";
    ctx.shadowBlur = 16;
    ctx.fillStyle = "#ffe8a0";

    ctx.beginPath();
    ctx.moveTo(0, -r.r - pulse);
    ctx.lineTo(r.r * .55, 0);
    ctx.lineTo(0, r.r + pulse);
    ctx.lineTo(-r.r * .55, 0);
    ctx.closePath();
    ctx.fill();

    ctx.shadowBlur = 0;
    ctx.strokeStyle = "#fff8d8";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
  }

  function drawHazard(h) {
    ctx.save();
    ctx.translate(h.x, h.y);
    ctx.rotate(h.phase * .25);

    const r = h.r + Math.sin(h.phase * 2) * 2;

    ctx.fillStyle = "#0b3539a8";
    ctx.beginPath();
    ctx.arc(0, 0, r + 5, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "#83d8d0";
    ctx.lineWidth = 2;
    ctx.globalAlpha = .68;

    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(
        0, 0, r * (.38 + i * .23),
        h.phase + i,
        h.phase + i + Math.PI * 1.5
      );
      ctx.stroke();
    }

    ctx.globalAlpha = .8;
    ctx.fillStyle = "#9ce5df";
    ctx.beginPath();
    ctx.arc(0, 0, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawLotus() {
    if (!lotus) return;

    ctx.save();
    ctx.translate(lotus.x, lotus.y);
    ctx.rotate(lotus.phase * .15);
    ctx.shadowColor = "#f2b9c8";
    ctx.shadowBlur = 18;

    for (let i = 0; i < 6; i++) {
      ctx.rotate(Math.PI / 3);
      ctx.fillStyle = i % 2 ? "#f2b9c8" : "#ffcfce";

      ctx.beginPath();
      ctx.ellipse(0, -8, 5, 10, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = "#f7dc83";
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawTurret(t) {
    ctx.save();
    ctx.translate(t.x, t.y);
    ctx.rotate(Math.sin(t.phase) * .08);

    ctx.shadowColor = "#e99db8";
    ctx.shadowBlur = t.flash > 0 ? 20 : 9;

    for (let i = 0; i < 6; i++) {
      ctx.save();
      ctx.rotate(i * Math.PI / 3);
      ctx.fillStyle = i % 2 ? "#9a5c83" : "#c7799a";

      ctx.beginPath();
      ctx.ellipse(0, -11, 6, 13, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    ctx.shadowBlur = 0;
    ctx.fillStyle = "#3b3348";
    ctx.beginPath();
    ctx.arc(0, 0, 7, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#ffe5f1";
    ctx.beginPath();
    ctx.arc(0, 0, 3, 0, Math.PI * 2);
    ctx.fill();

    // Thanh máu hoa sen địch
    ctx.fillStyle = "#203835";
    ctx.fillRect(-13, 20, 26, 3);
    ctx.fillStyle = "#f1a6c2";
    ctx.fillRect(-13, 20, 26 * (t.hp / t.maxHp), 3);

    ctx.restore();
  }

  function drawReedPatch(r) {
    ctx.save();
    ctx.translate(r.x, r.y);
    ctx.rotate(Math.sin(r.phase * 1.8) * .1);

    ctx.fillStyle = "#163e32";
    ctx.beginPath();
    ctx.ellipse(0, 5, r.r + 4, 8, 0, 0, Math.PI * 2);
    ctx.fill();

    for (let i = 0; i < 7; i++) {
      const a = i * Math.PI * 2 / 7;

      ctx.save();
      ctx.rotate(a);
      ctx.fillStyle = i % 2 ? "#668b55" : "#86a95c";

      ctx.beginPath();
      ctx.moveTo(0, 5);
      ctx.quadraticCurveTo(-5, -7, 0, -r.r - 5);
      ctx.quadraticCurveTo(5, -7, 0, 5);
      ctx.fill();

      ctx.strokeStyle = "#d8d88e";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, 4);
      ctx.lineTo(0, -r.r);
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
  }

  function drawShots() {
    // Đạn và kiếm quang của người chơi
    playerShots.forEach(s => {
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(Math.atan2(s.vy, s.vx));
      const color = s.color || "#ffe38a";
      ctx.shadowColor = color;
      ctx.shadowBlur = s.piercing ? 30 : 14;
      if (s.leLoiEmpowered) {
        // Kiếm khí Thuận Thiên; khi E đang bật, đạn chuyển sang hiệu ứng lam-tím nổi bật.
        const tier = s.comboLevel || 1;
        if (s.leLoiEBoost) {
          const r = (s.r || 6) * (tier === 3 ? 1.35 : 1);
          const pulse = 1 + Math.sin(elapsed * 19 + s.x * .03) * .1;
          ctx.scale(pulse, pulse);
          ctx.shadowColor = tier === 3 ? "#b69cff" : "#45e8ff";
          ctx.shadowBlur = tier === 3 ? 36 : 26;
          const grad = ctx.createLinearGradient(-r * 2.5, 0, r * 2.5, 0);
          grad.addColorStop(0, "rgba(69,232,255,0)");
          grad.addColorStop(.38, tier === 3 ? "rgba(167,139,250,.95)" : "rgba(69,232,255,.95)");
          grad.addColorStop(.72, "rgba(255,255,255,1)");
          grad.addColorStop(1, "rgba(69,232,255,0)");
          ctx.fillStyle = grad;
          ctx.beginPath(); ctx.ellipse(0, 0, r * 2.5, r * .8, 0, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = tier === 3 ? "#e6dcff" : "#d9ffff"; ctx.lineWidth = tier === 3 ? 3 : 2;
          ctx.beginPath(); ctx.moveTo(-r * 1.8, 0); ctx.lineTo(r * 2.3, 0); ctx.stroke();
          for (let i = 0; i < 3; i++) {
            const yy = (i - 1) * r * .65;
            ctx.strokeStyle = i % 2 ? "#a78bfa" : "#ffffff"; ctx.lineWidth = 1.4;
            ctx.beginPath(); ctx.moveTo(-r, yy + 2); ctx.lineTo(r * (1.2 + (i % 2) * .25), -yy); ctx.stroke();
          }
        } else {
          const pulse = 1 + Math.sin(elapsed * (tier === 3 ? 18 : 12) + s.x * .025) * .08;
          ctx.scale(pulse, pulse);
          if (tier === 3) {
            ctx.shadowColor = "#fff0a0"; ctx.shadowBlur = 34;
            const blade = ctx.createLinearGradient(-42, 0, 48, 0);
            blade.addColorStop(0, "rgba(255,199,55,0)");
            blade.addColorStop(.42, "rgba(255,220,92,.72)");
            blade.addColorStop(1, "rgba(255,255,239,1)");
            ctx.fillStyle = blade;
            ctx.beginPath(); ctx.moveTo(49, 0); ctx.lineTo(4, -13); ctx.lineTo(-27, -7); ctx.lineTo(-13, 0); ctx.lineTo(-27, 7); ctx.lineTo(4, 13); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = "#fffde3"; ctx.lineWidth = 2.5;
            ctx.beginPath(); ctx.moveTo(43, 0); ctx.lineTo(-28, 0); ctx.stroke();
            for (let i = 0; i < 3; i++) { ctx.strokeStyle = i % 2 ? "#ffd75c" : "#ffffff"; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(-18, (i - 1) * 5); ctx.lineTo(20, (i - 1) * 7); ctx.stroke(); }
          } else {
            const r = (s.r || 5) * (tier === 2 ? 1.25 : 1);
            ctx.fillStyle = tier === 2 ? "rgba(255,216,107,.25)" : "rgba(255,240,179,.18)";
            ctx.beginPath(); ctx.ellipse(0, 0, r * 1.8, r, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = tier === 2 ? "#ffd86b" : "#fff0b3";
            ctx.beginPath(); ctx.ellipse(0, 0, r, r * .62, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = "#ffffff"; ctx.beginPath(); ctx.arc(2, -1, Math.max(1.5, r * .35), 0, Math.PI * 2); ctx.fill();
          }
        }
      } else if (s.lienShockOrb || s.lienChargeBurst) {
        // Lôi Châu / Lục Lôi Liên Châu: lõi trắng xanh, nhiều vòng năng lượng và tia điện nhấp nháy.
        const pulse = 1 + Math.sin(elapsed * 18 + s.x * .03) * .12;
        const r = (s.r || 16) * pulse;
        ctx.shadowColor = "#63f7ff"; ctx.shadowBlur = 34;
        ctx.fillStyle = "rgba(80,245,255,.22)";
        ctx.beginPath(); ctx.arc(0, 0, r * 1.8, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "rgba(184,255,255,.95)"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, 0, r * 1.35, elapsed * 2, elapsed * 2 + Math.PI * 1.65); ctx.stroke();
        ctx.fillStyle = "#63f7ff"; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#ffffff"; ctx.beginPath(); ctx.arc(-r * .22, -r * .2, r * .48, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#dfffff"; ctx.lineWidth = 2.2;
        for (let i = 0; i < 4; i++) {
          const a = elapsed * 7 + i * Math.PI / 2;
          const x1 = Math.cos(a) * r * .9, y1 = Math.sin(a) * r * .9;
          const x2 = Math.cos(a + .22) * r * 1.65, y2 = Math.sin(a + .22) * r * 1.65;
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x1 + (x2 - x1) * .45 + Math.sin(elapsed * 20 + i) * 3, y1 + (y2 - y1) * .45); ctx.lineTo(x2, y2); ctx.stroke();
        }
      } else if (s.kimQuyTideBlade) {
        // Lưỡi Long Quy: mũi kiếm thủy tinh nhiều lớp, viền ngọc và vây năng lượng.
        const pulse = 1 + Math.sin(elapsed * 16 + (s.bladeIndex || 0)) * .08;
        ctx.scale(pulse, pulse);
        ctx.shadowColor = "#55ffe0";
        ctx.shadowBlur = 28;
        const blade = ctx.createLinearGradient(-44, 0, 48, 0);
        blade.addColorStop(0, "rgba(52,231,196,0)");
        blade.addColorStop(.38, "rgba(68,255,220,.72)");
        blade.addColorStop(1, "rgba(245,255,255,1)");
        ctx.fillStyle = blade;
        ctx.beginPath();
        ctx.moveTo(49, 0); ctx.lineTo(5, -8); ctx.lineTo(-19, -17);
        ctx.lineTo(-11, -5); ctx.lineTo(-42, 0); ctx.lineTo(-11, 5);
        ctx.lineTo(-19, 17); ctx.lineTo(5, 8); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = "#eaffff"; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.moveTo(45, 0); ctx.lineTo(-28, 0); ctx.stroke();
        ctx.strokeStyle = "rgba(91,255,225,.95)"; ctx.lineWidth = 1.5;
        for (let j = -1; j <= 1; j++) {
          ctx.beginPath(); ctx.moveTo(-18, j * 5); ctx.lineTo(15, j * 8); ctx.stroke();
        }
        ctx.fillStyle = "#ffffff";
        ctx.beginPath(); ctx.arc(7, 0, 2.6, 0, Math.PI * 2); ctx.fill();
      } else if (s.kimQuyEmpowered) {
        // Đạn cường hóa Kim Quy: quả cầu xanh ngọc; cấp 3 có lõi trắng, vòng sáng và tia năng lượng.
        const tier = s.comboLevel || 1;
        const pulse = 1 + Math.sin(elapsed * 14 + s.x * .02) * .08;
        const radius = (s.r || 8) * pulse;
        ctx.fillStyle = tier === 3 ? "rgba(202,255,251,.22)" : "rgba(66,245,207,.2)";
        ctx.beginPath(); ctx.arc(0, 0, radius * 1.8, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = tier === 3 ? "#b8fff8" : tier === 2 ? "#62ffe0" : "#35eac5";
        ctx.beginPath(); ctx.arc(0, 0, radius, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#efffff"; ctx.lineWidth = tier === 3 ? 3 : 1.5;
        ctx.beginPath(); ctx.arc(0, 0, radius * .72, 0, Math.PI * 2); ctx.stroke();
        if (tier >= 2) {
          ctx.strokeStyle = "rgba(220,255,250,.9)"; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.ellipse(0, 0, radius * 1.5, radius * .58, elapsed * 5, 0, Math.PI * 2); ctx.stroke();
        }
        if (tier === 3) {
          ctx.strokeStyle = "rgba(188,255,249,.95)"; ctx.lineWidth = 2;
          for (let i = 0; i < 4; i++) {
            const a = elapsed * 7 + i * Math.PI / 2;
            ctx.beginPath(); ctx.moveTo(Math.cos(a) * radius, Math.sin(a) * radius);
            ctx.lineTo(Math.cos(a) * radius * 1.9, Math.sin(a) * radius * 1.9); ctx.stroke();
          }
        }
      } else if (s.waterOrb && !s.slashWave) {
        const pulse = 1 + Math.sin(elapsed * 12 + s.x * .02) * .12;
        ctx.fillStyle = "rgba(98,245,223,.24)";
        ctx.beginPath(); ctx.arc(0, 0, 13 * pulse, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#62f5df";
        ctx.beginPath(); ctx.arc(0, 0, 7 * pulse, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#efffff"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(-1, -1, 5 * pulse, -.8, 2.4); ctx.stroke();
        for (let i = 0; i < 3; i++) { const a = elapsed * 4 + i * Math.PI * 2 / 3; ctx.fillStyle = "#b9fff4"; ctx.beginPath(); ctx.arc(Math.cos(a) * 11, Math.sin(a) * 11, 1.8, 0, Math.PI * 2); ctx.fill(); }
      } else if (s.slashWave && s.kimQuySlash) {
        // Kim Quy: lưỡi chém nước xanh ngọc mở rộng theo combo, cấp 3 có lõi trắng và tia xung kích.
        const tier = s.comboLevel || 1;
        const scale = [0.72, 1, 1.42][tier - 1];
        ctx.scale(scale, scale);
        const glow = ctx.createLinearGradient(-76, 0, 54, 0);
        glow.addColorStop(0, "rgba(34,226,190,0)");
        glow.addColorStop(.45, tier === 3 ? "rgba(118,255,244,.68)" : "rgba(45,245,205,.48)");
        glow.addColorStop(1, "rgba(239,255,255,1)");
        ctx.fillStyle = glow;
        ctx.beginPath(); ctx.ellipse(-8, 0, 67, 18 + tier * 3, 0, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = tier === 3 ? "#efffff" : "#9bfff0";
        ctx.lineWidth = tier === 3 ? 5 : 3; ctx.shadowBlur = 24 + tier * 8;
        ctx.beginPath(); ctx.ellipse(-9, 0, 60, 13 + tier * 2, 0, -.48, 2.5); ctx.stroke();
        ctx.fillStyle = tier === 3 ? "#70fff0" : "#35eac5";
        ctx.beginPath(); ctx.moveTo(48, 0); ctx.lineTo(-49, -10 - tier * 2); ctx.lineTo(-23, 0); ctx.lineTo(-49, 10 + tier * 2); ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#ffffff";
        ctx.beginPath(); ctx.moveTo(45, 0); ctx.lineTo(-39, -2.5); ctx.lineTo(-20, 0); ctx.lineTo(-39, 2.5); ctx.closePath(); ctx.fill();
        if (tier === 3) {
          ctx.strokeStyle = "rgba(188,255,249,.95)"; ctx.lineWidth = 2;
          for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(-26, i * 5); ctx.lineTo(35, i * 12); ctx.stroke(); }
        }
      } else if (s.slashWave) {
        // Thuận Thiên Trảm: lưỡi kiếm vàng dài, viền lam và vòng năng lượng xoáy.
        const glow = ctx.createLinearGradient(-88, 0, 48, 0);
        glow.addColorStop(0, "rgba(255,190,55,0)");
        glow.addColorStop(.45, "rgba(255,210,91,.48)");
        glow.addColorStop(1, "rgba(255,255,238,1)");
        ctx.fillStyle = glow;
        ctx.beginPath(); ctx.ellipse(-12, 0, 76, 24, 0, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#8af4ff"; ctx.lineWidth = 3; ctx.shadowBlur = 24;
        ctx.beginPath(); ctx.ellipse(-10, 0, 63, 15, 0, -.42, 2.45); ctx.stroke();
        ctx.fillStyle = "#ffd45e";
        ctx.beginPath(); ctx.moveTo(48, 0); ctx.lineTo(-52, -13); ctx.lineTo(-25, 0); ctx.lineTo(-52, 13); ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#fffef0";
        ctx.beginPath(); ctx.moveTo(44, 0); ctx.lineTo(-43, -3); ctx.lineTo(-23, 0); ctx.lineTo(-43, 3); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,.95)"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(-66, -17); ctx.lineTo(28, -5); ctx.stroke();
      } else if (s.trail) {
        // Ba lớp kiếm quang: quầng mờ, lưỡi xanh và lõi trắng.
        const glow = ctx.createLinearGradient(-48, 0, 28, 0);
        glow.addColorStop(0, "rgba(139,234,255,0)");
        glow.addColorStop(.55, "rgba(89,205,255,.42)");
        glow.addColorStop(1, "rgba(255,255,255,.95)");
        ctx.fillStyle = glow;
        ctx.beginPath(); ctx.ellipse(-9, 0, 42, 13, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.moveTo(30, 0); ctx.lineTo(-24, -7); ctx.lineTo(-12, 0); ctx.lineTo(-24, 7); ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#ffffff";
        ctx.beginPath(); ctx.moveTo(27, 0); ctx.lineTo(-18, -2.2); ctx.lineTo(-10, 0); ctx.lineTo(-18, 2.2); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = "rgba(224,250,255,.9)"; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(-37, -11); ctx.lineTo(18, -11); ctx.stroke();
      } else {
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.moveTo(10, 0); ctx.lineTo(-5, -4); ctx.lineTo(-2, 0); ctx.lineTo(-5, 4); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    });

    // Đạn năng lượng của kẻ địch
    enemyShots.forEach(s => {
      ctx.save();
      ctx.shadowColor = s.color;
      ctx.shadowBlur = 13;
      ctx.fillStyle = s.color;

      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = "#fff8ed";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r * .55, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    });
  }

  function drawPowerup() {
    if (!powerup) return;

    ctx.save();
    ctx.translate(powerup.x, powerup.y);
    ctx.rotate(powerup.phase * .25);
    ctx.shadowColor = "#8fe8ed";
    ctx.shadowBlur = 18;
    ctx.strokeStyle = "#b8f7f3";
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.arc(
      0, 0, powerup.r + Math.sin(powerup.phase) * 2,
      0, Math.PI * 2
    );
    ctx.stroke();

    ctx.fillStyle = "#76cfd1";
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(8, 0);
    ctx.lineTo(0, 9);
    ctx.lineTo(-8, 0);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#f3ffed";
    ctx.beginPath();
    ctx.arc(0, 0, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawHunterFish(f) {
    ctx.save();
    ctx.translate(f.x, f.y);
    if (f.kind === "ghost" || f.kind === "guardian") {
      const t = performance.now() * .004 + f.phase;
      const guardian = f.kind === "guardian";
      const glow = guardian ? "#f2c76b" : "#b58aff";
      ctx.rotate(Math.sin(t) * .08);
      ctx.shadowColor = glow;
      ctx.shadowBlur = f.flash > 0 ? 24 : 13;
      if (guardian) {
        ctx.fillStyle = f.flash > 0 ? "#fff8cf" : "#6d8ba4";
        ctx.beginPath();
        ctx.moveTo(0, -f.r - 5); ctx.lineTo(f.r * .82, -f.r * .45);
        ctx.lineTo(f.r * .72, f.r * .62); ctx.lineTo(0, f.r + 5);
        ctx.lineTo(-f.r * .72, f.r * .62); ctx.lineTo(-f.r * .82, -f.r * .45);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = "#f5d78c"; ctx.lineWidth = 2.5; ctx.stroke();
        ctx.fillStyle = "#f6d97d";
        ctx.beginPath(); ctx.arc(-3, -2, 3, 0, Math.PI * 2); ctx.arc(5, -2, 3, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#e7f0ff"; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(f.r * .75, -f.r * .3); ctx.lineTo(f.r + 9, f.r * .55); ctx.stroke();
      } else {
        ctx.fillStyle = f.flash > 0 ? "#ffffff" : "#9b80d5";
        ctx.beginPath(); ctx.moveTo(-f.r, -f.r * .6);
        ctx.quadraticCurveTo(0, -f.r * 1.45, f.r, -f.r * .5);
        ctx.lineTo(f.r * .72, f.r * .65); ctx.lineTo(f.r * .25, f.r * .4);
        ctx.lineTo(-f.r * .15, f.r * .8); ctx.lineTo(-f.r * .55, f.r * .45); ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#fff0c9";
        ctx.beginPath(); ctx.arc(-4, -2, 2.5, 0, Math.PI * 2); ctx.arc(4, -2, 2.5, 0, Math.PI * 2); ctx.fill();
      }
      ctx.shadowBlur = 0;
      ctx.fillStyle = "#1b233a"; ctx.fillRect(-f.r, f.r + 5, f.r * 2, 3);
      ctx.fillStyle = glow; ctx.fillRect(-f.r, f.r + 5, f.r * 2 * Math.max(0, f.hp / f.maxHp), 3);
      ctx.restore();
      return;
    }
    if (player && player.x < f.x) ctx.scale(-1, 1);
    ctx.rotate(Math.sin(f.phase) * .08);
    ctx.shadowColor = "#80d9ef";
    ctx.shadowBlur = f.flash > 0 ? 20 : 12;
    ctx.fillStyle = f.flash > 0 ? "#e7ffff" : "#398fa2";
    ctx.beginPath();
    ctx.ellipse(0, 0, f.r, f.r * .62, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#79c7d2";
    ctx.beginPath();
    ctx.moveTo(-f.r + 2, 0);
    ctx.lineTo(-f.r - 11, -10);
    ctx.lineTo(-f.r - 10, 10);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#d8f3e9";
    ctx.beginPath(); ctx.arc(f.r * .48, -3, 4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#102d39";
    ctx.beginPath(); ctx.arc(f.r * .55, -3, 1.8, 0, Math.PI * 2); ctx.fill();
    // Thanh máu cá săn mồi (máu gấp đôi hoa sen địch).
    ctx.fillStyle = "#203835";
    ctx.fillRect(-f.r, f.r * .82, f.r * 2, 4);
    ctx.fillStyle = "#75e0d2";
    ctx.fillRect(-f.r, f.r * .82, f.r * 2 * Math.max(0, f.hp / f.maxHp), 4);
    ctx.strokeStyle = "#d7a45d"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(f.r - 1, 5); ctx.lineTo(f.r + 5, 7); ctx.stroke();
    ctx.restore();
  }

  function drawBoss() {
    if (!boss) return;

    // Vòng cảnh báo và tia laser được vẽ ở tọa độ màn chơi để người chơi dễ quan sát.
    if (boss.form === "demon" && boss.demonTeleportTimer > 0) {
      const warningAlpha = .45 + Math.sin(boss.phase * 24) * .2;
      ctx.save();
      ctx.globalAlpha = warningAlpha;
      ctx.strokeStyle = "#e1c4ff";
      ctx.lineWidth = 3;
      ctx.setLineDash([7, 5]);
      ctx.beginPath();
      ctx.arc(boss.demonTeleportX, boss.demonTeleportY, boss.r + 9 + Math.sin(boss.phase * 16) * 4, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "rgba(173, 105, 255, 0.16)";
      ctx.beginPath();
      ctx.arc(boss.demonTeleportX, boss.demonTeleportY, boss.r + 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    if (boss.laserTelegraph > 0 || boss.laserActive > 0) {
      const active = boss.laserActive > 0;
      const angle = boss.laserAngle + (active ? Math.sin(boss.laserSweep) * (boss.transformed ? .13 : .035) : 0);
      const length = Math.hypot(W, H);
      ctx.save();
      ctx.lineCap = "round";
      ctx.globalAlpha = active ? .94 : (.35 + Math.sin(performance.now() * .025) * .16);
      ctx.strokeStyle = active ? (boss.transformed ? "#e878ff" : "#7ff7ff") : "#ffb7f4";
      ctx.lineWidth = active ? (boss.transformed ? 24 : 16) : 4;
      ctx.shadowColor = ctx.strokeStyle;
      ctx.shadowBlur = active ? 28 : 12;
      ctx.beginPath(); ctx.moveTo(boss.x, boss.y);
      ctx.lineTo(boss.x + Math.cos(angle) * length, boss.y + Math.sin(angle) * length); ctx.stroke();
      if (active) {
        ctx.strokeStyle = "#ffffff"; ctx.lineWidth = boss.transformed ? 5 : 3; ctx.shadowBlur = 10;
        ctx.beginPath(); ctx.moveTo(boss.x, boss.y);
        ctx.lineTo(boss.x + Math.cos(angle) * length, boss.y + Math.sin(angle) * length); ctx.stroke();
      }
      ctx.restore();
    }

    // Vòng năng lượng tím-đỏ bao quanh Hắc Long và Huyền Quy trong toàn bộ pha lùi bất tử.
    if ((boss.form === "dragon" || boss.form === "turtle") && boss.chargeState === "retreating") {
      const pulse = performance.now() * .006;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.translate(boss.x, boss.y);
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.ellipse(0, 0, boss.r + 19 + i * 9, boss.r + 10 + i * 8,
          pulse * (i % 2 ? -1 : 1) + i * .7, 0, Math.PI * 2);
        ctx.strokeStyle = i % 2 ? "rgba(255,45,92,.88)" : "rgba(170,55,255,.9)";
        ctx.lineWidth = 3 - i * .45;
        ctx.shadowColor = i % 2 ? "#ff245d" : "#9b30ff";
        ctx.shadowBlur = 20;
        ctx.stroke();
      }
      ctx.restore();
    }

    // Vạch đỏ nhấp nháy báo hướng lao trước khi boss phóng tới.
    if (boss.chargeState === "telegraph") {
      const length = Math.hypot(W, H);
      ctx.save();
      ctx.globalAlpha = .45 + Math.sin(performance.now() * .025) * .25;
      ctx.strokeStyle = "#ff526f";
      ctx.lineWidth = 5;
      ctx.setLineDash([14, 10]);
      ctx.shadowColor = "#ff315b";
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.moveTo(boss.x, boss.y);
      ctx.lineTo(boss.x + Math.cos(boss.chargeAngle) * length, boss.y + Math.sin(boss.chargeAngle) * length);
      ctx.stroke();
      ctx.restore();
    }

    if (boss.specialTelegraph > 0) {
      const reach = Math.max(W, H) * 0.72;
      const half = boss.form === "dragon" ? 0.52 : 0.32;
      ctx.save();
      ctx.globalAlpha = 0.22 + Math.sin(performance.now() * 0.025) * 0.08;
      ctx.fillStyle = boss.form === "dragon" ? "#ff633f" : boss.form === "demon" ? "#b778ff" : "#72eaff";
      ctx.beginPath();
      ctx.moveTo(boss.x, boss.y);
      ctx.arc(boss.x, boss.y, reach, boss.specialAngle - half, boss.specialAngle + half);
      ctx.closePath(); ctx.fill();
      ctx.globalAlpha = 0.85;
      ctx.strokeStyle = ctx.fillStyle; ctx.lineWidth = 2; ctx.setLineDash([8, 7]);
      ctx.beginPath(); ctx.moveTo(boss.x, boss.y);
      ctx.lineTo(boss.x + Math.cos(boss.specialAngle) * reach, boss.y + Math.sin(boss.specialAngle) * reach);
      ctx.stroke(); ctx.restore();
    }

    // Báo trước rõ ràng cho ba kỹ năng của Ma Chủ.
    if (boss.form === "demon" && boss.demonSkill !== "idle") {
      ctx.save();
      if (boss.demonSkill === "zones-windup" || boss.demonSkill === "zones-fire" || boss.demonSkill === "zones-recovery") {
        boss.demonZones.forEach((zone) => {
          const warning = !zone.done;
          ctx.save(); ctx.globalAlpha = warning ? .34 + Math.sin(performance.now() * .018) * .12 : .72;
          ctx.fillStyle = warning ? "#b66cff" : "#f4d9ff"; ctx.strokeStyle = warning ? "#e8c6ff" : "#ffffff";
          ctx.lineWidth = warning ? 3 : 5; ctx.shadowColor = "#a65cff"; ctx.shadowBlur = warning ? 15 : 28;
          ctx.beginPath(); ctx.arc(zone.x, zone.y, 72, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
          ctx.beginPath(); ctx.arc(zone.x, zone.y, 54 + Math.sin(performance.now() * .012) * 5, 0, Math.PI * 2); ctx.stroke();
          ctx.restore();
        });
      }
      if (boss.demonSkill === "slash-windup" || boss.demonSkill === "slash-active") {
        ctx.translate(boss.x, boss.y);
        ctx.rotate(boss.demonSkillAngle);
        ctx.globalAlpha = boss.demonSkill === "slash-active" ? .72 : .34 + Math.sin(performance.now() * .025) * .12;
        ctx.fillStyle = "#ff3d73"; ctx.strokeStyle = "#ffd0e5"; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, 190, -1.12, 1.12); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.globalAlpha = boss.demonSkill === "slash-active" ? .96 : .42; ctx.strokeStyle = "#fff3ff"; ctx.lineWidth = 7; ctx.shadowColor = "#ff3d73"; ctx.shadowBlur = 28; ctx.beginPath(); ctx.arc(0, 0, 178, -.98, .98); ctx.stroke();
        ctx.strokeStyle = "#ff7dbb"; ctx.lineWidth = 2; ctx.shadowBlur = 18; ctx.beginPath(); ctx.arc(0, 0, 198, -.9, .9); ctx.stroke();
      } else if (boss.demonSkill.startsWith("swords-")) {
        ctx.translate(boss.x, boss.y);
        boss.demonSkillSwords.forEach((sword, i) => {
          const a = sword.angle + performance.now() * .0014;
          const x = Math.cos(a) * sword.radius, y = Math.sin(a) * sword.radius;
          ctx.save(); ctx.translate(x, y); ctx.rotate(a + Math.PI / 2);
          ctx.globalAlpha = .9; ctx.shadowColor = "#c18aff"; ctx.shadowBlur = 14;
          ctx.fillStyle = i % 2 ? "#f1d9ff" : "#9e58ff";
          ctx.beginPath(); ctx.moveTo(0, -13); ctx.lineTo(5, 5); ctx.lineTo(0, 12); ctx.lineTo(-5, 5); ctx.closePath(); ctx.fill(); ctx.restore();
        });
      } else if (boss.demonSkill.includes("combo")) {
        ctx.globalAlpha = .38 + Math.sin(performance.now() * .03) * .14;
        ctx.strokeStyle = "#f2c7ff"; ctx.lineWidth = 4; ctx.setLineDash([10, 8]);
        ctx.beginPath(); ctx.arc(boss.x, boss.y, boss.r + 20, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.restore();
    }

    // Thanh kiếm có trạng thái riêng: hộ chủ, truy sát theo vòng cung, rồi hồi kiếm.
    if (boss.form === "demon" && !boss.defeated) {
      const t = performance.now() * .0018;
      const mode = boss.demonSwordMode || "guard";
      const orbitRadius = mode === "tracking" ? boss.r + 42 : mode === "return" ? boss.r + 28 : boss.r + 20;
      for (let i = 0; i < 3; i++) {
        const a = t * (mode === "tracking" ? 1.5 : mode === "return" ? -1.9 : .72) + i * Math.PI * 2 / 3;
        const sx = boss.x + Math.cos(a) * orbitRadius, sy = boss.y + Math.sin(a) * orbitRadius * .72;
        ctx.save(); ctx.translate(sx, sy); ctx.rotate(a + Math.PI / 2);
        ctx.globalAlpha = mode === "return" ? .55 : .9; ctx.shadowColor = mode === "tracking" ? "#f1a7ff" : "#9f5cff"; ctx.shadowBlur = 17;
        ctx.fillStyle = mode === "tracking" ? "#f4d7ff" : "#9d65ff"; ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(0, -22); ctx.lineTo(5, 5); ctx.lineTo(0, 13); ctx.lineTo(-5, 5); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.restore();
      }
    }
    ctx.save();
    ctx.translate(boss.x, boss.y);

    const r = boss.r;
    if (boss.form === "dragon" || boss.form === "demon") {
      const t = performance.now() * .003 + boss.phase;
      const dragon = boss.form === "dragon";
      const primary = dragon ? (boss.transformed ? "#ff9a59" : "#a7445a") : (boss.transformed ? "#b87aff" : "#513c83");
      const secondary = dragon ? "#f3b45e" : "#efc9ff";
      ctx.shadowColor = primary; ctx.shadowBlur = boss.flash > 0 ? 34 : 24;
      // Vòng phong ấn xoay quanh Boss tạo cảm giác trận đấu cuối.
      ctx.save(); ctx.rotate(t * (dragon ? .65 : -.5));
      ctx.strokeStyle = `${secondary}99`; ctx.lineWidth = 2; ctx.setLineDash([8, 7]);
      ctx.beginPath(); ctx.ellipse(0, 0, r + 22, r + 12, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.setLineDash([]); ctx.restore();
      if (dragon) {
        // Hắc Long: tạo hình rồng đen rõ nét, cánh màng nhiều lớp, sừng và hắc viêm đỏ.
        const dark = boss.flash > 0;
        const wingMembrane = dark ? "#fff0d8" : (boss.transformed ? "#24111f" : "#30202e");
        const wingRim = dark ? "#ffffff" : (boss.transformed ? "#e14d48" : "#87404b");
        const scale = dark ? "#fff4dc" : "#a83d49";
        // Cánh trái – khung xương và màng cánh có các khuyết nhọn kiểu dơi.
        ctx.save();
        ctx.lineJoin = "round";
        ctx.fillStyle = wingMembrane; ctx.strokeStyle = wingRim; ctx.lineWidth = Math.max(1.5, r * .045);
        ctx.beginPath();
        ctx.moveTo(-r * .18, -r * .16);
        ctx.lineTo(-r * .52, -r * .58); ctx.lineTo(-r * 1.18, -r * 1.22);
        ctx.lineTo(-r * 1.02, -r * .62); ctx.lineTo(-r * 1.24, -r * .40);
        ctx.lineTo(-r * .83, -r * .30); ctx.lineTo(-r * .94, r * .10);
        ctx.lineTo(-r * .52, -r * .02); ctx.lineTo(-r * .27, r * .28); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.strokeStyle = wingRim; ctx.lineWidth = Math.max(1.2, r * .035);
        ctx.beginPath(); ctx.moveTo(-r * .22, -r * .12); ctx.lineTo(-r * 1.18, -r * 1.22);
        ctx.moveTo(-r * .37, r * .08); ctx.lineTo(-r * 1.02, -r * .62);
        ctx.moveTo(-r * .48, r * .12); ctx.lineTo(-r * .83, -r * .30); ctx.stroke();
        // Cánh phải, lệch nhẹ để tạo chiều sâu.
        ctx.globalAlpha = .94;
        ctx.beginPath(); ctx.moveTo(r * .12, -r * .18); ctx.lineTo(r * .48, -r * .58);
        ctx.lineTo(r * 1.12, -r * 1.08); ctx.lineTo(r * .96, -r * .54);
        ctx.lineTo(r * 1.13, -r * .30); ctx.lineTo(r * .75, -r * .18);
        ctx.lineTo(r * .82, r * .12); ctx.lineTo(r * .42, r * .02); ctx.lineTo(r * .22, r * .28); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(r * .16, -r * .12); ctx.lineTo(r * 1.12, -r * 1.08);
        ctx.moveTo(r * .32, r * .08); ctx.lineTo(r * .96, -r * .54);
        ctx.moveTo(r * .43, r * .12); ctx.lineTo(r * .75, -r * .18); ctx.stroke();
        ctx.restore();

        // Đuôi dài uốn cong phía sau thân.
        ctx.save(); ctx.lineCap = "round";
        ctx.strokeStyle = dark ? "#fff0d8" : "#21151f"; ctx.lineWidth = r * .22;
        ctx.beginPath(); ctx.moveTo(r * .42, r * .28); ctx.quadraticCurveTo(r * .95, r * .65, r * 1.22, r * .22); ctx.stroke();
        ctx.fillStyle = dark ? "#fff0d8" : "#a83d49";
        ctx.beginPath(); ctx.moveTo(r * 1.12, r * .20); ctx.lineTo(r * 1.48, r * .05); ctx.lineTo(r * 1.37, r * .40); ctx.closePath(); ctx.fill();
        ctx.restore();

        // Thân giáp đen với ánh đỏ ở sống lưng.
        const body = ctx.createRadialGradient(-r * .28, -r * .32, r * .05, 0, 0, r * 1.05);
        body.addColorStop(0, dark ? "#fff4df" : (boss.transformed ? "#63303c" : "#5b303d"));
        body.addColorStop(.42, dark ? "#e8c6a0" : "#211923");
        body.addColorStop(.78, dark ? "#ffffff" : "#100f19");
        body.addColorStop(1, "#070912");
        ctx.fillStyle = body; ctx.strokeStyle = dark ? "#ffffff" : "#b3434d"; ctx.lineWidth = Math.max(1.5, r * .035);
        ctx.beginPath(); ctx.ellipse(0, r * .04, r * .76, r * .62, -.12, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        // Các phiến vảy đỏ chạy dọc lưng.
        ctx.fillStyle = scale;
        for (let i = 0; i < 5; i++) {
          const sx = -r * .42 + i * r * .20, sy = -r * .42 + Math.abs(i - 2) * r * .035;
          ctx.beginPath(); ctx.moveTo(sx - r * .07, sy + r * .10); ctx.lineTo(sx, sy - r * .10); ctx.lineTo(sx + r * .07, sy + r * .10); ctx.closePath(); ctx.fill();
        }
        // Cổ và đầu rồng hướng sang trái.
        ctx.fillStyle = dark ? "#fff0d8" : "#17131e"; ctx.strokeStyle = dark ? "#ffffff" : "#8f3543"; ctx.lineWidth = Math.max(1.5, r * .035);
        ctx.beginPath(); ctx.ellipse(-r * .52, -r * .36, r * .43, r * .34, -.42, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(-r * .72, -r * .38); ctx.quadraticCurveTo(-r * 1.12, -r * .47, -r * 1.22, -r * .20);
        ctx.lineTo(-r * .88, -r * .12); ctx.lineTo(-r * .67, -r * .19); ctx.closePath(); ctx.fill(); ctx.stroke();
        // Hàm dưới và răng nanh.
        ctx.fillStyle = dark ? "#fff0d8" : "#6e2938";
        ctx.beginPath(); ctx.moveTo(-r * .91, -r * .13); ctx.quadraticCurveTo(-r * .72, r * .02, -r * .48, -r * .12); ctx.lineTo(-r * .78, r * .02); ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#fff0dc"; ctx.beginPath(); ctx.moveTo(-r * .90, -r * .16); ctx.lineTo(-r * .82, -r * .02); ctx.lineTo(-r * .78, -r * .17); ctx.fill();
        // Sừng đen đỏ và gai dọc gáy.
        ctx.fillStyle = dark ? "#ffffff" : "#0a0b13"; ctx.strokeStyle = dark ? "#ffffff" : "#c64b50"; ctx.lineWidth = Math.max(1.2, r * .025);
        ctx.beginPath(); ctx.moveTo(-r * .65, -r * .57); ctx.lineTo(-r * .83, -r * 1.00); ctx.lineTo(-r * .43, -r * .69);
        ctx.lineTo(-r * .30, -r * 1.08); ctx.lineTo(-r * .18, -r * .62); ctx.closePath(); ctx.fill(); ctx.stroke();
        // Mắt hắc viêm, viền sáng để nhìn rõ ở kích thước nhỏ.
        ctx.save(); ctx.shadowColor = dark ? "#ffffff" : "#ff302f"; ctx.shadowBlur = r * .22;
        ctx.fillStyle = dark ? "#ffffff" : "#ff3b32";
        ctx.beginPath(); ctx.ellipse(-r * .88, -r * .34, r * .105, r * .055, -.12, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#fff4d0"; ctx.beginPath(); ctx.arc(-r * .89, -r * .34, Math.max(1.2, r * .025), 0, Math.PI * 2); ctx.fill(); ctx.restore();
        // Hai luồng ria lửa mảnh từ mõm, chỉ vẽ nét ngắn để không tốn FPS.
        ctx.strokeStyle = dark ? "#ffffff" : "#ff5a3f"; ctx.lineWidth = Math.max(1, r * .025); ctx.globalAlpha = .85;
        ctx.beginPath(); ctx.moveTo(-r * 1.02, -r * .23); ctx.quadraticCurveTo(-r * 1.30, -r * .30, -r * 1.38, -r * .18);
        ctx.moveTo(-r * .98, -r * .16); ctx.quadraticCurveTo(-r * 1.20, -r * .06, -r * 1.34, r * .02); ctx.stroke(); ctx.globalAlpha = 1;
      } else {
        // Ma Chủ khoác áo choàng, vương miện và kiếm thần bị nhuốm bóng tối.
        ctx.fillStyle = boss.flash > 0 ? "#ffffff" : "#211b3f";
        ctx.beginPath(); ctx.moveTo(-r * .9, r * .95); ctx.lineTo(-r * .7, -r * .1);
        ctx.quadraticCurveTo(-r * .55, -r * .9, 0, -r * .9); ctx.quadraticCurveTo(r * .65, -r * .85, r * .7, -.0 * r);
        ctx.lineTo(r * 1.05, r * .95); ctx.quadraticCurveTo(0, r * .65, -r * .9, r * .95); ctx.fill();
        ctx.strokeStyle = secondary; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-r * .72, r * .8); ctx.lineTo(0, r * .25); ctx.lineTo(r * .75, r * .8); ctx.stroke();
        ctx.fillStyle = primary; ctx.beginPath(); ctx.ellipse(0, -r * .35, r * .47, r * .55, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#f7d8ff"; ctx.beginPath(); ctx.arc(-r * .17, -r * .4, 3.4, 0, Math.PI * 2); ctx.arc(r * .17, -r * .4, 3.4, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = secondary; ctx.beginPath(); ctx.moveTo(-r * .42, -r * .75); ctx.lineTo(-r * .3, -r * 1.12); ctx.lineTo(-r * .08, -r * .72); ctx.lineTo(r * .12, -r * 1.2); ctx.lineTo(r * .32, -r * .72); ctx.lineTo(r * .47, -r * .9); ctx.lineTo(r * .4, -r * .52); ctx.lineTo(-r * .4, -r * .52); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = "#d9c7ff"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(r * .55, -r * .05); ctx.lineTo(r * 1.08, r * .85); ctx.stroke();
        ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(r * .55, -r * .05); ctx.lineTo(r * 1.08, r * .85); ctx.stroke();
      }
      if (boss.invulnerable) {
        ctx.strokeStyle = secondary; ctx.lineWidth = 3; ctx.setLineDash([7, 5]);
        ctx.beginPath(); ctx.ellipse(0, 0, r + 30, r + 24, t, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
      }
      ctx.restore();
      return;
    }
    if (boss.chargeState === "stunned") {
      // Vòng choáng và các ngôi sao quay quanh đầu rùa.
      const t = performance.now() * .006;
      ctx.save();
      ctx.strokeStyle = "#fff0a8";
      ctx.fillStyle = "#fff0a8";
      ctx.lineWidth = 3;
      ctx.shadowColor = "#ffe36e";
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.ellipse(0, -r - 15, r + 16, 13, Math.sin(t) * .12, 0, Math.PI * 2);
      ctx.stroke();
      for (let i = 0; i < 3; i++) {
        const a = t + i * Math.PI * 2 / 3;
        const sx = Math.cos(a) * (r + 20);
        const sy = -r - 17 + Math.sin(a) * 9;
        ctx.beginPath();
        ctx.moveTo(sx - 5, sy); ctx.lineTo(sx + 5, sy);
        ctx.moveTo(sx, sy - 5); ctx.lineTo(sx, sy + 5);
        ctx.stroke();
      }
      ctx.restore();
    }
    const glow = ctx.createRadialGradient(0, 0, 5, 0, 0, 85);

    glow.addColorStop(0, boss.transformed ? "#bd65ff88" : "#7bd8d66a");
    glow.addColorStop(.48, boss.transformed ? "#702bff42" : "#28d9d926");
    glow.addColorStop(1, "#7bd8d600");

    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, 86, 0, Math.PI * 2);
    ctx.fill();

    if (boss.flash > 0) {
      ctx.globalAlpha = .55 + Math.sin(boss.flash * 80) * .4;
    }

    // Mai rùa chuyển tím và phát sáng ở dạng thức tỉnh.
    ctx.fillStyle = boss.transformed ? "#35265f" : "#244c43";
    ctx.strokeStyle = boss.transformed ? "#edb8ff" : "#b1d5a1";
    ctx.lineWidth = boss.transformed ? 4 : 3;
    if (boss.transformed) { ctx.shadowColor = "#c56bff"; ctx.shadowBlur = 20; }

    ctx.beginPath();
    ctx.ellipse(0, 4, r + 8, r * .78, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = boss.transformed ? "#a98aff" : "#6aa28a";
    ctx.lineWidth = boss.transformed ? 3 : 2;

    ctx.beginPath();
    ctx.moveTo(-31, -22);
    ctx.lineTo(0, -32);
    ctx.lineTo(30, -20);
    ctx.lineTo(34, 12);
    ctx.lineTo(0, 31);
    ctx.lineTo(-32, 12);
    ctx.closePath();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, -30);
    ctx.lineTo(0, 29);
    ctx.moveTo(-31, -4);
    ctx.lineTo(31, -4);
    ctx.stroke();

    // Đầu rùa hướng sang trái
    ctx.fillStyle = boss.transformed ? "#9c6ed9" : "#719b68";
    ctx.beginPath();
    ctx.ellipse(-r - 6, -1, 17, 15, -.2, 0, Math.PI * 2);
    ctx.fill();
    if (boss.transformed) {
      ctx.shadowColor = "#ff70f2"; ctx.shadowBlur = 18;
      ctx.fillStyle = "#ffb9ff";
      ctx.beginPath(); ctx.ellipse(-r - 11, -4, 4.5, 3.5, -.2, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.beginPath(); ctx.arc(-r - 12, -4, 1.7, 0, Math.PI * 2); ctx.fill();
      ctx.shadowBlur = 0;
      // Các gai năng lượng trên mai.
      for (let i = 0; i < 7; i++) {
        const a = Math.PI + i * Math.PI / 6;
        ctx.fillStyle = i % 2 ? "#9d7bff" : "#f0a5ff";
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * (r * .72), Math.sin(a) * (r * .62));
        ctx.lineTo(Math.cos(a - .12) * (r + 20), Math.sin(a - .12) * (r + 16));
        ctx.lineTo(Math.cos(a + .12) * (r + 20), Math.sin(a + .12) * (r + 16));
        ctx.closePath(); ctx.fill();
      }
    }

    ctx.fillStyle = "#f7d981";
    ctx.beginPath();
    ctx.arc(-r - 10, -5, 3.5, 0, Math.PI * 2);
    ctx.fill();

    // Thanh kiếm cổ gắn ngay trước miệng Huyền Quy, hướng ra phía người chơi.
    ctx.save();
    ctx.translate(-r - 20, 7);
    ctx.rotate(-0.12);
    ctx.shadowColor = "#b8f5ff"; ctx.shadowBlur = 12;
    ctx.fillStyle = "#d8f5f7";
    ctx.beginPath();
    ctx.moveTo(-30, 0); ctx.lineTo(-7, -4); ctx.lineTo(2, 0); ctx.lineTo(-7, 4); ctx.closePath(); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = "#6e9fa8"; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(-26, 0); ctx.lineTo(-5, 0); ctx.stroke();
    ctx.fillStyle = "#f0cc79"; ctx.fillRect(-4, -7, 4, 14);
    ctx.fillStyle = "#8c5a37"; ctx.fillRect(0, -2, 10, 4);
    ctx.restore();

    // Bốn chân
    [[-25, -25], [22, -25], [-25, 27], [22, 27]].forEach(([x, y]) => {
      ctx.fillStyle = "#4e7957";
      ctx.beginPath();
      ctx.ellipse(x, y, 12, 8, .3, 0, Math.PI * 2);
      ctx.fill();
    });

    if (boss.invulnerable) {
      ctx.save(); ctx.rotate(boss.phase * 1.8);
      ctx.strokeStyle = "#e2a2ff"; ctx.lineWidth = 2.5; ctx.setLineDash([7, 6]);
      ctx.shadowColor = "#c56bff"; ctx.shadowBlur = 15;
      ctx.beginPath(); ctx.ellipse(0, 0, r + 27, r + 20, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.setLineDash([]); ctx.restore();
    }

    // Vương miện
    ctx.fillStyle = boss.transformed ? "#f7a5ff" : "#f0cc79";
    ctx.beginPath();
    ctx.moveTo(-12, -r * .65);
    ctx.lineTo(-5, -r - 12);
    ctx.lineTo(1, -r * .62);
    ctx.lineTo(8, -r - 9);
    ctx.lineTo(13, -r * .55);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }

  // `drawPlayer` được dùng cho cả hai người qua withPlayerTwoContext.
  // Không tự gắn nhãn P1 khi đang vẽ P2; nhãn được vẽ rõ ràng ở lớp gọi để tránh
  // nhãn P1 xuất hiện trên đầu P2 và tạo cảm giác nhân vật/định vị bị lệch.
  function drawPlayer(drawLabel = true) {
    if (!player) return;

    player.trail.forEach(t => {
      if (t.life <= 0) return;

      const trailColor = activeCombatPlayerIndex === 2 ? `rgba(98, 233, 255, ${t.life * .35})` : `rgba(247, 222, 148, ${t.life * .35})`;
      ctx.fillStyle = trailColor;
      ctx.beginPath();
      ctx.arc(t.x, t.y, 3 + t.life * 7, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.save();
    ctx.translate(player.x, player.y);

    if (selectedCharacter === "lien") {
      // Quầng thủy thuật của Liên: vòng nước và cánh sen chuyển động nhẹ.
      const pulse = 1 + Math.sin(performance.now() / 180) * .08;
      ctx.save();
      ctx.strokeStyle = "rgba(105,238,231,.62)"; ctx.lineWidth = 2;
      ctx.shadowColor = "#4ce5df"; ctx.shadowBlur = 13;
      ctx.beginPath(); ctx.ellipse(0, 0, 23 * pulse, 15 / pulse, 0, 0, Math.PI * 2); ctx.stroke();
      for (let i = 0; i < 5; i++) {
        const a = performance.now() / 650 + i * Math.PI * 2 / 5;
        ctx.fillStyle = "rgba(171,255,248,.8)";
        ctx.beginPath(); ctx.ellipse(Math.cos(a) * 20, Math.sin(a) * 13, 3.2, 5.5, a, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
      // Sáu hạt Lôi Ấn xoay quanh Liên; các hạt sáng dần khi gần tích đầy.
      if (lienCharge > 0) {
        const orbit = performance.now() / 520;
        ctx.save();
        ctx.font = "bold 10px system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillStyle = lienCharge === 6 ? "#ffffff" : "#a8ffff";
        ctx.shadowColor = "#36eaff"; ctx.shadowBlur = lienCharge === 6 ? 14 : 6;
        ctx.fillText(lienCharge === 6 ? "LỤC LÔI SẴN SÀNG" : `LÔI ẤN ${lienCharge}/6`, 0, -31);
        ctx.restore();
        for (let i = 0; i < lienCharge; i++) {
          const a = orbit + i * Math.PI * 2 / 6;
          const ox = Math.cos(a) * 31, oy = Math.sin(a) * 21;
          ctx.save();
          ctx.shadowColor = "#63f7ff"; ctx.shadowBlur = lienCharge === 6 ? 20 : 10;
          ctx.fillStyle = lienCharge === 6 ? "#ffffff" : "#63f7ff";
          ctx.beginPath(); ctx.arc(ox, oy, lienCharge === 6 ? 4.5 : 3.2, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = "rgba(196,255,255,.9)"; ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.moveTo(ox - 5, oy); ctx.lineTo(ox + 5, oy); ctx.moveTo(ox, oy - 5); ctx.lineTo(ox, oy + 5); ctx.stroke();
          ctx.restore();
        }
      }
    }

    // Hiệu ứng lưỡi kiếm vòng cung khi dùng Thuận Thiên Trảm.
    if (slashFlash > 0) {
      const progress = 1 - slashFlash / .62;
      ctx.save(); ctx.rotate(Math.atan2(player.aimY || 0, player.aimX || 1));
      ctx.globalAlpha = Math.max(0, 1 - progress);
      ctx.shadowColor = selectedCharacter === "lien" ? "#55f4e8" : "#ffd45c"; ctx.shadowBlur = 30;
      ctx.strokeStyle = "rgba(255,248,203,.98)"; ctx.lineWidth = 15 * (1 - progress * .45);
      ctx.beginPath(); ctx.arc(0, 0, 68 + progress * 36, -1.02, 1.02); ctx.stroke();
      ctx.strokeStyle = "rgba(255,190,55,.9)"; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.arc(0, 0, 78 + progress * 36, -.96, .96); ctx.stroke();
      ctx.strokeStyle = "rgba(105,238,255,.9)"; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(0, 0, 58 + progress * 30, -.88, .88); ctx.stroke();
      // Các tia kiếm tỏa ra như cánh chim phượng.
      for (let i = 0; i < 7; i++) {
        const a = -.82 + i * .273;
        ctx.strokeStyle = i % 2 ? "#fff4bb" : "#80efff";
        ctx.lineWidth = i === 3 ? 3 : 1.5;
        ctx.beginPath(); ctx.moveTo(24, 0); ctx.lineTo(104 + progress * 24, Math.sin(a) * (24 + i * 3)); ctx.stroke();
      }
      ctx.restore(); ctx.globalAlpha = 1; ctx.shadowBlur = 0;
    }

    if (phongFlash > 0) {
      ctx.save(); ctx.rotate(Math.atan2(player.aimY || 0, player.aimX || 1));
      ctx.strokeStyle = `rgba(139,234,255,${phongFlash / .24})`; ctx.lineWidth = 4;
      ctx.shadowColor = "#8beaff"; ctx.shadowBlur = 20; ctx.beginPath();
      ctx.moveTo(10, -13); ctx.lineTo(40, 0); ctx.lineTo(10, 13); ctx.stroke(); ctx.restore();
    }
    if (longFlash > 0) {
      // Long Trảm bản nhẹ: vẽ ít đường, không dùng shadowBlur / composite "lighter"
      // vì các hiệu ứng blur và cộng sáng lặp mỗi frame khá tốn trên máy yếu.
      const progress = 1 - longFlash / .56;
      const fade = Math.max(0, 1 - progress);
      ctx.save();
      ctx.globalAlpha = fade;
      const outerRadius = 28 + progress * 178;

      // Hai vòng sóng mảnh tạo cảm giác lan rộng nhưng chỉ cần vài lệnh vẽ.
      ctx.strokeStyle = "#fff3bd";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(0, 0, outerRadius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = "#65e5ff";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, Math.max(3, outerRadius - 13), 0, Math.PI * 2);
      ctx.stroke();

      // Sáu lưỡi kiếm lớn, dùng nét thay vì các mảng tô và bóng đổ.
      for (let i = 0; i < 6; i++) {
        const a = i * Math.PI / 3 + progress * .12;
        const inner = 24 + progress * 26;
        const outer = 62 + progress * 132;
        ctx.save();
        ctx.rotate(a);
        ctx.beginPath();
        ctx.moveTo(inner, 0);
        ctx.quadraticCurveTo((inner + outer) * .55, -8, outer, 0);
        ctx.quadraticCurveTo((inner + outer) * .55, 8, inner, 0);
        ctx.closePath();
        ctx.strokeStyle = i % 2 ? "#70eaff" : "#ffd45c";
        ctx.lineWidth = 2.2;
        ctx.stroke();
        ctx.restore();
      }

      // Chớp sáng trung tâm đơn giản, không tạo thêm hạt mỗi frame.
      ctx.fillStyle = `rgba(255,248,205,${fade * .22})`;
      ctx.beginPath();
      ctx.arc(0, 0, 12 + progress * 19, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Vòng khiên
    if (shieldTimer > 0) {
      ctx.strokeStyle =
        `rgba(144, 239, 239, ${.65 + Math.sin(elapsed * 8) * .2})`;
      ctx.lineWidth = 2.5;
      ctx.shadowColor = "#8fe8ed";
      ctx.shadowBlur = 16;

      ctx.beginPath();
      ctx.arc(0, 0, 23 + Math.sin(elapsed * 5) * 2, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    if (invulnerable > 0 && Math.floor(elapsed * 12) % 2 === 0) {
      ctx.globalAlpha = .42;
    }

    if (selectedCharacter === "lien") {
      // Liên: linh nữ thủy thuật với dáng áo dài cách điệu, tóc dài và trượng hoa sen.
      // Tạo hình được vẽ riêng trên canvas nên chỉ thay đổi khi người chơi chọn Liên.
      ctx.save();
      const lienBob = Math.sin(elapsed * 7) * 1.5;
      ctx.translate(0, lienBob);

      // Tóc dài bay phía sau.
      ctx.fillStyle = "#172d39";
      ctx.beginPath(); ctx.moveTo(-5, -18); ctx.quadraticCurveTo(-19, -10, -15, 8);
      ctx.quadraticCurveTo(-13, 15, -8, 17); ctx.lineTo(7, 12);
      ctx.quadraticCurveTo(17, 2, 7, -18); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "rgba(106,245,231,.7)"; ctx.lineWidth = 1.2; ctx.stroke();

      // Dải khăn và tà áo xanh ngọc tạo dáng thanh thoát khác hẳn giáp chiến tướng.
      ctx.fillStyle = "#168f91";
      ctx.beginPath(); ctx.moveTo(-7, -3); ctx.quadraticCurveTo(-17, 4, -12, 18);
      ctx.lineTo(-3, 12); ctx.lineTo(2, 19); ctx.lineTo(12, 15);
      ctx.quadraticCurveTo(15, 4, 7, -3); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#8bfff0"; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.fillStyle = "#d7fff1";
      ctx.beginPath(); ctx.moveTo(-2, 1); ctx.lineTo(0, 15); ctx.lineTo(4, 2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#f0c86e"; ctx.fillRect(-7, 5, 14, 2.5);
      ctx.fillStyle = "#f8d98a"; ctx.beginPath(); ctx.arc(0, 6, 2, 0, Math.PI * 2); ctx.fill();

      // Tay áo mềm và gương mặt.
      ctx.fillStyle = "#37c9bd";
      ctx.beginPath(); ctx.ellipse(-10, 1, 5, 3.2, -.55, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(10, 1, 5, 3.2, .55, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#e8b98f"; ctx.fillRect(-2.3, -11, 4.6, 5);
      ctx.beginPath(); ctx.ellipse(0, -14, 6.2, 7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#172d39";
      ctx.beginPath(); ctx.arc(0, -17, 6.8, Math.PI, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-6, -16); ctx.quadraticCurveTo(-10, -7, -5, -5);
      ctx.lineTo(-4, -14); ctx.fill();
      ctx.beginPath(); ctx.moveTo(5, -17); ctx.quadraticCurveTo(10, -7, 5, -4);
      ctx.lineTo(4, -13); ctx.fill();
      ctx.fillStyle = "#243c43"; ctx.fillRect(-3.5, -14, 1.3, 1); ctx.fillRect(2.2, -14, 1.3, 1);

      // Trâm sen và trượng phép phát sáng.
      ctx.strokeStyle = "#e9c86e"; ctx.lineWidth = 2.2;
      ctx.beginPath(); ctx.moveTo(10, 4); ctx.lineTo(17, -9); ctx.stroke();
      ctx.strokeStyle = "#c5fff4"; ctx.lineWidth = 2.4; ctx.shadowColor = "#5cf5e7"; ctx.shadowBlur = 10;
      ctx.beginPath(); ctx.moveTo(17, -9); ctx.lineTo(20, -18); ctx.stroke();
      ctx.fillStyle = "#a4fff0";
      for (let petal = 0; petal < 5; petal++) {
        const a = petal * Math.PI * 2 / 5;
        ctx.beginPath(); ctx.ellipse(20 + Math.cos(a) * 3, -20 + Math.sin(a) * 3, 2, 3.3, a, 0, Math.PI * 2); ctx.fill();
      }
      ctx.shadowBlur = 0;
      ctx.restore();
    } else if (selectedCharacter === "kimQuy") {
      // Kim Quy — thần hộ hồ: mũ miện mai rùa, giáp ngọc và kiếm thủy quang.
      ctx.save();
      const quyBob = Math.sin(elapsed * 4.8) * 1.25;
      const tide = 0.5 + 0.5 * Math.sin(elapsed * 3.2);
      ctx.translate(0, quyBob);

      // Quầng thủy triều mảnh dưới chân, thay cho vòng trang trí dày.
      ctx.save();
      ctx.globalAlpha = .3 + tide * .22;
      ctx.strokeStyle = "#55e6c2"; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.ellipse(0, 20, 17 + tide * 3, 3.2, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();

      // Áo choàng dạng mai rùa, xanh thẫm với viền vàng cổ.
      ctx.fillStyle = "#0b5a50";
      ctx.beginPath(); ctx.moveTo(-7, -2); ctx.quadraticCurveTo(-17, 4, -13, 16);
      ctx.lineTo(-4, 12); ctx.lineTo(0, 16); ctx.lineTo(5, 12); ctx.lineTo(13, 16);
      ctx.quadraticCurveTo(17, 4, 7, -2); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#e9bd61"; ctx.lineWidth = 2.1; ctx.stroke();
      ctx.strokeStyle = "rgba(121,255,220,.75)"; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-9, 5); ctx.lineTo(-3, 9); ctx.lineTo(0, 5); ctx.lineTo(4, 9); ctx.lineTo(9, 5); ctx.stroke();

      // Giáp ngọc trung tâm và phù hiệu mai rùa phát sáng.
      ctx.shadowColor = "#55e6c2"; ctx.shadowBlur = 9;
      ctx.fillStyle = "#116e62";
      ctx.beginPath(); ctx.moveTo(-7, -4); ctx.lineTo(-9, 7); ctx.lineTo(-5, 13); ctx.lineTo(5, 13); ctx.lineTo(9, 7); ctx.lineTo(7, -4); ctx.closePath(); ctx.fill();
      ctx.shadowBlur = 0; ctx.strokeStyle = "#f0ce78"; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.strokeStyle = "#8dffe0"; ctx.lineWidth = 1;
      ctx.strokeRect(-4, 0, 8, 7); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, 7); ctx.moveTo(-4, 3.5); ctx.lineTo(4, 3.5); ctx.stroke();
      ctx.fillStyle = "#fff0a8"; ctx.beginPath(); ctx.arc(0, 1, 2, 0, Math.PI * 2); ctx.fill();

      // Vai giáp và tay áo màu ngọc lam.
      ctx.fillStyle = "#d9ad50";
      ctx.beginPath(); ctx.ellipse(-9, 0, 4.4, 3.4, -.35, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(9, 0, 4.4, 3.4, .35, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#2ab9a0";
      ctx.beginPath(); ctx.ellipse(-11, 4, 3.2, 2.5, -.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(11, 4, 3.2, 2.5, .5, 0, Math.PI * 2); ctx.fill();

      // Khuôn mặt và miện rùa vàng.
      ctx.fillStyle = "#f0c99a"; ctx.fillRect(-2.8, -13, 5.6, 4);
      ctx.beginPath(); ctx.ellipse(0, -15, 6.4, 7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#183d38"; ctx.fillRect(-4.5, -16, 2, 1.2); ctx.fillRect(2.5, -16, 2, 1.2);
      ctx.strokeStyle = "#9a5939"; ctx.lineWidth = .8; ctx.beginPath(); ctx.moveTo(-2, -12); ctx.lineTo(2, -12); ctx.stroke();
      ctx.fillStyle = "#dba84c"; ctx.strokeStyle = "#fff0a5"; ctx.lineWidth = 1.1;
      ctx.beginPath(); ctx.moveTo(-7, -19); ctx.lineTo(-4, -25); ctx.lineTo(-1, -22); ctx.lineTo(0, -28); ctx.lineTo(3, -22); ctx.lineTo(7, -25); ctx.lineTo(8, -18); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = "#8d4436"; ctx.beginPath(); ctx.arc(0, -22, 1.7, 0, Math.PI * 2); ctx.fill();

      // Kiếm thủy quang hướng chéo lên, ánh sáng xanh ngọc.
      ctx.save(); ctx.translate(10, 2); ctx.rotate(.72);
      ctx.strokeStyle = "#e8c66b"; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(0, 5); ctx.lineTo(0, -5); ctx.stroke();
      ctx.shadowColor = "#75fff0"; ctx.shadowBlur = 10;
      ctx.fillStyle = "#c7fff5"; ctx.beginPath(); ctx.moveTo(-1.3, -4); ctx.lineTo(1.3, -4); ctx.lineTo(.8, -20); ctx.lineTo(0, -24); ctx.lineTo(-.8, -20); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#4de2d0"; ctx.lineWidth = 1; ctx.stroke(); ctx.shadowBlur = 0;
      ctx.restore();
      ctx.restore();
    } else {
      // Lê Lợi — tạo hình chiến tướng Lam Sơn lấy cảm hứng từ trang phục Việt thế kỷ XV.
      // Áo giáp xanh ngọc, giáp vàng, áo choàng đỏ và khăn/mũ chiến tướng giúp nhận diện rõ khi chơi.
      ctx.save();
      const bob = Math.sin(elapsed * 8) * 1.1;
      ctx.translate(0, bob);

      // Áo choàng đỏ phía sau, có viền vàng.
      ctx.fillStyle = "#7d2028";
      ctx.beginPath();
      ctx.moveTo(-7, -1); ctx.quadraticCurveTo(-17, 7, -13, 18);
      ctx.lineTo(0, 13); ctx.lineTo(12, 18); ctx.quadraticCurveTo(16, 6, 7, -1);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#e8bd63"; ctx.lineWidth = 1.4; ctx.stroke();

      // Thân giáp xanh lam sơn, viền kim loại.
      ctx.shadowColor = "#ffd36b"; ctx.shadowBlur = 13;
      ctx.fillStyle = "#174d48";
      ctx.beginPath(); ctx.moveTo(-8, -3); ctx.lineTo(-11, 8); ctx.lineTo(-7, 15);
      ctx.lineTo(7, 15); ctx.lineTo(11, 8); ctx.lineTo(8, -3); ctx.closePath(); ctx.fill();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = "#e8bd63"; ctx.lineWidth = 2; ctx.stroke();
      // Các hàng vảy giáp và phù hiệu mặt trời.
      for (let row = 0; row < 3; row++) {
        ctx.strokeStyle = "rgba(244,205,112,.9)"; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(-7 + row * .6, 3 + row * 3); ctx.lineTo(7 - row * .6, 3 + row * 3); ctx.stroke();
      }
      ctx.fillStyle = "#f8d77d"; ctx.beginPath(); ctx.arc(0, 1, 2.2, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fff0b4"; ctx.beginPath(); ctx.arc(0, 1, .8, 0, Math.PI * 2); ctx.fill();

      // Vai giáp và đai lưng.
      ctx.fillStyle = "#d8a94f";
      ctx.beginPath(); ctx.ellipse(-9, 0, 4, 3.4, -.4, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(9, 0, 4, 3.4, .4, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#8e292b"; ctx.fillRect(-8, 8, 16, 2.5);
      ctx.fillStyle = "#f4d27b"; ctx.fillRect(-2, 7.5, 4, 3.5);

      // Cổ và gương mặt.
      ctx.fillStyle = "#d99b69"; ctx.fillRect(-2.5, -10, 5, 5);
      ctx.fillStyle = "#e9b887"; ctx.beginPath(); ctx.ellipse(0, -12, 6.5, 7.3, 0, 0, Math.PI * 2); ctx.fill();
      // Tóc mai, ria mép và nét mặt nhỏ nhưng rõ ở kích thước gameplay.
      ctx.fillStyle = "#202b28";
      ctx.beginPath(); ctx.arc(0, -15, 6.8, Math.PI, Math.PI * 2); ctx.fill();
      ctx.fillRect(-6.6, -15, 2.1, 5.5); ctx.fillRect(4.5, -15, 2.1, 5.5);
      ctx.fillStyle = "#34231d";
      ctx.beginPath(); ctx.moveTo(-4, -10); ctx.quadraticCurveTo(-2, -8, 0, -10);
      ctx.quadraticCurveTo(2, -8, 4, -10); ctx.quadraticCurveTo(2, -9, 0, -9.5); ctx.quadraticCurveTo(-2, -9, -4, -10); ctx.fill();
      ctx.fillStyle = "#35261d"; ctx.fillRect(-3.7, -13, 1.5, 1); ctx.fillRect(2.2, -13, 1.5, 1);

      // Mũ chiến tướng cách điệu, đỉnh nhọn và phù hiệu vàng.
      ctx.fillStyle = "#9a2e2d";
      ctx.beginPath(); ctx.moveTo(-8, -15); ctx.lineTo(-6, -22); ctx.lineTo(-2, -19);
      ctx.lineTo(0, -25); ctx.lineTo(3, -19); ctx.lineTo(7, -22); ctx.lineTo(8, -15); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#f1cf77"; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = "#ffdf83"; ctx.beginPath(); ctx.arc(0, -18, 2, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#e9c76e"; ctx.fillRect(-7, -15.5, 14, 2);

      // Thuận Thiên kiếm — lưỡi sáng, chuôi đỏ và tấm chắn tay vàng.
      ctx.save(); ctx.rotate(Math.sin(elapsed * 5) * .08);
      ctx.strokeStyle = "#7a4a25"; ctx.lineWidth = 3.6; ctx.beginPath(); ctx.moveTo(8, 3); ctx.lineTo(13, -1); ctx.stroke();
      ctx.strokeStyle = "#f3c75e"; ctx.lineWidth = 2.8; ctx.beginPath(); ctx.moveTo(8, 1); ctx.lineTo(12, -3); ctx.stroke();
      ctx.strokeStyle = "#fff9d8"; ctx.lineWidth = 2.5; ctx.shadowColor = "#b9f7ff"; ctx.shadowBlur = 8;
      ctx.beginPath(); ctx.moveTo(11, -4); ctx.lineTo(20, -15); ctx.stroke();
      ctx.strokeStyle = "#74eaff"; ctx.lineWidth = .8; ctx.beginPath(); ctx.moveTo(12, -5); ctx.lineTo(19, -14); ctx.stroke();
      ctx.restore();
    }

    // Đóng cả save của nhánh tạo hình và save ngoài cùng chứa translate(player.x, player.y).
    // Nếu thiếu restore thứ hai, transform của P1 còn sót lại khi vẽ P2: sprite P2 bị
    // vẽ lệch theo tọa độ P1 và nhãn P2 bị dịch khỏi đầu nhân vật dù player2 không đổi vị trí.
    ctx.restore();
    ctx.restore();
    if (drawLabel && activeCombatPlayerIndex === 1) drawPlayerLabel(player, "P1", "#ffe39a");
  }

  // Nhãn cố định theo người chơi, luôn nằm ngay trên đầu nhân vật.
  function drawPlayerLabel(target, text, color) {
    if (!target) return;
    ctx.save();
    ctx.font = "800 12px system-ui, sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.lineWidth = 3.5; ctx.strokeStyle = "rgba(3,12,22,.92)";
    ctx.strokeText(text, target.x, target.y - 31);
    ctx.fillStyle = color; ctx.fillText(text, target.x, target.y - 31);
    ctx.restore();
  }

  function drawParticles() {
    particles.forEach(p => {
      ctx.globalAlpha = clamp(p.life / p.max, 0, 1);
      ctx.fillStyle = p.color;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.globalAlpha = 1;
  }

  function drawKimQuyUltimate() {
    const u = kimQuyUltimate; if (!u) return;
    const t = u.t, x = u.x, y = u.y;
    const charge = clamp(t / .45, 0, 1);
    const fade = t > 2.0 ? clamp((2.5 - t) / .5, 0, 1) : 1;
    const radius = u.radius || 420;
    ctx.save();
    ctx.globalAlpha = fade;
    // Mai rùa cổ: các đường lục giác tượng trưng vẽ trực tiếp, không tạo hạt mới.
    const shellR = 28 + charge * 34;
    ctx.lineWidth = 2.4; ctx.strokeStyle = '#62e9c8';
    ctx.beginPath(); ctx.arc(x, y, shellR, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,231,160,.9)'; ctx.lineWidth = 1.5;
    for (let i = 0; i < 6; i++) {
      const a = i * Math.PI / 3 + t * .22;
      ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * 9, y + Math.sin(a) * 9);
      ctx.lineTo(x + Math.cos(a) * shellR, y + Math.sin(a) * shellR); ctx.stroke();
    }
    const glow = ctx.createRadialGradient(x, y, 4, x, y, 68 + charge * 20);
    glow.addColorStop(0, 'rgba(220,255,240,.48)');
    glow.addColorStop(.48, 'rgba(71,224,188,.22)');
    glow.addColorStop(1, 'rgba(71,224,188,0)');
    ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(x, y, 88, 0, Math.PI * 2); ctx.fill();
    // Tám vòng chấn hải đan xen; vẽ trực tiếp trên canvas để giữ FPS.
    const drawWave = (start, duration, color, width, scale) => {
      if (t <= start) return;
      const p = clamp((t - start) / duration, 0, 1);
      ctx.globalAlpha = fade * (1 - p) * .98;
      ctx.strokeStyle = color; ctx.lineWidth = width * (1 - p) + 1;
      ctx.beginPath(); ctx.arc(x, y, 18 + p * radius * scale, 0, Math.PI * 2); ctx.stroke();
    };
    drawWave(.38, .48, '#d9fff0', 8, 1);
    drawWave(.88, .48, '#ffe7a0', 10, .96);
    drawWave(1.38, .48, '#ffffff', 12, 1.02);
    drawWave(1.88, .58, '#62e9c8', 15, 1.08);
    if (t < .38) {
      ctx.globalAlpha = fade * (.25 + charge * .45);
      ctx.strokeStyle = '#a8ffe8'; ctx.lineWidth = 2 + charge * 5;
      ctx.beginPath(); ctx.arc(x, y, 38 + charge * 68, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
  }

  // Trụ hình bông sen của chiêu R Liên — hiệu ứng tồn tại 10 giây.
  function drawLienFlowerPillar() {
    const p = lienFlowerPillar; if (!p) return;
    const life = Math.max(0, 1 - p.t / p.duration);
    const pulse = 1 + Math.sin(p.t * 4) * .045;
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.globalAlpha = Math.min(1, life * 5 + .25);
    ctx.scale(pulse, pulse);
    // Bóng và bệ trụ.
    ctx.fillStyle = 'rgba(20, 105, 111, .28)';
    ctx.beginPath(); ctx.ellipse(0, 8, 34, 13, 0, 0, Math.PI * 2); ctx.fill();
    const pillar = ctx.createLinearGradient(-18, -8, 18, 8);
    pillar.addColorStop(0, '#287d86'); pillar.addColorStop(.45, '#b9fff2'); pillar.addColorStop(1, '#397f9b');
    ctx.fillStyle = pillar; ctx.strokeStyle = '#d9fff8'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(-15, 2); ctx.lineTo(-11, -30); ctx.lineTo(-7, -39);
    ctx.lineTo(7, -39); ctx.lineTo(11, -30); ctx.lineTo(15, 2); ctx.closePath(); ctx.fill(); ctx.stroke();
    // Sáu cánh sen lớn bao quanh đỉnh trụ.
    for (let i = 0; i < 6; i++) {
      ctx.save(); ctx.rotate(i * Math.PI / 3 + p.t * .12);
      ctx.fillStyle = i % 2 ? 'rgba(76, 239, 218, .88)' : 'rgba(226, 255, 248, .95)';
      ctx.strokeStyle = '#e4fffb'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(0, -34);
      ctx.quadraticCurveTo(-19, -52, 0, -66);
      ctx.quadraticCurveTo(19, -52, 0, -34); ctx.fill(); ctx.stroke();
      ctx.restore();
    }
    ctx.shadowColor = '#68fff0'; ctx.shadowBlur = 18;
    ctx.fillStyle = '#f0fffb'; ctx.beginPath(); ctx.arc(0, -48, 5, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function drawLienLightningDragon() {
    const u = lienLightningDragon; if (!u) return;
    const elapsed = Math.max(0, u.t || 0);
    const fade = elapsed < 2.35 ? 1 : clamp((2.85 - elapsed) / .5, 0, 1);
    const radius = u.radius || 240;
    ctx.save();
    // Vùng bão điện: nhiều vòng, vạch cảnh báo và ánh sáng nền.
    ctx.globalAlpha = fade;
    const pulse = .5 + .5 * Math.sin(elapsed * 11);
    const aura = ctx.createRadialGradient(u.x, u.y, 8, u.x, u.y, radius);
    aura.addColorStop(0, 'rgba(105,235,255,.20)');
    aura.addColorStop(.58, 'rgba(54,128,255,.09)');
    aura.addColorStop(1, 'rgba(70,90,255,0)');
    ctx.fillStyle = aura; ctx.beginPath(); ctx.arc(u.x, u.y, radius, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = `rgba(105,245,255,${.55 + pulse * .3})`; ctx.lineWidth = 2.5;
    ctx.setLineDash([10, 7]); ctx.lineDashOffset = -elapsed * 38;
    ctx.beginPath(); ctx.arc(u.x, u.y, radius * (.96 + pulse * .025), 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    ctx.strokeStyle = 'rgba(188,250,255,.42)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(u.x, u.y, radius * (.72 + pulse * .025), 0, Math.PI * 2); ctx.stroke();
    // Hai đường cung điện chạy quanh rìa vùng sét.
    for (let ring = 0; ring < 2; ring++) {
      ctx.beginPath(); ctx.strokeStyle = ring ? 'rgba(175,120,255,.58)' : 'rgba(75,225,255,.72)';
      ctx.lineWidth = ring ? 2 : 3;
      const start = elapsed * (ring ? -1.3 : 1.8) + ring * Math.PI;
      ctx.arc(u.x, u.y, radius * (ring ? .83 : .91), start, start + Math.PI * (1.1 + pulse * .25)); ctx.stroke();
    }
    // Vẽ đủ 20 điểm sét đã giáng xuống, bố trí theo vòng xoắn cố định để không nhấp nháy ngẫu nhiên.
    const count = Math.min(14, Math.max(0, u.strike || 0));
    for (let i = 0; i < count; i++) {
      const angle = i * 2.399963 + .35;
      const dist = radius * (.12 + .78 * Math.sqrt((i + 1) / 14));
      const x = clamp(u.x + Math.cos(angle) * dist, 24, W - 24);
      const y = clamp(u.y + Math.sin(angle) * dist, 24, H - 24);
      const isLatest = i === count - 1;
      const age = isLatest && u.lastStrike ? Math.max(0, u.lastStrike.t || 0) : Math.max(0, elapsed - (.25 + i * .12));
      const alpha = isLatest ? clamp(1 - age / .42, .25, 1) : .30;
      const impactR = isLatest ? 24 + (1 - alpha) * 52 : 30;
      ctx.save(); ctx.globalAlpha = fade * alpha;
      // Brilliance and vertical lightning bolt.
      ctx.shadowColor = '#65f5ff'; ctx.shadowBlur = isLatest ? 20 : 7;
      ctx.strokeStyle = '#eaffff'; ctx.lineWidth = isLatest ? 3.5 : 1.6;
      ctx.beginPath(); ctx.moveTo(x + Math.sin(i * 4) * 10, y - 105);
      ctx.lineTo(x - 15, y - 73); ctx.lineTo(x + 12, y - 49);
      ctx.lineTo(x - 9, y - 23); ctx.lineTo(x + 2, y - 5); ctx.stroke();
      ctx.strokeStyle = '#54dfff'; ctx.lineWidth = isLatest ? 5 : 2.5;
      ctx.beginPath(); ctx.moveTo(x - 2, y - 56); ctx.lineTo(x - 27, y - 36); ctx.lineTo(x - 12, y - 19); ctx.stroke();
      // Ground impact rings, core and radial sparks.
      ctx.shadowBlur = 20; ctx.strokeStyle = '#6cecff'; ctx.lineWidth = isLatest ? 5 : 2.5;
      ctx.beginPath(); ctx.arc(x, y, impactR, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(x, y, impactR * .62, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = 'rgba(195,252,255,.8)'; ctx.beginPath(); ctx.arc(x, y, isLatest ? 5 : 2.5, 0, Math.PI * 2); ctx.fill();
      for (let k = 0; k < 6; k++) {
        const a = k * Math.PI / 3 + i * .7 + elapsed * 2;
        const len = (isLatest ? 25 : 13) + 5 * Math.sin(elapsed * 13 + k);
        ctx.strokeStyle = k % 2 ? '#a4aaff' : '#d9ffff'; ctx.lineWidth = isLatest ? 2.5 : 1.3;
        ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * 7, y + Math.sin(a) * 7);
        ctx.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len); ctx.stroke();
      }
      ctx.restore();
    }
    // Các tia điện nhỏ chạy quanh vùng, tạo cảm giác bão sét liên tục.
    ctx.save(); ctx.globalAlpha = fade * (.45 + pulse * .25); ctx.shadowColor = '#75eaff'; ctx.shadowBlur = 12;
    for (let j = 0; j < 8; j++) {
      const a = elapsed * (j % 2 ? -1.1 : 1.4) + j * Math.PI / 4;
      const r1 = radius * (.72 + .06 * Math.sin(elapsed * 8 + j));
      const r2 = radius * (.83 + .05 * Math.cos(elapsed * 9 + j));
      const x1 = u.x + Math.cos(a) * r1, y1 = u.y + Math.sin(a) * r1;
      const x2 = u.x + Math.cos(a + .12) * r2, y2 = u.y + Math.sin(a + .12) * r2;
      ctx.strokeStyle = j % 2 ? '#b6a4ff' : '#7af6ff'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo((x1 + x2) / 2 + Math.sin(elapsed * 15 + j) * 8, (y1 + y2) / 2); ctx.lineTo(x2, y2); ctx.stroke();
    }
    ctx.restore(); ctx.restore();
  }

  function drawLienUltimate() {
    const u = lienUltimate; if (!u) return;
    const t = u.t, x = u.x, y = u.y;
    const bloom = clamp(t / .42, 0, 1);
    const wave = clamp((t - .46) / .48, 0, 1);
    const fade = t > .76 ? clamp((1.18 - t) / .42, 0, 1) : 1;
    ctx.save();
    // Một quầng nước dịu và hai vòng mảnh — không tạo particle trong vòng lặp vẽ.
    ctx.globalAlpha = fade * .72;
    const glow = ctx.createRadialGradient(x, y, 4, x, y, 42 + bloom * 48);
    glow.addColorStop(0, 'rgba(225,255,251,.62)');
    glow.addColorStop(.42, 'rgba(91,246,225,.24)');
    glow.addColorStop(1, 'rgba(91,246,225,0)');
    ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(x, y, 92, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#7dfff0'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(x, y, 18 + bloom * 44, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = 'rgba(228,255,251,.9)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(x, y, 30 + bloom * 32, 0, Math.PI * 2); ctx.stroke();
    // Sáu cánh sen lớn, xoay chậm khi nở.
    ctx.translate(x, y); ctx.rotate(t * .7);
    for (let i = 0; i < 6; i++) {
      ctx.save(); ctx.rotate(i * Math.PI / 3);
      ctx.globalAlpha = fade * (.48 + bloom * .42);
      ctx.fillStyle = i % 2 ? 'rgba(100,246,228,.24)' : 'rgba(225,255,250,.28)';
      ctx.strokeStyle = i % 2 ? '#4bdacb' : '#cafff5'; ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(-13, -(14 + bloom * 22), 0, -(28 + bloom * 39));
      ctx.quadraticCurveTo(13, -(14 + bloom * 22), 0, 0);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }
    if (t > .46) {
      ctx.globalAlpha = fade * (1 - wave) * .85;
      ctx.strokeStyle = '#d7fffa'; ctx.lineWidth = 3 * (1 - wave) + .8;
      ctx.beginPath(); ctx.arc(0, 0, 20 + wave * u.radius, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
  }

  function drawLeLoiSwordUltimate() {
    const u = leLoiSwordUltimate;
    if (!u) return;
    const t = u.t, x = u.x, y = u.y;
    const charge = clamp(t / .68, 0, 1);
    const fall = clamp((t - .58) / .5, 0, 1);
    const impact = clamp((t - 1.02) / .22, 0, 1);
    const fade = t > 1.55 ? clamp((2.35 - t) / .8, 0, 1) : 1;
    ctx.save();
    // Vòng ma trận tím dưới đất và các mảnh phù văn xoay quanh tâm rơi.
    ctx.globalAlpha = fade * .85;
    ctx.strokeStyle = "#b77aff"; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(x, y, 22 + charge * 76, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = "rgba(226,190,255,.8)"; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(x, y, 38 + charge * 112, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 12; i++) {
      const a = i * Math.PI * 2 / 12 + t * .8;
      const r = 52 + charge * 45;
      ctx.strokeStyle = i % 2 ? "#8e44ff" : "#f0dcff"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
      ctx.lineTo(x + Math.cos(a) * (r + 14), y + Math.sin(a) * (r + 14)); ctx.stroke();
    }
    // Đại kiếm phát sáng dựng trên không rồi cắm thẳng xuống tâm mục tiêu.
    if (t < 1.36) {
      const swordY = y - 205 + fall * 178;
      const swordH = 170, swordW = 26;
      ctx.save(); ctx.translate(x, swordY); ctx.rotate(-.04);
      ctx.shadowColor = "#a45cff"; ctx.shadowBlur = 28;
      ctx.fillStyle = "#f7edff"; ctx.strokeStyle = "#9d4dff"; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(-swordW * .38, -swordH * .36); ctx.lineTo(swordW * .38, -swordH * .36);
      ctx.lineTo(swordW * .28, swordH * .34); ctx.lineTo(0, swordH * .5); ctx.lineTo(-swordW * .28, swordH * .34); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = "#6e24d9"; ctx.lineWidth = 8;
      ctx.beginPath(); ctx.moveTo(-38, -swordH * .25); ctx.lineTo(38, -swordH * .25); ctx.stroke();
      ctx.strokeStyle = "#e8ccff"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, -swordH * .35); ctx.lineTo(0, swordH * .38); ctx.stroke();
      ctx.restore();
    }
    // Vụ nổ lan ra khi lưỡi kiếm chạm đất.
    if (t > 1.0) {
      const p = clamp((t - 1.0) / .72, 0, 1);
      ctx.globalAlpha = fade * (1 - p * .55);
      ctx.strokeStyle = "#f6eaff"; ctx.lineWidth = 11 * (1 - p) + 2;
      ctx.beginPath(); ctx.arc(x, y, 20 + p * u.radius, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = "#9b4dff"; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(x, y, 12 + p * (u.radius - 14), 0, Math.PI * 2); ctx.stroke();
      for (let i = 0; i < 10; i++) {
        const a = i * Math.PI * 2 / 10 + .15, r1 = 24 + p * 34, r2 = 48 + p * u.radius;
        ctx.strokeStyle = i % 2 ? "#d7a7ff" : "#ffffff"; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r1, y + Math.sin(a) * r1);
        ctx.lineTo(x + Math.cos(a) * r2, y + Math.sin(a) * r2); ctx.stroke();
      }
    }
    ctx.restore();
  }

  function drawDaiVietUltimate() {
    const u = daiVietUltimate;
    if (!u) return;
    const t = u.t, x = u.x, y = u.y;
    const summon = clamp(t / .82, 0, 1);
    const impact = clamp((t - 1.65) / .22, 0, 1);
    const fade = t > 2.55 ? clamp((3.2 - t) / .65, 0, 1) : 1;
    ctx.save();
    // Trống đồng phù văn mở rộng dần dưới nhân vật.
    ctx.globalAlpha = fade * (t < 2.6 ? .88 : fade);
    ctx.strokeStyle = "#f6d477"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(x, y, 22 + summon * 112, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = "rgba(115,238,239,.9)"; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(x, y, 34 + summon * 94, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 16; i++) {
      const a = i * Math.PI * 2 / 16 + t * .45;
      const r1 = 42 + summon * 34, r2 = r1 + 13;
      ctx.strokeStyle = i % 2 ? "#f8df91" : "#7cecf1"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r1, y + Math.sin(a) * r1);
      ctx.lineTo(x + Math.cos(a) * r2, y + Math.sin(a) * r2); ctx.stroke();
    }
    // Đại Việt Thần Tướng: silhouette nhiều lớp tạo cảm giác giáp vàng 3D anime.
    if (t > .42 && t < 2.85) {
      const rise = clamp((t - .42) / .7, 0, 1);
      const scale = .48 + rise * .58;
      ctx.save(); ctx.translate(x + 40, y - 24 - rise * 30); ctx.scale(scale, scale);
      ctx.globalAlpha = fade * (t < 2.1 ? 1 : clamp((2.85 - t) / .75, 0, 1));
      // Hào quang tròn phía sau đầu.
      ctx.strokeStyle = "#fff0ac"; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(0, -112, 37 + Math.sin(t * 7) * 2, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = "#69e6eb"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, -112, 48, 0, Math.PI * 2); ctx.stroke();
      // Vai và áo giáp.
      ctx.fillStyle = "#9c571e"; ctx.strokeStyle = "#ffe49a"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-29, -77); ctx.lineTo(-55, -65); ctx.lineTo(-48, -39); ctx.lineTo(-24, -46); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(29, -77); ctx.lineTo(55, -65); ctx.lineTo(48, -39); ctx.lineTo(24, -46); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = "#d99b39"; ctx.beginPath(); ctx.moveTo(-24, -82); ctx.lineTo(24, -82); ctx.lineTo(32, -28); ctx.lineTo(17, 8); ctx.lineTo(-17, 8); ctx.lineTo(-32, -28); ctx.closePath(); ctx.fill(); ctx.stroke();
      // Mặt nạ thần tướng và vương miện.
      ctx.fillStyle = "#f4d98c"; ctx.beginPath(); ctx.ellipse(0, -105, 21, 26, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = "#a83228"; ctx.beginPath(); ctx.moveTo(-22, -120); ctx.lineTo(-14, -143); ctx.lineTo(-4, -129); ctx.lineTo(0, -150); ctx.lineTo(7, -129); ctx.lineTo(17, -142); ctx.lineTo(22, -120); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = "#5fe9f2"; ctx.fillRect(-12, -108, 7, 3); ctx.fillRect(5, -108, 7, 3);
      // Hai tay giương vũ khí, lưỡi thần kiếm hướng xuống khi chuẩn bị giáng.
      const swing = t < 1.6 ? -18 : -18 + impact * 54;
      ctx.strokeStyle = "#d99b39"; ctx.lineWidth = 12; ctx.beginPath(); ctx.moveTo(-25, -68); ctx.lineTo(-49, -35); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(25, -68); ctx.lineTo(42, -40); ctx.stroke();
      ctx.save(); ctx.translate(44, -42); ctx.rotate(.18 + swing * Math.PI / 180);
      ctx.fillStyle = "#fff4c7"; ctx.strokeStyle = "#f7d16e"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-5, -10); ctx.lineTo(5, -10); ctx.lineTo(4, 52); ctx.lineTo(0, 65); ctx.lineTo(-4, 52); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.restore();
      // Dải lụa linh khí sau lưng.
      ctx.strokeStyle = "rgba(255,222,126,.9)"; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(-25, -64); ctx.quadraticCurveTo(-75, -80, -65, -22); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(25, -64); ctx.quadraticCurveTo(70, -90, 65, -28); ctx.stroke();
      ctx.restore();
    }
    // Sóng chấn động bung đúng nhịp va chạm ở giây 1,82.
    if (t > 1.62) {
      const p = clamp((t - 1.62) / .75, 0, 1);
      ctx.globalAlpha = fade * (1 - p * .65);
      ctx.strokeStyle = "#fff4c6"; ctx.lineWidth = 10 * (1 - p) + 2;
      ctx.beginPath(); ctx.arc(x, y, 26 + p * u.radius, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = "#5ce8f0"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(x, y, 12 + p * (u.radius - 20), 0, Math.PI * 2); ctx.stroke();
      for (let i = 0; i < 12; i++) {
        const a = i * Math.PI * 2 / 12 + .12;
        const r1 = 28 + p * 48, r2 = 48 + p * u.radius;
        ctx.strokeStyle = i % 2 ? "#ffe9a1" : "#8af5f3"; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r1, y + Math.sin(a) * r1);
        ctx.lineTo(x + Math.cos(a) * r2, y + Math.sin(a) * r2); ctx.stroke();
      }
    }
    ctx.restore();
  }

  // Người chơi 2 dùng lại chính hàm vẽ nhân vật của chế độ một người.
  // withPlayerTwoContext tạm chuyển player + selectedCharacter sang dữ liệu P2,
  // sau đó khôi phục nguyên trạng P1 để hai nhân vật không ghi đè lẫn nhau.
  function drawPlayerTwo() {
    if (!player2 || !p2CombatState) return;
    // Vẽ sprite bằng cùng renderer nhưng tắt nhãn mặc định của P1; nhãn P2 chỉ
    // được đặt một lần theo tọa độ thực của player2 sau khi context được khôi phục.
    // Khi P2 gục, ẩn hoàn toàn sprite và nhãn để chỉ còn ngôi mộ.
    if (p2Lives > 0) {
      withPlayerTwoContext(() => drawPlayer(false));
      drawPlayerLabel(player2, "P2", "#62e9ff");
    } else {
      drawDownedMarker(player2, "#62e9ff", "P2 GỤC · C ĐỂ CỨU");
    }
  }

  function drawDownedMarker(target, color, label) {
    if (!target) return;
    ctx.save();
    ctx.globalAlpha = .96;
    // Ngôi mộ nhỏ phát sáng thay cho vòng đánh dấu đơn giản.
    const x = target.x, y = target.y;
    ctx.fillStyle = "rgba(4,18,25,.82)"; ctx.strokeStyle = color; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(x, y + 13, 24, 8, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x - 13, y + 10); ctx.lineTo(x - 13, y - 5);
    ctx.quadraticCurveTo(x - 13, y - 17, x, y - 17);
    ctx.quadraticCurveTo(x + 13, y - 17, x + 13, y - 5); ctx.lineTo(x + 13, y + 10); ctx.closePath();
    ctx.fillStyle = "rgba(18,42,43,.96)"; ctx.fill(); ctx.stroke();
    ctx.strokeStyle = "#fff0bb"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x, y - 11); ctx.lineTo(x, y + 1); ctx.moveTo(x - 5, y - 6); ctx.lineTo(x + 5, y - 6); ctx.stroke();
    ctx.font = "bold 11px sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "bottom";
    ctx.fillStyle = "#fff2c5"; ctx.fillText(label, x, y - 23);
    if (reviveProgress > 0) {
      ctx.strokeStyle = "#8dffbd"; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(x, y - 1, 22, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, reviveProgress / REVIVE_DURATION)); ctx.stroke();
      ctx.font = "bold 10px sans-serif"; ctx.fillStyle = "#b8ffd2"; ctx.textBaseline = "top";
      ctx.fillText(`CỨU ${Math.max(0, REVIVE_DURATION - reviveProgress).toFixed(1)}s`, x, y + 23);
    }
    ctx.restore();
  }

  // Hiệu ứng phản hồi của kỹ năng P2 được vẽ tại vị trí/hướng riêng của P2,
  // không dùng slashFlash/phongFlash/longFlash toàn cục của P1.
  function drawP2SkillFx() {
    if (!player2 || p2Lives <= 0 || !p2SkillFx || p2SkillFx.time <= 0) return;
    const f = p2SkillFx;
    const progress = 1 - f.time / Math.max(.01, f.duration);
    const x = player2.x, y = player2.y;
    ctx.save();
    ctx.globalAlpha = Math.max(0, 1 - progress);
    ctx.translate(x, y);
    ctx.rotate(f.angle || 0);
    ctx.strokeStyle = "#62e9ff";
    ctx.fillStyle = "rgba(98,233,255,.18)";
    ctx.lineWidth = 3;
    if (f.type === "shot") {
      ctx.beginPath(); ctx.moveTo(10, 0); ctx.lineTo(48, 0); ctx.stroke();
      ctx.beginPath(); ctx.arc(30, 0, 5 + progress * 5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    } else {
      const radius = f.type === "ultimate" ? 62 : f.type === "wind" ? 44 : 30;
      ctx.beginPath(); ctx.arc(0, 0, radius * (.65 + progress * .35), f.type === "slash" ? -.9 : -1.25, f.type === "slash" ? .9 : 1.25); ctx.stroke();
      if (f.type === "ultimate") { ctx.beginPath(); ctx.arc(0, 0, 24 + progress * 24, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
    }
    ctx.restore();
  }

  function updateTwoPlayerHUD(){
    const a=$("p1Health"),b=$("p2Health"),sa=$("p1Score"),sb=$("p2Score");
    if(a)a.textContent=lives>0?"♥ ".repeat(lives).trim():"GỤC";
    if(b)b.textContent=p2Lives>0?"♥ ".repeat(p2Lives).trim():"GỤC";
    if(sa)sa.textContent=String(Math.max(0,score-p2Score)).padStart(4,"0"); if(sb)sb.textContent=String(p2Score).padStart(4,"0");
  }

  function draw() {
    // Khôi phục trạng thái canvas chuẩn ở đầu mỗi frame. Một số hoạt ảnh/kỹ năng
    // được tái sử dụng giữa P1/P2; nếu một nhánh hiệu ứng để sót transform,
    // alpha hoặc composite mode thì nền có thể bị vẽ thành mảng chữ nhật lớn.
    ctx.setTransform(renderScaleX, 0, 0, renderScaleY, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.shadowBlur = 0;
    ctx.shadowColor = "transparent";
    ctx.save();

    // Camera ổn định: không dịch chuyển toàn bộ canvas khi tung chiêu, trúng đòn
    // hoặc kết thúc màn. Hiệu ứng va chạm vẫn được thể hiện bằng hạt, tia sáng và
    // hoạt ảnh kỹ năng để tránh méo/nhấp nháy viền canvas trên một số màn hình.

    drawBackground();
    relics.forEach(drawRelic);
    hazards.forEach(drawHazard);
    reedPatches.forEach(drawReedPatch);
    turrets.forEach(drawTurret);
    drawLotus();
    drawPowerup();
    drawShots();
    hunterFish.forEach(drawHunterFish);
    drawBoss();
    // Vẽ bộ hiệu ứng gốc của P1 như trước.
    drawKimQuyUltimate();
    drawLienUltimate();
    drawLienLightningDragon();
    drawLienFlowerPillar();
    drawLeLoiSwordUltimate();
    drawDaiVietUltimate();

    // Sau đó vẽ lại đúng các hàm hoạt ảnh gốc trong ngữ cảnh P2.
    // withPlayerTwoContext tạm gắn state kỹ năng của P2 vào các biến mà hàm vẽ dùng,
    // rồi khôi phục state P1; vì vậy không còn vòng tròn giả thay cho CSS/FX gốc.
    withPlayerTwoContext(() => {
      drawKimQuyUltimate();
      drawLienUltimate();
      drawLienLightningDragon();
      drawLienFlowerPillar();
      drawLeLoiSwordUltimate();
      drawDaiVietUltimate();
    });
    // Khi P1 gục, không vẽ sprite nhân vật phía sau ngôi mộ.
    if (lives > 0) drawPlayer();
    else drawDownedMarker(player, "#f4d681", "P1 GỤC · C ĐỂ CỨU P2");
    drawPlayerTwo();
    drawP2SkillFx();
    drawParticles();

    ctx.restore();
  }

  let lastFrameAt = 0;
  const FRAME_INTERVAL = 1000 / 60;
  function loop(now) {
    // Giới hạn 60 FPS trên màn hình tần số quét cao để giảm tải CPU/GPU laptop.
    if (lastFrameAt && now - lastFrameAt < FRAME_INTERVAL - 1) {
      requestAnimationFrame(loop);
      return;
    }
    lastFrameAt = now;
    const dt = Math.min((now - (lastTime || now)) / 1000, .035);
    lastTime = now;

    // Màn kết quả/tạm dừng không cần chạy AI, va chạm và vẽ toàn bộ hiệu ứng mỗi khung hình.
    const activePlay = state === "playing" || state === "bossIntro" || state === "bossDefeatedIntro";
    if (activePlay) {
      update(dt);
      updateTwoPlayerHUD();
      updateBossHUD();
      draw();
    } else if (state === "intro") {
      // Vẫn giữ nền và nhân vật tĩnh ở màn bắt đầu, nhưng không chạy mô phỏng gameplay.
      draw();
    }
    requestAnimationFrame(loop);
  }


  // Nút bắt đầu, tiếp tục và chuyển chương
  $("mainBtn").addEventListener("click", () => {
    if (state === "intro") {
      if (!characterConfirmed || !modeConfirmed) {
        const missing = [];
        if (!characterConfirmed) missing.push('xác nhận nhân vật');
        if (!modeConfirmed) missing.push('xác nhận chế độ chơi');
        showOverlay('CHUẨN BỊ TRƯỚC TRẬN', 'Chưa sẵn sàng xuất phát', 'Hãy ' + missing.join(' và ') + ' trước khi bắt đầu hành trình.', 'Quay lại chọn', '✦');
        document.querySelector(!characterConfirmed ? '.character-select-panel' : '.mode-panel')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      resetGame();
    } else if (state === "gameover" || state === "won") {
      resetGame();
    } else if (state === "paused") {
      pauseGame();
    } else if (state === "bossIntro") {
      state = "playing";
      $("overlay").classList.add("hidden");
      $("pauseBtn").disabled = false;
      $("pauseBtn").textContent = "Ⅱ Tạm dừng";
      $("statusLabel").textContent = "ĐANG ĐẤU BOSS";
      lastTime = performance.now();
    } else if (state === "bossDefeatedIntro") {
      state = "playing";
      $("overlay").classList.add("hidden");
      $("pauseBtn").disabled = false;
      $("pauseBtn").textContent = "Ⅱ Tạm dừng";
      $("statusLabel").textContent = level === chapters.length - 1 ? "KIẾM THẦN ĐƯỢC GIẢI CỨU" : "CỔNG THÁP RÙA ĐÃ MỞ";
      lastTime = performance.now();
    } else if (state === "chapterDone") {
      setupLevel(level + 1);
      state = "playing";
      $("overlay").classList.add("hidden");
      $("pauseBtn").disabled = false;
      $("pauseBtn").textContent = "Ⅱ Tạm dừng";
      lastTime = performance.now();
    }
  });

  $("pauseBtn").addEventListener("click", pauseGame);

  $("restartBtn").addEventListener("click", () => {
    resetGame();

    showOverlay(
      "HÀNH TRÌNH BẮT ĐẦU",
      "Giải cứu Hồ Gươm",
      "Thu thập linh quang, tránh xoáy nước và đánh bại boss.",
      "Bắt đầu hành trình",
      "✧"
    );

    state = "intro";
    $("pauseBtn").disabled = true;
    $("statusLabel").textContent = "SẴN SÀNG";
  });

  $("soundBtn").addEventListener("click", () => {
    soundOn = !soundOn;

    $("soundBtn").setAttribute("aria-pressed", String(soundOn));
    $("soundBtn").innerHTML =
      `${soundOn ? "♫" : "♪"} <span>Âm thanh: ${soundOn ? "bật" : "tắt"}</span>`;

    if (soundOn) playTone(660, .08);
  });

  // Chuột: di chuyển con trỏ để ngắm, nhấn chuột trái để bắn theo hướng ngắm.
  function updateMouseAim(e) {
    if (!player) return;
    const rect = canvas.getBoundingClientRect();

    // Convert CSS pointer coordinates into the canvas's logical 960x540 space.
    // Use the content box (excluding borders) so aiming stays accurate when
    // the canvas is resized responsively.
    const cssX = e.clientX - rect.left - canvas.clientLeft;
    const cssY = e.clientY - rect.top - canvas.clientTop;
    const displayW = canvas.clientWidth || rect.width;
    const displayH = canvas.clientHeight || rect.height;
    const mouseX = cssX * (W / displayW);
    const mouseY = cssY * (H / displayH);

    const dx = mouseX - player.x;
    const dy = mouseY - player.y;
    const length = Math.hypot(dx, dy);
    if (length > 0.0001) {
      player.aimX = dx / length;
      player.aimY = dy / length;
    }
  }

  canvas.addEventListener("pointermove", e => {
    if (e.pointerType === "mouse") updateMouseAim(e);
  });

  // Fire on pointerdown so the shot uses the exact aim position at the moment
  // the user presses the mouse button, without click-delay or stale aim.
  canvas.addEventListener("pointerdown", e => {
    if (e.pointerType !== "mouse" || e.button !== 0 || state !== "playing" || lives <= 0) return;
    e.preventDefault();
    updateMouseAim(e);
    aimP1AtNearestTarget();
    firePlayerShot();
  });

  // Tùy chỉnh phím P2: lưu riêng trong trình duyệt và ánh xạ về các hành động logic.
  const DEFAULT_P2_KEY_MAP = { up: "i", down: "k", left: "j", right: "l", shoot: "Enter", skill1: "o", skill2: "p", ultimate: ";" };
  let p2KeyMap = { ...DEFAULT_P2_KEY_MAP };
  try {
    const savedP2Keys = JSON.parse(localStorage.getItem("hoguom_p2_keymap_v1") || "null");
    if (savedP2Keys && Object.keys(DEFAULT_P2_KEY_MAP).every(action => typeof savedP2Keys[action] === "string" && savedP2Keys[action])) p2KeyMap = { ...DEFAULT_P2_KEY_MAP, ...savedP2Keys };
  } catch (_) {}
  const p2KeyDialog = document.getElementById("p2KeyDialog");
  const p2KeyStatus = document.getElementById("p2KeyStatus");
  let p2RebindingAction = null;
  const keyDisplay = key => key === " " ? "Space" : key === ";" ? ";" : key.length === 1 ? key.toUpperCase() : key;
  const normalizedKey = key => key.length === 1 ? key.toLowerCase() : key;
  function updateP2KeyLabels() {
    document.querySelectorAll("[data-p2-bind]").forEach(button => { button.textContent = keyDisplay(p2KeyMap[button.dataset.p2Bind]); });
    const banner = document.querySelector(".two-player-banner span:nth-of-type(2)");
    if (banner) banner.textContent = `Người 2: ${keyDisplay(p2KeyMap.up)}/${keyDisplay(p2KeyMap.left)}/${keyDisplay(p2KeyMap.down)}/${keyDisplay(p2KeyMap.right)} di chuyển · ${keyDisplay(p2KeyMap.shoot)} đánh thường · ${keyDisplay(p2KeyMap.skill1)}/${keyDisplay(p2KeyMap.skill2)}/${keyDisplay(p2KeyMap.ultimate)} kỹ năng`;
    const small = document.querySelector(".p2-picker-heading small");
    if (small) small.textContent = `${keyDisplay(p2KeyMap.up)}/${keyDisplay(p2KeyMap.left)}/${keyDisplay(p2KeyMap.down)}/${keyDisplay(p2KeyMap.right)} di chuyển · ${keyDisplay(p2KeyMap.shoot)} đánh thường · ${keyDisplay(p2KeyMap.skill1)}/${keyDisplay(p2KeyMap.skill2)}/${keyDisplay(p2KeyMap.ultimate)} kỹ năng`;
  }
  function saveP2KeyMap() {
    try { localStorage.setItem("hoguom_p2_keymap_v1", JSON.stringify(p2KeyMap)); } catch (_) {}
    updateP2KeyLabels();
  }
  function openP2KeyDialog() { if (!p2KeyDialog) return; p2KeyDialog.hidden = false; p2RebindingAction = null; if (p2KeyStatus) p2KeyStatus.textContent = "Nhấn vào một phím để thay đổi."; }
  function closeP2KeyDialog() { if (!p2KeyDialog) return; p2KeyDialog.hidden = true; p2RebindingAction = null; }
  document.getElementById("p2KeySettingsBtn")?.addEventListener("click", openP2KeyDialog);
  document.getElementById("p2KeyCloseBtn")?.addEventListener("click", closeP2KeyDialog);
  document.getElementById("p2KeyDoneBtn")?.addEventListener("click", closeP2KeyDialog);
  p2KeyDialog?.addEventListener("click", event => { if (event.target === p2KeyDialog) closeP2KeyDialog(); });
  document.getElementById("p2KeyResetBtn")?.addEventListener("click", () => { p2KeyMap = { ...DEFAULT_P2_KEY_MAP }; saveP2KeyMap(); if (p2KeyStatus) p2KeyStatus.textContent = "Đã khôi phục phím mặc định."; });
  document.querySelectorAll("[data-p2-bind]").forEach(button => button.addEventListener("click", () => {
    p2RebindingAction = button.dataset.p2Bind;
    document.querySelectorAll("[data-p2-bind]").forEach(item => item.classList.toggle("is-listening", item === button));
    if (p2KeyStatus) p2KeyStatus.textContent = `Đang chờ phím cho mục “${button.parentElement.firstChild.textContent.trim()}”… nhấn Esc để hủy.`;
  }));
  updateP2KeyLabels();

  // Bàn phím
  const movementKeyNames = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "w", "a", "s", "d", "W", "A", "S", "D"];
  function clearKeyboardMovement() {
    movementKeyNames.forEach(key => { keys[key] = false; });
  }

  // Shift is disabled completely. Intercept it in capture phase so no other
  // handler/browser shortcut can turn it into an action; also clear any held
  // movement keys to prevent a stuck direction if keyup was missed.
  window.addEventListener("keydown", e => {
    if (e.key !== "Shift") return;
    e.preventDefault();
    e.stopImmediatePropagation();
    clearKeyboardMovement();
  }, true);
  window.addEventListener("keyup", e => {
    if (e.key !== "Shift") return;
    e.preventDefault();
    e.stopImmediatePropagation();
    clearKeyboardMovement();
  }, true);

  window.addEventListener("keydown", e => {
    const k = e.key;

    if (p2RebindingAction && p2KeyDialog && !p2KeyDialog.hidden) {
      e.preventDefault();
      if (k === "Escape") { p2RebindingAction = null; if (p2KeyStatus) p2KeyStatus.textContent = "Đã hủy đổi phím."; document.querySelectorAll("[data-p2-bind]").forEach(item => item.classList.remove("is-listening")); return; }
      if (["Shift", "Control", "Alt", "Meta", "Tab"].includes(k)) { if (p2KeyStatus) p2KeyStatus.textContent = "Phím này không được hỗ trợ; hãy chọn phím khác."; return; }
      if (["w", "a", "s", "d", "e", "r", "f", "c", "u", " "].includes(normalizedKey(k))) { if (p2KeyStatus) p2KeyStatus.textContent = "Phím này đang dành cho P1 hoặc chức năng hệ thống. Hãy chọn phím khác (có thể dùng các phím mũi tên)."; return; }
      const duplicate = Object.entries(p2KeyMap).find(([action, value]) => action !== p2RebindingAction && normalizedKey(value) === normalizedKey(k));
      if (duplicate) { if (p2KeyStatus) p2KeyStatus.textContent = `Phím ${keyDisplay(k)} đang được dùng cho mục khác. Hãy chọn phím chưa sử dụng.`; return; }
      p2KeyMap[p2RebindingAction] = k;
      p2RebindingAction = null;
      document.querySelectorAll("[data-p2-bind]").forEach(item => item.classList.remove("is-listening"));
      saveP2KeyMap();
      if (p2KeyStatus) p2KeyStatus.textContent = `Đã gán phím ${keyDisplay(k)}. Thiết lập đã lưu.`;
      return;
    }

    // Shift is intentionally unsupported; ignore it completely.
    if (k === "Shift") return;

    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " ", ...Object.values(p2KeyMap)].some(key => normalizedKey(key) === normalizedKey(k))) {
      e.preventDefault();
    }

    // Giữ C (P1 cứu P2) hoặc U (P2 cứu P1) đủ 2 giây khi đứng sát đồng đội.
    // Tiến trình được xử lý trong update(dt), nhả phím sẽ hủy cứu.
    // P1 và P2 có bộ trạng thái phím riêng để không ghi đè hướng di chuyển của nhau.
    keys[k] = true;
    const pk = k.toLowerCase();
    for (const direction of ["up", "down", "left", "right"]) {
      if (normalizedKey(p2KeyMap[direction]) === normalizedKey(k)) p2Keys[({ up: "i", down: "k", left: "j", right: "l" })[direction]] = true;
    }
    if (normalizedKey(p2KeyMap.shoot) === normalizedKey(k)) {
      e.preventDefault();
      p2Keys.Enter = true;
      if (!e.repeat && state === "playing" && player2 && p2Lives > 0) {
        withPlayerTwoContext(() => { aimP2AtNearestTarget(); firePlayerShot(); });
        p2SkillFx = { type: "shot", time: .18, duration: .18, angle: Math.atan2(player2.aimY || 0, player2.aimX || 1) };
      }
    }

    if (lives > 0 && (k === "e" || k === "E") && !e.repeat) thuanThienSlash();
    if (normalizedKey(p2KeyMap.skill1) === normalizedKey(k) && !e.repeat && state === "playing" && p2Lives > 0) {
      withPlayerTwoContext(() => { aimP2AtNearestTarget(); thuanThienSlash(); });
      p2SkillFx = { type: "slash", time: .42, duration: .42, angle: Math.atan2(player2?.aimY || 0, player2?.aimX || -1) };
    }
    if (normalizedKey(p2KeyMap.skill2) === normalizedKey(k) && !e.repeat && state === "playing" && p2Lives > 0) {
      withPlayerTwoContext(() => { aimP2AtNearestTarget(); kiemPhong(); });
      p2SkillFx = { type: "wind", time: .62, duration: .62, angle: Math.atan2(player2?.aimY || 0, player2?.aimX || -1) };
    }
    if (normalizedKey(p2KeyMap.ultimate) === normalizedKey(k) && !e.repeat && state === "playing" && p2Lives > 0) {
      withPlayerTwoContext(() => { aimP2AtNearestTarget(); longTram(); });
      p2SkillFx = { type: "ultimate", time: .95, duration: .95, angle: Math.atan2(player2?.aimY || 0, player2?.aimX || -1) };
    }
    // Defer dash to update() so all movement keys pressed in the same frame
    // are considered together rather than relying on keydown event order.
    if (lives > 0 && (k === "r" || k === "R") && !e.repeat) kiemPhong();
    if (lives > 0 && (k === "f" || k === "F") && !e.repeat) longTram();
    if (k === "Escape" && !e.repeat) pauseGame();
  });

  window.addEventListener("keyup", e => {
    keys[e.key] = false;
    const pk = e.key.toLowerCase();
    for (const direction of ["up", "down", "left", "right"]) {
      if (normalizedKey(p2KeyMap[direction]) === normalizedKey(e.key)) p2Keys[({ up: "i", down: "k", left: "j", right: "l" })[direction]] = false;
    }
    if (normalizedKey(p2KeyMap.shoot) === normalizedKey(e.key)) p2Keys.Enter = false;
  });

  window.addEventListener("blur", () => {
    keys = Object.create(null);
    p2Keys = Object.create(null);
    if (state === "playing") pauseGame();
  });

  // Nút kỹ năng cảm ứng cho Lê Lợi.
  const slashButton = $("slashBtn");
  if (slashButton) slashButton.addEventListener("pointerdown", e => { e.preventDefault(); thuanThienSlash(); });
  const phongButton = $("phongBtn");
  if (phongButton) phongButton.addEventListener("pointerdown", e => { e.preventDefault(); kiemPhong(); });
  const longButton = $("longBtn");
  if (longButton) longButton.addEventListener("pointerdown", e => { e.preventDefault(); longTram(); });

  // Nút bắn trên điện thoại
  const shootButton = $("shootBtn");

  if (shootButton) {
    const startShoot = e => {
      e.preventDefault();
      keys[" "] = true;
    };

    const stopShoot = e => {
      e.preventDefault();
      keys[" "] = false;
    };

    shootButton.addEventListener("pointerdown", startShoot);
    shootButton.addEventListener("pointerup", stopShoot);
    shootButton.addEventListener("pointercancel", stopShoot);
    shootButton.addEventListener("pointerleave", stopShoot);
  }

  // Nút điều hướng cảm ứng. Pointer capture giúp tránh trạng thái phím bị kẹt
  // hoặc bị nhả nhầm khi chạm nhiều nút cùng lúc.
  const directionPointers = new Map();
  const directionKeyHeld = key => {
    for (const heldKey of directionPointers.values()) {
      if (heldKey === key) return true;
    }
    return false;
  };

  document.querySelectorAll("[data-dir]").forEach(btn => {
    const dir = btn.dataset.dir;
    const map = { up: "ArrowUp", down: "ArrowDown", left: "ArrowLeft", right: "ArrowRight" };
    const key = map[dir];
    if (!key) return;

    const down = e => {
      e.preventDefault();
      if (e.pointerId !== undefined) {
        try { btn.setPointerCapture(e.pointerId); } catch (_) { }
        directionPointers.set(e.pointerId, key);
      }
      keys[key] = true;
    };

    const up = e => {
      e.preventDefault();
      if (e.pointerId !== undefined) directionPointers.delete(e.pointerId);
      // Keep the direction active if another finger is still holding its button.
      keys[key] = directionKeyHeld(key);
    };

    btn.addEventListener("pointerdown", down, { passive: false });
    btn.addEventListener("pointerup", up, { passive: false });
    btn.addEventListener("pointercancel", up, { passive: false });
    btn.addEventListener("lostpointercapture", up, { passive: false });
  });

  // Clear held movement inputs if the browser interrupts touch/keyboard input.
  function clearMovementInputs() {
    directionPointers.clear();
    clearKeyboardMovement();
  }
  window.addEventListener("blur", clearMovementInputs);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) clearMovementInputs();
  });


  // Nối các nút nâng cấp
  $("difficultySelect").addEventListener("change", (e) => {
    setMode(e.target.value);
  });
  document.querySelectorAll("[data-mode]").forEach(button => {
    button.addEventListener("click", () => setMode(button.dataset.mode));
  });

  // Chọn nhân vật: Lê Lợi và Liên dùng chung hành trình, Liên có bộ hiệu ứng thủy thuật riêng.
  let selectedCharacter = "leLoi";
  let p2SelectedCharacter = "lien";


  // Tiến triển các chiêu có hoạt ảnh trễ của P2 bằng chính bộ cập nhật dùng chung.
  // Các hiệu ứng này có tâm/điểm khởi tạo đã được chốt tại vị trí P2 khi thi triển.
  function updateP2DelayedSkills(dt) {
    if (!player2 || !p2CombatState) return;
    const c = p2CombatState;
    c.slashFlash = Math.max(0, (c.slashFlash || 0) - dt);
    c.phongFlash = Math.max(0, (c.phongFlash || 0) - dt);
    c.longFlash = Math.max(0, (c.longFlash || 0) - dt);
    p2ShieldTimer = Math.max(0, p2ShieldTimer - dt);
    const tick = (key, duration, hitAt, applyHit) => {
      const fx = c[key];
      if (!fx) return;
      fx.t = (fx.t || 0) + dt;
      if (fx.t >= hitAt && !fx.hit) { fx.hit = true; applyHit(fx); }
      if (fx.t >= duration) c[key] = null;
    };
    const hitRadius = (x, y, radius, damage, color) => {
      const hit = target => Math.hypot(target.x - x, target.y - y) <= radius + (target.r || 10);
      turrets = turrets.filter(t => { if (!hit(t)) return true; t.hp -= damage; t.flash = .25; burst(t.x,t.y,color,12); if(t.hp<=0){p2Score+=150;score+=150;return false;} return true; });
      hunterFish = hunterFish.filter(f => { if (!hit(f)) return true; f.hp -= damage; f.flash = .25; burst(f.x,f.y,color,12); if(f.hp<=0){p2Score+=180;score+=180;return false;} return true; });
      if (boss && !boss.defeated && hit(boss)) { withPlayerTwoContext(() => { for(let i=0;i<Math.max(1,damage);i++){ if(boss && !boss.defeated) damageBoss(); } }); }
      updateHUD();
    };
    tick("lienUltimate", 1.18, .48, u => hitRadius(u.x,u.y,u.radius||108,3,"#75fff0"));
    // Chiêu cuối Kim Quy của P2 có bộ đếm riêng, không dùng chung trạng thái của P1.
    if (c.kimQuyUltimate) {
      const u = c.kimQuyUltimate;
      u.t = (u.t || 0) + dt;
      const radius = u.radius || 420;
      const inRange = target => Math.hypot(target.x-u.x,target.y-u.y) <= radius + (target.r||10);
      if (u.t >= .22 && !u.pulled) {
        u.pulled = true;
        [...turrets, ...hunterFish].forEach(target => {
          if (!inRange(target)) return;
          const dx=u.x-target.x, dy=u.y-target.y, d=Math.hypot(dx,dy)||1;
          target.x=clamp(target.x+dx/d*Math.min(34,d*.24),20,W-20);
          target.y=clamp(target.y+dy/d*Math.min(34,d*.24),20,H-20);
        });
        playTone(180,.16);
      }
      const wave = (damage, push, color) => {
        turrets = turrets.filter(t => { if(!inRange(t)) return true; t.hp-=damage; t.flash=.3; t.stunTimer=Math.max(t.stunTimer||0,.8); const dx=t.x-u.x,dy=t.y-u.y,d=Math.hypot(dx,dy)||1; t.x=clamp(t.x+dx/d*push,20,W-20); t.y=clamp(t.y+dy/d*push,20,H-20); burst(t.x,t.y,color,7); if(t.hp<=0){p2Score+=150;score+=150;return false;} return true; });
        hunterFish = hunterFish.filter(f => { if(!inRange(f)) return true; f.hp-=damage; f.flash=.3; f.stunTimer=Math.max(f.stunTimer||0,.8); const dx=f.x-u.x,dy=f.y-u.y,d=Math.hypot(dx,dy)||1; f.x=clamp(f.x+dx/d*push,20,W-20); f.y=clamp(f.y+dy/d*push,20,H-20); burst(f.x,f.y,color,7); if(f.hp<=0){p2Score+=180;score+=180;return false;} return true; });
        if (boss && !boss.defeated && inRange(boss)) { withPlayerTwoContext(() => { breakBossWindupForKimQuy(); if (!boss.invulnerable) for(let i=0;i<2;i++){ if(boss && !boss.defeated) damageBoss(); } }); }
        shake=Math.max(shake,9); playTone(color==="#ffffff"?660:(color==="#ffe7a0"?520:420),.2); updateHUD();
      };
      const waveTimes = [.38, .70, 1.02, 1.34, 1.66, 1.98, 2.30, 2.62];
      const wavePush = [28, 35, 42, 49, 56, 63, 70, 78];
      const waveColors = ["#62e9c8", "#ffe7a0", "#ffffff", "#62e9c8", "#8beaff", "#fff4c2", "#b7fff3", "#ffffff"];
      if (!u.waves) u.waves = [u.hit, u.hit2, u.hit3, u.hit4, false, false, false, false].map(Boolean);
      waveTimes.forEach((at, i) => {
        if (u.t >= at && !u.waves[i]) {
          u.waves[i] = true;
          wave(12, wavePush[i], waveColors[i]);
          if (i === 7) c.shieldTimer = Math.max(c.shieldTimer || 0, 2);
        }
      });
      if(u.t>=3.18)c.kimQuyUltimate=null;
    }
    tick("leLoiSwordUltimate", 2.35, 1.08, u => hitRadius(u.x,u.y,u.radius||150,3.5,"#d7a7ff"));
    tick("daiVietUltimate", 3.2, 1.82, u => hitRadius(u.x,u.y,u.radius||228,4,"#f6d477"));
    if (c.lienLightningDragon) {
      const u = c.lienLightningDragon; u.t = (u.t || 0) + dt; if (u.lastStrike) u.lastStrike.t += dt;
      if (u.strike < 14 && u.t >= .25 + u.strike * .15) withPlayerTwoContext(() => resolveLienLightningDragon());
      if (u.t >= 2.85) c.lienLightningDragon = null;
    }
    if (c.lienFlowerPillar) { const p=c.lienFlowerPillar; p.t=(p.t||0)+dt; p.fireTimer=(p.fireTimer||.2)-dt; if(p.fireTimer<=0&&p.t<p.duration){let target=boss&&!boss.defeated?boss:null;let best=target?distance(p,target):Infinity;[...hunterFish,...turrets].forEach(t=>{const d=distance(p,t);if(d<best){target=t;best=d;}});if(target&&best<620){const dx=target.x-p.x,dy=target.y-p.y,len=Math.hypot(dx,dy)||1;playerShots.push({x:p.x,y:p.y-48,vx:dx/len*330,vy:dy/len*330,r:9,life:2.1,damage:1,color:'#8ffff0',lotusPillarShot:true,coOpShot:true,trail:true});}p.fireTimer=.62;}if(p.t>=p.duration)c.lienFlowerPillar=null; }
  }

  // Temporarily bind the existing single-player combat functions to player 2.
  // Shared world entities/projectiles remain shared, while combo and cooldown state is restored per fighter.
  function withPlayerTwoContext(action) {
    if (!player2 || !p2CombatState) return;
    const p1 = { player, selectedCharacter, upgrades, shotCooldown, slashCooldown, phongCooldown, longCooldown, slashFlash, phongFlash, longFlash, shieldTimer, activeCombatPlayerIndex, daiVietUltimate, leLoiSwordUltimate, kimQuyUltimate, lienUltimate, lienLightningDragon, lienFlowerPillar, lienCharge, lienChargeIdleTimer, kimQuyCombo, kimQuyComboTimer, leLoiCombo, leLoiComboTimer, leLoiEmpowerTimer, invulnerable };
    const firstNewShot = playerShots.length;
    player = player2;
    activeCombatPlayerIndex = 2;
    selectedCharacter = p2SelectedCharacter;
    upgrades = p2Upgrades;
    shotCooldown = p2CombatState.shotCooldown;
    slashCooldown = p2CombatState.slashCooldown;
    phongCooldown = p2CombatState.phongCooldown;
    longCooldown = p2CombatState.longCooldown;
    slashFlash = p2CombatState.slashFlash || 0; phongFlash = p2CombatState.phongFlash || 0; longFlash = p2CombatState.longFlash || 0;
    shieldTimer = p2ShieldTimer;
    lienCharge = p2CombatState.lienCharge;
    lienChargeIdleTimer = p2CombatState.lienChargeIdleTimer;
    kimQuyCombo = p2CombatState.kimQuyCombo;
    kimQuyComboTimer = p2CombatState.kimQuyComboTimer;
    leLoiCombo = p2CombatState.leLoiCombo;
    leLoiComboTimer = p2CombatState.leLoiComboTimer;
    leLoiEmpowerTimer = p2CombatState.leLoiEmpowerTimer;
    invulnerable = p2Invulnerable;
    daiVietUltimate = p2CombatState.daiVietUltimate || null;
    leLoiSwordUltimate = p2CombatState.leLoiSwordUltimate || null;
    kimQuyUltimate = p2CombatState.kimQuyUltimate || null;
    lienUltimate = p2CombatState.lienUltimate || null;
    lienLightningDragon = p2CombatState.lienLightningDragon || null;
    lienFlowerPillar = p2CombatState.lienFlowerPillar || null;
    try { action(); } finally {
      // Giữ hiệu ứng đang chạy của P2 trong trạng thái riêng, không để bị xóa khi khôi phục P1.
      Object.assign(p2CombatState, { daiVietUltimate, leLoiSwordUltimate, kimQuyUltimate, lienUltimate, lienLightningDragon, lienFlowerPillar });
      for (let i = firstNewShot; i < playerShots.length; i++) {
        // Chỉ gắn nguồn P2; không sửa tọa độ do kỹ năng gốc tính toán (một số chiêu bắn từ điểm ngắm).
        playerShots[i].coOpShot = true;
      }
      Object.assign(p2CombatState, { shotCooldown, slashCooldown, phongCooldown, longCooldown, slashFlash, phongFlash, longFlash, lienCharge, lienChargeIdleTimer, kimQuyCombo, kimQuyComboTimer, leLoiCombo, leLoiComboTimer, leLoiEmpowerTimer, invulnerable });
      // Hiệu ứng/flash toàn cục do hàm dùng chung tạo khi P2 ra chiêu không được để lại trên P1.
      slashFlash = p1.slashFlash; phongFlash = p1.phongFlash; longFlash = p1.longFlash; p2ShieldTimer = shieldTimer; shieldTimer = p1.shieldTimer; activeCombatPlayerIndex = p1.activeCombatPlayerIndex;
      daiVietUltimate = p1.daiVietUltimate; leLoiSwordUltimate = p1.leLoiSwordUltimate;
      kimQuyUltimate = p1.kimQuyUltimate; lienUltimate = p1.lienUltimate;
      lienLightningDragon = p1.lienLightningDragon; lienFlowerPillar = p1.lienFlowerPillar;
      p2Invulnerable = invulnerable;
      player = p1.player;
      selectedCharacter = p1.selectedCharacter;
      p2Upgrades = upgrades;
      upgrades = p1.upgrades;
      shotCooldown = p1.shotCooldown; slashCooldown = p1.slashCooldown; phongCooldown = p1.phongCooldown; longCooldown = p1.longCooldown;
      lienCharge = p1.lienCharge; lienChargeIdleTimer = p1.lienChargeIdleTimer; kimQuyCombo = p1.kimQuyCombo; kimQuyComboTimer = p1.kimQuyComboTimer;
      leLoiCombo = p1.leLoiCombo; leLoiComboTimer = p1.leLoiComboTimer; leLoiEmpowerTimer = p1.leLoiEmpowerTimer; invulnerable = p1.invulnerable;
    }
  }
  let characterConfirmed = false;
  const leLoiChoice = $("leLoiChoice");
  const lienChoice = $("lienChoice");
  const kimQuyChoice = $("kimQuyChoice");
  const confirmCharacterBtn = $("confirmCharacterBtn");
  const characterSelectPanel = document.querySelector(".character-select-panel");
  function selectCharacter(id) {
    selectedCharacter = id;
    characterConfirmed = false;
    updateCooldownDisplay();
    const isLien = id === "lien", isKimQuy = id === "kimQuy";
    leLoiChoice?.classList.toggle("selected", !isLien && !isKimQuy);
    lienChoice?.classList.toggle("selected", isLien);
    kimQuyChoice?.classList.toggle("selected", isKimQuy);
    // Nhãn trên từng thẻ cập nhật ngay để người chơi luôn thấy nhân vật đã chọn.
    [[leLoiChoice, !isLien && !isKimQuy], [lienChoice, isLien], [kimQuyChoice, isKimQuy]].forEach(([card, active]) => {
      const badge = card?.querySelector(".hero-choice-selected");
      if (badge) badge.innerHTML = active ? '<span>✓</span> ĐÃ CHỌN' : '<span>＋</span> CHỌN NHÂN VẬT';
    });
    leLoiChoice?.setAttribute("aria-pressed", String(!isLien && !isKimQuy));
    lienChoice?.setAttribute("aria-pressed", String(isLien));
    kimQuyChoice?.setAttribute("aria-pressed", String(isKimQuy));
    $("characterSelectStatus").innerHTML = '<span class="status-check">✓</span> ' + (isLien ? 'Liên đã sẵn sàng ra trận' : isKimQuy ? 'Kim Quy đã sẵn sàng ra trận' : 'Lê Lợi đã sẵn sàng ra trận');
    const ribbon = document.querySelector(".character-ribbon strong");
    if (ribbon) ribbon.textContent = 'NHÂN VẬT ĐANG CHỌN: ' + (isLien ? 'LIÊN' : isKimQuy ? 'KIM QUY' : 'LÊ LỢI');
    const subtitle = $("characterRibbonSubtitle");
    if (subtitle) subtitle.textContent = isLien ? 'Linh nữ Hồ Gươm · Pháp sư tầm xa · Thủy thuật' : isKimQuy ? 'Thần hộ hồ · Đỡ đòn · Sóng nước phản công' : 'Kiếm chủ Thuận Thiên · Cận chiến cơ động · Kiếm khí tầm xa';
    const shootBtn = $("shootBtn"), slashBtn = $("slashBtn"), phongBtn = $("phongBtn"), longBtn = $("longBtn");
    if (shootBtn) shootBtn.textContent = isLien ? "💧 Thủy Châu" : isKimQuy ? "🌊 Thủy Đạn" : "✦ Kiếm khí";
    if (slashBtn) slashBtn.textContent = isLien ? "✿ Liên Hoa · E" : isKimQuy ? "🛡 Quy Giáp · E" : "⚔ Thuận Thiên Trảm · E";
    if (phongBtn) phongBtn.textContent = isLien ? "〰 Thủy Ảnh · R" : isKimQuy ? "〰 Thủy Chấn · R" : "〰 Kiếm Phong · R";
    if (longBtn) longBtn.textContent = isLien ? "✿ Liên Hoa Nguyệt Triều · F" : isKimQuy ? "🐢 Thần Quy Hiện Thế · F" : "☀ Hồn Thiêng Đại Việt · F";
    if (confirmCharacterBtn) {
      confirmCharacterBtn.classList.remove("is-confirmed");
      confirmCharacterBtn.innerHTML = 'Xác nhận nhân vật <span>→</span>';
    }
    characterSelectPanel?.classList.remove("character-confirmed");
  }
  leLoiChoice?.addEventListener("click", () => selectCharacter("leLoi"));
  lienChoice?.addEventListener("click", () => selectCharacter("lien"));
  kimQuyChoice?.addEventListener("click", () => selectCharacter("kimQuy"));
  const p2CharacterStatus = $("p2CharacterStatus");
  document.querySelectorAll("[data-p2-character]").forEach(button => {
    button.addEventListener("click", () => {
      p2SelectedCharacter = button.dataset.p2Character;
      document.querySelectorAll("[data-p2-character]").forEach(option => {
        const active = option === button;
        option.classList.toggle("is-selected", active);
        option.setAttribute("aria-pressed", String(active));
      });
      if (p2CharacterStatus) p2CharacterStatus.textContent = p2SelectedCharacter === "lien" ? "LIÊN" : p2SelectedCharacter === "kimQuy" ? "KIM QUY" : "LÊ LỢI";
      if (player2) {
        p2CombatState = { shotCooldown: 0, slashCooldown: 0, phongCooldown: 0, longCooldown: 0, slashFlash: 0, phongFlash: 0, longFlash: 0, shieldTimer: 0, lienCharge: 0, lienChargeIdleTimer: 0, kimQuyCombo: 0, kimQuyComboTimer: 0, leLoiCombo: 0, leLoiComboTimer: 0, leLoiEmpowerTimer: 0, invulnerable: p2Invulnerable, daiVietUltimate: null, leLoiSwordUltimate: null, kimQuyUltimate: null, lienUltimate: null, lienLightningDragon: null, lienFlowerPillar: null };
      }
      updateCooldownDisplay();
      p2SkillFx = { type: "ultimate", time: .55, duration: .55, angle: Math.atan2(player2?.aimY || 0, player2?.aimX || -1) };
    });
  });
  confirmCharacterBtn?.addEventListener("click", () => {
    characterConfirmed = true;
    const isLien = selectedCharacter === "lien", isKimQuy = selectedCharacter === "kimQuy";
    characterSelectPanel?.classList.add("character-confirmed");
    confirmCharacterBtn.classList.add("is-confirmed");
    confirmCharacterBtn.innerHTML = 'Đã xác nhận ' + (isLien ? 'Liên' : isKimQuy ? 'Kim Quy' : 'Lê Lợi') + ' <span>✓</span>';
    $("characterSelectStatus").innerHTML = '<span class="status-check">✓</span> Đã khóa lựa chọn · ' + (isLien ? 'Linh nữ Hồ Gươm' : isKimQuy ? 'Thần hộ hồ' : 'Kiếm chủ Thuận Thiên');
    document.querySelector(".mode-panel")?.scrollIntoView({ behavior: "smooth", block: "center" });
  });

  $("confirmModeBtn")?.addEventListener("click", () => {
    modeConfirmed = true;
    const names = { easy: "Thư thái", normal: "Phiêu lưu", hard: "Huyền thoại", hell: "Địa ngục" };
    const button = $("confirmModeBtn");
    button?.classList.add("is-confirmed");
    if (button) button.innerHTML = 'Đã xác nhận ' + names[difficulty] + ' <span>✓</span>';
    $("modeConfirmStatus").textContent = '✓ Chế độ ' + names[difficulty] + ' đã sẵn sàng';
    document.querySelector(".game-card")?.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  // Chế độ toàn màn hình cho khu vực trò chơi.
  const fullscreenBtn = $("fullscreenBtn");
  const gameCard = document.querySelector(".game-card");
  async function toggleFullscreen() {
    try {
      if (!document.fullscreenElement) {
        if (gameCard.requestFullscreen) await gameCard.requestFullscreen();
      } else if (document.exitFullscreen) {
        await document.exitFullscreen();
      }
    } catch (error) {
      console.warn("Không thể bật toàn màn hình trên trình duyệt này.", error);
    }
  }
  fullscreenBtn?.addEventListener("click", toggleFullscreen);
  document.addEventListener("fullscreenchange", () => {
    configureCanvasResolution();
    const active = document.fullscreenElement === gameCard;
    if (fullscreenBtn) {
      fullscreenBtn.textContent = active ? "⤢ Thoát toàn màn hình" : "⛶ Toàn màn hình";
      fullscreenBtn.setAttribute("aria-pressed", String(active));
    }
  });

  refreshUpgradeUI();

  // Khởi tạo trò chơi
  $("best").textContent = String(best).padStart(4, "0");

  setupLevel(0);
  state = "intro";
  draw();

  requestAnimationFrame(loop);
  // ===== CẦU NỐI DEV MODE =====
  // Giữ cầu nối trong cùng phạm vi với các biến/hàm của game.
  window.HoGuomDevAPI = {
    get chapterCount() { return chapters.length; },
    jumpChapter(index) {
      index = clamp(Number(index) || 0, 0, chapters.length - 1);
      setupLevel(index);
      state = "playing";
      lives = Math.max(lives, 3);
      collected = 0;
      $("overlay").classList.add("hidden");
      $("pauseBtn").disabled = false;
      $("pauseBtn").textContent = "Ⅱ Tạm dừng";
      $("statusLabel").textContent = `DEV · CHƯƠNG ${index + 1}`;
      updateHUD();
      lastTime = performance.now();
      return `Đã nhảy tới chương ${index + 1}: ${chapters[index].name}`;
    },
    spawnBoss(stage) {
      if (state === "intro") { lives = Math.max(lives, 3); score = Math.max(score, 0); }
      let finalChapter = level === chapters.length - 1;
      if (stage === 2 && !finalChapter) {
        this.jumpChapter(chapters.length - 1);
        finalChapter = true;
      }
      if (!finalChapter && stage !== 2) stage = 0;
      collected = chapters[level].count;
      relics = [];
      gateOpen = true;
      state = "playing";
      $("overlay").classList.add("hidden");
      spawnBoss(finalChapter ? (stage || 1) : 0);
      updateHUD();
      return `Đã gọi ${boss ? boss.name : "Boss"}`;
    },
    advanceBossPhase() {
      if (level !== chapters.length - 1) this.jumpChapter(chapters.length - 1);
      if (boss && !boss.defeated && boss.stage === 1) {
        boss.hp = 0;
        boss.defeated = true;
        spawnBoss(2);
        return "Đã chuyển sang giai đoạn 2/2 · Ma Chủ Đoạt Kiếm";
      }
      this.spawnBoss(2);
      return "Đã mở giai đoạn 2/2 · Ma Chủ Đoạt Kiếm";
    },
    testVictory() {
      this.jumpChapter(chapters.length - 1);
      finishChapter();
      return "Đã chạy thử màn hình chiến thắng cuối game";
    },
    resetRun() {
      devGodMode = false;
      resetGame();
      return "Đã đặt lại hành trình từ chương 1";
    },
    toggleGodMode() { devGodMode = !devGodMode; return devGodMode; },
    setGodMode(value) { devGodMode = Boolean(value); return devGodMode; },
    heal() { lives = 3; invulnerable = 2; updateHUD(); return "Đã hồi đầy 3 mạng cho P1"; },
    healPlayer2() { p2Lives = 3; p2Invulnerable = 2; updateHUD(); return "Đã hồi đầy 3 mạng cho P2"; },
    healBothPlayers() { lives = 3; invulnerable = 2; p2Lives = 3; p2Invulnerable = 2; updateHUD(); return "Đã hồi đầy 3 mạng cho cả P1 và P2"; },
    setDevPlayer2Invulnerable(value) { p2DevGodMode = Boolean(value); return p2DevGodMode; }
  };
})();