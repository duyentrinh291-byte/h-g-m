/* HỒ GƯƠM — DEV MODE RIÊNG CHO CHẾ ĐỘ 2 NGƯỜI
 * Gỡ: xóa thẻ script HOGUOM_DEV_2P trong game-2p.html và xóa file này.
 * Không cần sửa game.css. Phím F8 hoặc nút DEV để mở/ẩn bảng.
 */
(() => {
  "use strict";
  if (!location.pathname.toLowerCase().endsWith("game-2p.html")) return;
  const api = window.HoGuomDevAPI;
  if (!api || typeof api.healPlayer2 !== "function") { console.warn("Dev 2P: API chưa sẵn sàng."); return; }
  const style = document.createElement("style"); style.id = "hoguom-dev-2p-style";
  style.textContent = `
  #hoguomDev2pToggle{position:fixed;z-index:100000;left:12px;bottom:12px;border:1px solid #70e6d3;border-radius:999px;padding:9px 14px;color:#eafffa;background:#07343a;box-shadow:0 5px 18px #0005;font:700 12px system-ui,sans-serif;cursor:pointer}
  #hoguomDev2pPanel{position:fixed;z-index:99999;top:12px;right:12px;width:min(320px,calc(100vw - 24px));max-height:calc(100vh - 24px);overflow:auto;box-sizing:border-box;padding:13px;border:1px solid #70e6d388;border-radius:14px;color:#eafffa;background:#071f26f5;box-shadow:0 12px 34px #0007;font:12px/1.45 system-ui,sans-serif}
  #hoguomDev2pPanel[hidden]{display:none}#hoguomDev2pPanel *{box-sizing:border-box}#hoguomDev2pPanel .hgd-head{display:flex;justify-content:space-between;align-items:center;color:#8ff1d8;margin-bottom:10px}
  #hoguomDev2pPanel button,#hoguomDev2pPanel select{min-width:0;border:1px solid #86e2d855;border-radius:7px;padding:7px 8px;color:#eafffa;background:#12383e;font:inherit;cursor:pointer}#hoguomDev2pPanel button:hover{background:#1b5558}
  #hoguomDev2pPanel .hgd-row{display:flex;gap:6px;margin:6px 0}#hoguomDev2pPanel .hgd-row select{flex:1;width:0}#hoguomDev2pPanel .hgd-actions{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:10px}#hoguomDev2pPanel label{display:block;margin-top:9px;color:#b4d8d4}#hoguomDev2pStatus{min-height:18px;color:#9bf1cb;margin:10px 0 4px}#hoguomDev2pPanel small{color:#9bb8b8}@media(max-width:520px){#hoguomDev2pPanel{top:7px;right:7px;width:min(290px,calc(100vw - 14px));max-height:calc(100vh - 14px)}}`;
  document.head.appendChild(style);
  const toggle=document.createElement("button");toggle.id="hoguomDev2pToggle";toggle.type="button";toggle.textContent="🛠 DEV 2P";toggle.setAttribute("aria-label","Mở hoặc ẩn Dev Mode hai người");document.body.appendChild(toggle);
  const panel=document.createElement("aside");panel.id="hoguomDev2pPanel";panel.hidden=true;panel.setAttribute("aria-label","Công cụ kiểm thử hai người");
  panel.innerHTML=`<div class="hgd-head"><strong>🛠 DEV MODE · 2P</strong><button type="button" data-action="close" aria-label="Ẩn bảng">×</button></div>
  <small>Công cụ kiểm thử riêng chế độ hai người. F8 để mở/ẩn.</small>
  <label for="hgd2pChapter">Chuyển nhanh chương</label><div class="hgd-row"><select id="hgd2pChapter"><option value="0">Chương 1</option><option value="1">Chương 2</option><option value="2">Chương 3</option><option value="3">Chương 4</option><option value="4">Chương 5</option><option value="5">Chương 6</option></select><button type="button" data-action="jump">Đi</button></div>
  <label for="hgd2pBoss">Gọi boss</label><div class="hgd-row"><select id="hgd2pBoss"><option value="0">Boss chương hiện tại</option><option value="1">Hắc Long thức tỉnh</option><option value="2">Ma Chủ đoạt kiếm</option></select><button type="button" data-action="boss">Gọi</button></div>
  <div class="hgd-actions"><button type="button" data-action="heal1">Hồi máu P1</button><button type="button" data-action="heal2">Hồi máu P2</button><button type="button" data-action="healBoth">Hồi máu cả hai</button><button type="button" data-action="phase">Boss phase 2</button><button type="button" data-action="god1">Bất tử P1: TẮT</button><button type="button" data-action="god2">Bất tử P2: TẮT</button><button type="button" data-action="victory">Test chiến thắng</button><button type="button" data-action="reset">Reset màn</button></div><p id="hoguomDev2pStatus" role="status">Đã đóng bảng · F8 để mở/ẩn</p>`;
  document.body.appendChild(panel);let god1=false,god2=false;
  const status=m=>{const el=panel.querySelector("#hoguomDev2pStatus");if(el)el.textContent=m;};
  function show(force){panel.hidden=typeof force==="boolean"?!force:!panel.hidden;status(panel.hidden?"Đã đóng bảng · F8 để mở/ẩn":"Đang mở · chế độ 2 người");}
  function run(fn){try{status(fn());}catch(err){console.error("Dev 2P:",err);status("Thao tác lỗi · kiểm tra Console (F12)");}}
  toggle.addEventListener("click",()=>show());window.addEventListener("keydown",e=>{if(e.key==="F8"){e.preventDefault();show();}});
  panel.addEventListener("click",e=>{const b=e.target.closest("button[data-action]");if(!b)return;switch(b.dataset.action){
  case "close":show(false);break;case "jump":run(()=>api.jumpChapter(Number(panel.querySelector("#hgd2pChapter").value)));break;case "boss":run(()=>api.spawnBoss(Number(panel.querySelector("#hgd2pBoss").value)));break;
  case "heal1":run(()=>api.heal());break;case "heal2":run(()=>api.healPlayer2());break;case "healBoth":run(()=>api.healBothPlayers());break;case "phase":run(()=>api.advanceBossPhase());break;
  case "god1":god1=api.setGodMode(!god1);b.textContent=`Bất tử P1: ${god1?"BẬT":"TẮT"}`;status(`Bất tử P1 ${god1?"đã bật":"đã tắt"}`);break;
  case "god2":god2=api.setDevPlayer2Invulnerable(!god2);b.textContent=`Bất tử P2: ${god2?"BẬT":"TẮT"}`;status(`Bất tử P2 ${god2?"đã bật":"đã tắt"}`);break;
  case "victory":run(()=>api.testVictory());break;case "reset":god1=false;god2=false;api.setDevPlayer2Invulnerable(false);run(()=>api.resetRun());panel.querySelector('[data-action="god1"]').textContent="Bất tử P1: TẮT";panel.querySelector('[data-action="god2"]').textContent="Bất tử P2: TẮT";break;}});
})();
